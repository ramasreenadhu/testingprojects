package com.login.test;

import com.login.bean.LoginBean;
import com.login.dao.LoginDao;
import java.io.IOException;

import java.io.IOException;

public class loginTest {
    public static void main(String args[]){
        LoginBean loginBean = new LoginBean();

        loginBean.setUserName("rama");
        loginBean.setPassword("welcome1");

        LoginDao loginDao = new LoginDao();

       try {
           String userValidate = loginDao.authenticateUser(loginBean);

           if (userValidate.equals("Admin_Role")) {
               System.out.println("Admin's Home");
           }
       } catch (Exception e1) {
           e1.printStackTrace();
       }
    }
}
