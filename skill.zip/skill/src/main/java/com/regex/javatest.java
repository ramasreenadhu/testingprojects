package com.regex;

import java.text.SimpleDateFormat;
import java.util.Date;

public class javatest {
    public static void main(String args[]){
     // String date ="2018-09-10T21:19:42.000+0000";
     // System.out.println(date.substring(5,7)+"/"+date.substring(8,10));
//        double kilobytes = 0.068478;
//
//        System.out.println("kilobytes : " + kilobytes);
//
//        double newKB = Math.round(kilobytes*100);
//        System.out.println("kilobytes (Math.round) : " + newKB);

        //System.out.println(String.format ("%.2f", 6.8478));

        String dateInString = "sep 04";
        int i =dateInString.indexOf(" ")+1;
       // dateInString =

    }
}
