package crackinterview;


import java.util.Arrays;

public class Mar0720 {

    /*
        tips
         int[] num = new int[128];
         num[1]='a'; // output 97
     */



    /*
        check string has unique chars return true / false
     */

    public boolean isUniqueChars(String str){
        if(str.length()>128){
            return false;
        }
        boolean[] char_set = new boolean[128];
        for(int i=0; i<str.length(); i++){
            int val = str.charAt(i);
            if(char_set[val]){
                return false;
            }
            char_set[val]=true;
        }
        return true;
    }

    /*
        check string has permutations ex: ABC -> BCA or CBA...
     */

    public boolean isStringsPermutations(String str1, String str2){
        if(str1.length() != str2.length()){
            return false;
        }

        return sort(str1).equals(sort(str2));
    }

    public String sort(String str){
        char[] chars= str.toCharArray();
        Arrays.sort(chars);
        return new String(chars);
    }

    public void numberOFCharsInString(String str){
        char[] myChar= str.toCharArray();
        int[] num = new int[128];
        num[1]='a'; // output 97

        for(char c:myChar){
            num[c]++;
        }

        for(char c:myChar){
            System.out.println("count of " +c +" is "+ num[c]);
        }
    }

    public boolean isStringsPermutationsSolution2(String str1, String str2){
        if(str1.length() != str2.length()){
            return false;
        }

        char[] myChar= str1.toCharArray();
        int[] num = new int[128];

        for(char c:myChar){
            num[c]++;
        }

        char[] myChars = str2.toCharArray();
         for(char c:myChars){
             num[c]--;
             if(num[c]<0){
                 return false;
             }
         }
         return true;
    }

    public static void main(String args[]){
        String myString= "abac";
        boolean result =new Mar0720().isUniqueChars(myString);
        System.out.println(result);
//
//        String str="abc";
//        String str1 ="bca";
//        boolean result1 = new Mar0720().isStringsPermutations(str,str1);
//        System.out.println(result1);

        //new Mar0720().numberOFCharsInString("rama");

//        String str="abc";
//        String str1 ="bca";
//        boolean result1 = new Mar0720().isStringsPermutationsSolution2(str,str1);
//        System.out.println(result1);


    }
}
