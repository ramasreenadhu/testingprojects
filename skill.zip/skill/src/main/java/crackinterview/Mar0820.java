package crackinterview;

public class Mar0820 {

    public void print2DMatrix(){

        final int[][] matrix = {
                { 1, 2, 3 },
                { 4, 5, 6 },
                { 7, 8, 9 }
        };
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println(); //change line on console as row comes to end in the matrix.

            /*
                matrix[0][0] -> 1, matrix[0][1] -> 2..
             */
        }

    }
}
