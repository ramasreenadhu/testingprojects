package crackinterview;

import java.util.HashMap;
import java.util.Map;

public class Mar0920 {

    /*
        Given nums = [2, 7, 11, 15], target = 9,
        Because nums[0] + nums[1] = 2 + 7 = 9,
        return [0, 1].
     */
    public int[] twoSum(int[] nums, int target) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            map.put(nums[i], i);
        }
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement) && map.get(complement) != i) {
                return new int[] { i, map.get(complement) };
            }
        }
        throw new IllegalArgumentException("No two sum solution");
    }

    public int maxSubArray(int[] sum){

        int currSum=sum[0], maxSum=sum[0];
        for(int i =1;i<sum.length;i++){
            currSum = Math.max(currSum, currSum+sum[i]);
            maxSum = Math.max(currSum,maxSum);
        }
        return maxSum;
    }

    public int maxSubArraySolution2(int[] nums) {
        int n = nums.length;
        int currSum = nums[0], maxSum = nums[0];

        for(int i = 1; i < n; ++i) {
            currSum = Math.max(nums[i], currSum + nums[i]);
            maxSum = Math.max(maxSum, currSum);
        }
        return maxSum;
    }

    public static void main(String args[]){
        int[] val = new int[]{-2,1,-3,4,-1,2,1,-5,4};
        int result = new Mar0920().maxSubArraySolution2(val);
        System.out.println(result);
    }
}
