package cyclicSort;

public class CyclicSortTest {

    /*
         Input: [3, 1, 5, 4, 2]
         Output: [1, 2, 3, 4, 5]
     */

    public static void sort(int[] nums) {
        int i = 0;
        while (i < nums.length) {
            int j = nums[i] - 1;
            if (nums[i] != nums[j])
                swap(nums, i, j);
            else
                i++;
        }
    }

    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public static void main(String[] args) {
        int[] arr = new int[]{3, 1, 5, 4, 2};
        CyclicSortTest.sort(arr);
        for (int num : arr)
            System.out.print(num + " ");
        System.out.println();
    }

}
