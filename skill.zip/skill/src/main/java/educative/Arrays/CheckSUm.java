package educative.Arrays;

/*
    arr = {1, 21, 3, 14, 5, 60, 7, 6}
    value = 27
    output : arr = {21, 6} or {6, 21}
 */
public class CheckSUm {

}
