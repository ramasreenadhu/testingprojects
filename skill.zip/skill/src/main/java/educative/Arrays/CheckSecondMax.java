package educative.Arrays;

public class CheckSecondMax {
}
