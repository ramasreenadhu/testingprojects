package educative.Arrays;

public class FindSum2 {
        static boolean findSumOfTwo(int[] A, int val) {
            int i = 0;
            int j = A.length - 1;

            while (i < j) {
                int sum = A[i] + A[j];
                if (sum == val) {
                    return true;
                }

                if (sum < val) {
                    ++i;
                } else {
                    --j;
                }
            }
            return false;
        }

        public static void main(String[] args) {
            int[] v = new int[]{1, 3, 4, 5, 7, 14, 15}; //Sorted Array
            int[] test = new int[]{3, 20, 1, 2, 7};

            for (int i = 0; i < test.length; i++){
                boolean output = findSumOfTwo(v, test[i]);
                System.out.println("findSumOfTwo(v, " + test[i] + ") = " + (output ? "true" : "false"));
            }
        }
    }
