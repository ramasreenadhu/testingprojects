package educative.Arrays;


/*
      arr1 = {1, 3, 4, 5}
      arr2 = {2, 6, 7, 8,10}
      output: arr = {1, 2, 3, 4, 5, 6, 7, 8, 10}
 */

public class MergeTwoSortedArrsys {

    public static int[] mergeTwo(int[] arr1, int[] arr2){
        int r1 = arr1.length;
        int r2 = arr2.length;
        int[] resultArr= new int[r1+r2];
        int i=0, j=0, k=0;
        while(i < r1 && j <r2 ){
            if(arr1[i] < arr2[j]){
                resultArr[k++] = arr1[i++];
            }else{
                resultArr[k++] = arr2[j++];
            }
        }

        while(i<r1){
            resultArr[k++] = arr1[i++];
        }

        while(j<r2){
            resultArr[k++] = arr2[j++];
        }

      return resultArr;
    }

    public static void main(String args[]) {

        int[] arr1 = {1,12,14,17,23}; // creating a sorted array called arr1
        int[] arr2 = {11,19,27};  // creating a sorted array called arr2

        int[] resultantArray = mergeTwo(arr1, arr2); // calling mergeArrays

        System.out.print("Arrays after merging: ");
        for(int i = 0; i < arr1.length + arr2.length; i++) {
            System.out.print(resultantArray[i] + " ");
        }

        //Arrays after merging: 1 11 12 14 17 19 23 27
    }
}
