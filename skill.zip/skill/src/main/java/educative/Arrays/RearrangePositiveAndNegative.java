package educative.Arrays;

import java.util.Arrays;

public class RearrangePositiveAndNegative {
    /*
         arr = {10, -1, 20, 4, 5, -9, -6} => arr = {-1, -9, -6, 10, 20, 4, 5}
     */

      public static void reArrange(int[] arr) {
          int j = 0;
          for (int i = 0; i < arr.length; i++) {
              if (arr[i] < 0) {   // if negative number found
                  if (i != j) {
                      int temp = arr[i];
                      arr[i] = arr[j]; // swapping with leftmost positive
                      arr[j] = temp;
                  }
                  j++;
              }
          }
      }

    public static void main(String args[]) {
        int[] arr = {2, 4, -6, 8, -5, -10};
        reArrange(arr);
        System.out.println(Arrays.toString(arr));
        //output : [-6, -5, -10, 8, 4, 2]
    }
}
