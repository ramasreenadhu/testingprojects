package educative.Arrays;

import java.util.Arrays;

public class RemoveEleFromArray {

    public static int[] removeEvenNumbersFromArray(int[] arr){
        int oddElements=0;
        int k=0;
        for(int i=0; i<arr.length;i++){
            if(arr[i]%2!=0){
                oddElements++;
            }
        }
        int[] oddNum = new int[oddElements];

        for(int i=0; i<arr.length;i++){
            if(arr[i]%2!=0){
                oddNum[k++]=arr[i];
            }
        }
        return oddNum;
    }

    public static void main(String args[]) {

        int[] arr1 = {1,12,14,17,23};

        int[] resultantArray = removeEvenNumbersFromArray(arr1);
        System.out.println(Arrays.toString(resultantArray));
        //output : [1, 17, 23] -- oddNumbers
    }
}
