package educative;

import java.util.HashMap;

public class FreackingProb {
    public int maxNumberOfBalloons(String text) {

        if(text==null || text.length()<7){
            return 0;
        }
        HashMap<Character,Integer> map = new HashMap<>();
        for(char ch:text.toCharArray()){
            if (ch == 'B' || ch == 'A' || ch == 'L' || ch == 'O' || ch == 'N')
                map.put(ch,map.getOrDefault(ch,0)+1);
        }

        if(!map.containsKey('B') || !map.containsKey('A') || !map.containsKey('L') || !map.containsKey('O') || !map.containsKey('N')) {
            return 0;
        }

        int charCount = 0;
        while(map.get('B')>=1 && map.get('B')>=1 && map.get('L')>=2 && map.get('O')>=2 && map.get('N')>=1){
            charCount++;
            map.put('B',map.get('B')-1);
            map.put('A',map.get('A')-1);
            map.put('L',map.get('L')-2);
            map.put('O',map.get('O')-2);
            map.put('N',map.get('N')-1);
        }
        System.out.println(charCount);
        return charCount;
    }

    public static void main(String[] args){
        FreackingProb freackingProb = new FreackingProb();
        freackingProb.maxNumberOfBalloons("BAONXXOLL");
        freackingProb.maxNumberOfBalloons("BAOOLLNNOLOLGBAX");
        freackingProb.maxNumberOfBalloons("QAWABAWONL");



    }
}
