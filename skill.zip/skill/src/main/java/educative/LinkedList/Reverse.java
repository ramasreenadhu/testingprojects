package educative.LinkedList;//package educative.LinkedList;
//
//import java.util.LinkedList;
//
//class Reverse{
//    public static LinkedListNode reverse(LinkedListNode head) {
//        // no need to reverse if head is null
//        // or there is only 1 node.
//        if (head == null || head.next == null) {
//            return head;
//        }
//
//        LinkedListNode listToDo = head.next;
//        LinkedListNode reversedList = head;
//
//        reversedList.next = null;
//
//        while (listToDo != null) {
//            LinkedListNode temp = listToDo;
//            listToDo = listToDo.next;
//
//            temp.next = reversedList;
//            reversedList = temp;
//        }
//
//        return reversedList;
//    }
//    public static void main(String[] args) {
//        LinkedListNode listHead = null;
//        int [] arr = {7,14,21,28};
//        listHead = LinkedList.createLinkedList(arr);
//
//        System.out.print("Original: ");
//        LinkedList.display(listHead);
//
//        listHead = reverse(listHead);
//        System.out.print("After Reverse: ");
//        LinkedList.display(listHead);
//    }
//}
