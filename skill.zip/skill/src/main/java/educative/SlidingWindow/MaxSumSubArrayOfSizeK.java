package educative.SlidingWindow;

/*
         Given an array of positive numbers and a positive number ‘k’,
         find the maximum sum of any contiguous subarray of size ‘k’.

         Input: [2, 1, 5, 1, 3, 2], k=3
         Output: 9
         Explanation: Subarray with maximum sum is [5, 1, 3].

         Input: [2, 3, 4, 1, 5], k=2
         Output: 7
         Explanation: Subarray with maximum sum is [3, 4].
 */

public class MaxSumSubArrayOfSizeK {

    public static int maxSumFromSubArray(int[] arr, int k){

        int maxSum=0, sum=0;
        int j=0;

        for(int i=0; i< arr.length;i++){
            sum = sum+arr[i];

            if(i >=k-1){
                maxSum = Math.max(sum,maxSum);
                sum = sum-arr[j];
                j++;
            }
        }
         return maxSum;
    }

    public static void main(String[] args) {
        System.out.println("Maximum sum of a subarray of size K: "
                + MaxSumSubArrayOfSizeK.maxSumFromSubArray(new int[] { 2, 1, 5, 1, 3, 2, 10 },3));
    }
}

/*
    class MaxSumSubArrayOfSizeK {
  public static int findMaxSumSubArray(int k, int[] arr) {
    int maxSum = 0, windowSum;
    for (int i = 0; i <= arr.length - k; i++) {
      windowSum = 0;
      for (int j = i; j < i + k; j++) {
        windowSum += arr[j];
      }
      maxSum = Math.max(maxSum, windowSum);
    }

    return maxSum;
  }

  public static void main(String[] args) {
    System.out.println("Maximum sum of a subarray of size K: "
        + MaxSumSubArrayOfSizeK.findMaxSumSubArray(3, new int[] { 2, 1, 5, 1, 3, 2 }));
    System.out.println("Maximum sum of a subarray of size K: "
        + MaxSumSubArrayOfSizeK.findMaxSumSubArray(2, new int[] { 2, 3, 4, 1, 5 }));
  }
}
 */