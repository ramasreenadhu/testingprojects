package educative.String;

import java.util.*;
//https://www.youtube.com/watch?v=8ZlmgBcQzMM

class NoRepeatSubstring {
    public static int lengthOfLongestSubstring(String s) {

        int maxCount = 0;
        int i = 0;
        int j = 0;
        int strLen = s.length();

        //Declare set of characters
        Set<Character> st = new HashSet<>();

        //Traverse a string
        while(i < strLen && j < strLen) {

            //If it's a unique character add in a set
            if(!st.contains(s.charAt(j))) {
                st.add(s.charAt(j));
                j++;
                maxCount = Math.max(maxCount, j-i);
            } else {
                st.remove(s.charAt(i));
                i++;
            }
        }

        return maxCount;
    }

    public static void main(String[] args) {

        String str = "abcabcbb";
        int len = lengthOfLongestSubstring(str);

        System.out.println(" Length " + len);
    }
}