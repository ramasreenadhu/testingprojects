package educative.twopinters;


/*
   Array should be sorted
   Input: [1, 2, 3, 4, 6], target=6
   Output: [1, 3]
   Explanation: The numbers at index 1 and 3 add up to 6: 2+4=6
 */

import java.util.HashMap;

public class PairwihTargetSum {

    public static int[] getPairFromTargetSum(int[] arr, int t){
       HashMap<Integer,Integer> hMap =new HashMap<Integer,Integer>();
       for(int i=0; i<arr.length;i++){
           if(hMap.containsKey(t-arr[i])){
               return new int[] { hMap.get(t - arr[i]), i };
           }
           hMap.put(arr[i],i);
       }
       return new int[] {-1,-1};
    }

    public static void main(String[] args) {
        int[] result = PairwihTargetSum.getPairFromTargetSum(new int[] { 1, 2, 3, 4, 6 }, 6);
        System.out.println("Pair with target sum: [" + result[0] + ", " + result[1] + "]");

        result = PairwihTargetSum.getPairFromTargetSum(new int[] { 2, 5, 9, 11 }, 11);
        System.out.println("Pair with target sum: [" + result[0] + ", " + result[1] + "]");
    }

}
