package educative.twopinters;

import java.util.Arrays;
import java.util.HashMap;

/*
    Input: [2, 3, 3, 3, 6, 9, 9]
   Output: 4
   Explanation: The first four elements after removing the duplicates will be [2, 3, 6, 9].
 */

public class RemoveDuplucate {

    public static HashMap<Integer,Integer>removeDuplicate(int[] arr){
        HashMap<Integer,Integer> hashMap= new HashMap<Integer,Integer>();
        int j=0;
        for(int i=0; i< arr.length;i++){
            if(!hashMap.containsKey(arr[i])){
                hashMap.put(arr[i],j);
                j++;
            }
        }
        return hashMap;
    }


    public static int removeElementFromArray(int[] arr, int element){
        int nonDuplicates=0;
        for( int i=0; i< arr.length; i++){
            if(arr[i]!=element){
                arr[nonDuplicates] = arr[i];
                nonDuplicates++;
            }
        }
        System.out.println(Arrays.toString(arr));
        return nonDuplicates;
    }



    public static void main(String[] args) {
        int[] arr = new int[] { 2, 3, 3, 3, 6, 9, 9 };
        HashMap<Integer,Integer> hashMap1 =RemoveDuplucate.removeDuplicate(arr);
        System.out.println(hashMap1);

        int[] arr1 = new int[] { 2, 3, 6, 9, 9};
        System.out.println(RemoveDuplucate.removeElementFromArray(arr1,3));

    }
}
