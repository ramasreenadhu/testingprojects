package educative.twopinters;

import java.util.Arrays;

/*
     Input: [-2, -1, 0, 2, 3]
     Output: [0, 1, 4, 4, 9]
 */

public class SortedArraySquares {

    public static int[] makeSequare(int[] arr){
        int[] newArr= new int[arr.length];

        for(int i=0; i< arr.length; i++){
            newArr[i] = arr[i] * arr[i];
        }

        Arrays.sort(newArr);
        return newArr;
    }

    public static int[] makeSquares2ndsolution(int[] arr) {
        int n = arr.length;
        int[] squares = new int[n];
        int highestSquareIdx = n - 1;
        int left = 0, right = arr.length - 1;
        while (left <= right) {
            int leftSquare = arr[left] * arr[left];
            int rightSquare = arr[right] * arr[right];
            if (leftSquare > rightSquare) {
                squares[highestSquareIdx--] = leftSquare;
                left++;
            } else {
                squares[highestSquareIdx--] = rightSquare;
                right--;
            }
        }
        return squares;
    }

    public static void main(String args[]){
        int[] result = SortedArraySquares.makeSequare(new int[] { -2, -1, 0, 2, 3 });
        System.out.println(Arrays.toString(result));

        int[] result1 = SortedArraySquares.makeSquares2ndsolution(new int[] { -2, -1, 0, 2, 3 });
        System.out.println(Arrays.toString(result1));
    }
}
