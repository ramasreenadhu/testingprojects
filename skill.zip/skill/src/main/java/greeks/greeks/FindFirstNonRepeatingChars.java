package greeks.greeks;

/*
   Input: "geeksforgeeks"
   output : f
 */

import java.util.HashMap;

public class FindFirstNonRepeatingChars {

    static final int NO_OF_CHARS = 256;
    static HashMap<Character, CountIndex> hm
            = new HashMap<Character, CountIndex>(NO_OF_CHARS);

    static void getCharCountArray(String str)
    {
        for (int i = 0; i < str.length(); i++) {
            if (hm.containsKey(str.charAt(i))) {
                hm.get(str.charAt(i)).incCount();
            }
            else {
                hm.put(str.charAt(i), new CountIndex(i));
            }
        }
    }

    static int firstNonRepeating(String str)
    {
        getCharCountArray(str);
        int result = Integer.MAX_VALUE, i;
        for (i = 0; i < str.length(); i++) {
            if (hm.get(str.charAt(i)).count == 1
                    && result > hm.get(str.charAt(i)).index) {
                result = hm.get(str.charAt(i)).index;
            }
        }

        return result;
    }
}
