package greeks.greeks;

import java.util.*;

public class StringExamples {

    /*
         swap first & last chars in String
     */

    public static String swapChars(String str){
        char[] ch =str.toCharArray();
        char temp;
        for(int i =0; i< ch.length; i++){
            int j=i;
            while(i<ch.length && ch[i]!=' '){
                i++;
            }
            temp =ch[i-1];
            ch[i-1]=ch[j];
            ch[j]=temp;
        }
        return new String(ch);
    }

    public static String reverseString(String str){
        StringBuffer buff = new StringBuffer(str);
        return buff.reverse().toString();
    }

    static void reverse(char[] a)
    {
        int i, n = a.length;
        char t;
        for (i = 0; i < n / 2; i++)
        {
            t = a[i];
            a[i] = a[n - i - 1];
            a[n - i - 1] = t;
        }
    }

    public static void descendingOrderString(String str){
        Arrays.sort(str.toCharArray());
        StringExamples.reverse(str.toCharArray());
    }

    public static boolean isNumber(String str){
          //char[] ch = str.toCharArray();
          for(int i=0; i< str.length(); i++){
              if(Character.isDigit(str.charAt(i))==false){
                  return false;
              }
          }
        return true;
    }

    /*
       Input: abc, k = 2
Output: 2
Possible substrings are {"ab", "bc"}

Input: aba, k = 2
Output: 3
Possible substrings are {"ab", "ba", "aba"}

Input: aa, k = 1
Output: 3
Possible substrings are {"a", "a", "aa"}
     */
    // Function to count number of substrings
    // with exactly k unique characters
   public static int countkDist(String str, int k)
    {
        int res = 0;
        int n = str.length();

        // To store count of characters from 'a' to 'z'
        int cnt[] = new int[26];
        for (int i = 0; i < n; i++)
        {
            int dist_count = 0;
            Arrays.fill(cnt, 0);
            for (int j=i; j<n; j++)
            {
                if (cnt[str.charAt(j) - 'a'] == 0)
                    dist_count++;
                cnt[str.charAt(j) - 'a']++;
                if (dist_count == k)
                    res++;
            }
        }

        return res;
    }

    // The words are separated by following characters: space (‘ ‘) or new line (‘\n’) or tab (‘\t’)
    public static int countWords(String str){

       int wc=1;

        for(int i=0; i< str.length(); i++){
           if(str.charAt(i)==' ' || str.charAt(i)=='\n' || str.charAt(i)=='\t'){
               wc++;
           }

       }
       return wc;
    }

    /*
          Input: "abcabcbb"
          Output: 3
          Explanation: The answer is "abc", with the length of 3.
     */

    public static int lengthOfLongestSubstring(String s) {
        int n = s.length(), ans = 0;
        Map<Character, Integer> map = new HashMap<>(); // current index of character
        // try to extend the range [i, j]
        for (int j = 0, i = 0; j < n; j++) {
            if (map.containsKey(s.charAt(j))) {
                i = Math.max(map.get(s.charAt(j)), i);
            }
            ans = Math.max(ans, j - i + 1);
            map.put(s.charAt(j), j + 1);
        }
        return ans;
    }

    public static void main(String args[]){
//       String str = "rama sreenadhu";
//       System.out.println(StringExamples.swapChars(str));

      // int cnt=  StringExamples.countkDist("aaa",2);
       //System.out.println(cnt);

        //String str = "rama sreenadhu \t krishna";
        //System.out.println(StringExamples.countWords(str));

        StringExamples.lengthOfLongestSubstring("abcabcbb");

    }
}