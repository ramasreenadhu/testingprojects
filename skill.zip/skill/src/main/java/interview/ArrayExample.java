package interview;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;

public class ArrayExample {

    // how to check array contains values
    public void arrayContainsVal(){

        //one way
        String[] VALUES = new String[] {"AB","BC","CD","AE"};
        System.out.println(Arrays.asList(VALUES).contains("AB"));

        //simple loop - other way
        boolean isPresent=false;

        for(String val: VALUES){
            if(val.equals("CD")){
                isPresent=true;
                break;
            }

            System.out.println("pass................................");

        }

        if(isPresent){
            System.out.println("present");
        }else{
            System.out.println("not present");
        }

        //java 8
//        boolean sInArray = Arrays.stream(VALUES).anyMatch("AB"::equals);
//        System.out.println(sInArray);
    }

    public static void main(String args[]){
        new ArrayExample().arrayContainsVal();
    }
}
