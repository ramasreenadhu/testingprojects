package interview;

import java.util.Comparator;

public class EmpIDComparatator implements Comparator<EmployeeD> {

    @Override
    public int compare(EmployeeD em, EmployeeD em1){

        if(em.getSalary()>em1.getSalary()){
            return -1;
        }else if(em.getSalary()==em1.getSalary()){
            return 0;
        }else {
            return 1;
        }
    }
}
