package interview;

public class EmployeeD {
    private int eNo;
    private String eName;
    private double salary;

    EmployeeD(int num,String name,double sal){
        this.eNo=num;
        this.eName=name;
        this.salary=sal;
    }

    public int geteNo() {
        return eNo;
    }

    public void seteNo(int eNo) {
        this.eNo = eNo;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
