package interview;

public class EmployeeData {

    private int empId;
    private String empName;

    EmployeeData(int id,String name){
        this.empId =id;
        this.empName = name;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }



}
