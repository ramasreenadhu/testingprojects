package interview;

import java.io.FileNotFoundException;
import java.io.IOException;

public class ExceptionHandling {

    public static void main(String[] args) {
        try{
            //testException(-5);
            testException(15);
        }catch(FileNotFoundException e){
            e.printStackTrace();
            System.out.println("Its FileNotFoundException..........");
        }catch(IOException e){
            e.printStackTrace();
            System.out.println("Its IOException..........");
        }finally{
            System.out.println("Releasing resources");
        }
       // testException(-15);
    }

    public static void testException(int i) throws FileNotFoundException, IOException{
       System.out.println("i value is................"+i);
        if(i < 0){
            FileNotFoundException myException = new FileNotFoundException("Negative Integer "+i);
            throw myException;
        }else if(i > 10){
            throw new IOException("Only supported for index 0 to 10");
        }

    }

}