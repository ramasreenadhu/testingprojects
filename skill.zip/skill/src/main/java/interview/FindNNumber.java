package interview;

public class FindNNumber {

    public static void main(String a[]){
        FindNNumber f = new FindNNumber();
        f.find(6);
    }

    private void find(int n) {

        int rem=0;
        int sum=0;
        for(int i=1; i<=n; i++){

            if(i==n){
                for(int k=0;k<n;k++) {
                    sum = sum + rem + 1 + k;

                }
                break;
            }




            for(int j=1; j<=i; j++){

                rem = rem+1;
            }
        }

        System.out.println(sum);
    }
}
