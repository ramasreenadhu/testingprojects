package interview;

import java.util.Date;

public class HamcrestExamples {
//Hamcrest is a library of matchers, which can be combined in to create flexible expressions of intent in tests. They've also been used for other purposes.

}
