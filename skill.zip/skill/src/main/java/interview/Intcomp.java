package interview;

import java.util.Comparator;

public class Intcomp implements Comparator<Integer> {

    @Override
    public int compare(Integer emp1, Integer emp2) {
        return emp2.intValue() - emp1.intValue();
    }
}
