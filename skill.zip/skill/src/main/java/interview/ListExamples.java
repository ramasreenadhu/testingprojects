package interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class ListExamples {

    public static void numberOfrepeatedElemntsinList(){
        ArrayList<String> animals = new ArrayList<String>();
        animals.add("bat");
        animals.add("owl");
        animals.add("bat");
        animals.add("bat");
        System.out.println("Freq of bat: "+ Collections.frequency(animals, "bat"));
    }

    public static void _numberOfrepeatedElemntsinList() {
        ArrayList<String> animals = new ArrayList<String>();
        animals.add("bat");
        animals.add("owl");
        animals.add("bat");
        animals.add("bat");
       HashMap<String, Integer> map = new HashMap<String, Integer>();
       for(String s : animals) {
           if (map.containsKey(s)){
               map.put(s,map.get(s)+1);
           }else{
               map.put(s,1);
           }
       }

        System.out.println(map);

    }

    public void sortArrayList(){
        ArrayList<String> animals = new ArrayList<String>();
        String temp = animals.get(0);
        for(int i=0; i<animals.size();i++){
            for(int j=1; j<animals.size();j++){
                if(animals.get(i).compareTo(animals.get(j))>0){
                     temp=animals.get(j);
                    //animals.get(i)=temp;
                }
            }
        }
    }

    public static void swap(List<Integer> sort, int i, int j) {
        int tmp = sort.get(i);
        sort.set(i, sort.get(j));
        sort.set(j, tmp);
    }

    public static void doSort(List<Integer> sort) {
        int min;
        for (int i = 0; i < sort.size(); ++i) {
            //find minimum in the rest of array
            min = i;
            for (int j = i + 1; j < sort.size(); ++j) {
                if (sort.get(j) < sort.get(min)) {
                    min = j;
                }
            }

            //do swap
            swap(sort, i, min);
        }
    }

    public static void main(String[] args){
        ListExamples._numberOfrepeatedElemntsinList();
    }
}
