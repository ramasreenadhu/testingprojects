package interview;

public class Student implements Comparable<Student> {
    public int getRollNum() {
        return rollNum;
    }

    public void setRollNum(int rollNum) {
        this.rollNum = rollNum;
    }

    private int rollNum;
    Student(int num){
        this.rollNum=num;
    }

    @Override
    public int compareTo(Student st){
       if(this.rollNum > st.rollNum){
           return 1;
       }else if(this.rollNum == st.rollNum){
           return 0;
       }else{
           return -1;
       }
    }
}
