package interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StudentTest implements Comparable<StudentTest> {

    private int sno;
    private String sName;

    StudentTest(int sno,String sName){
        this.sno=sno;
        this.sName=sName;
    }

    public int getSno() {
        return sno;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    @Override
    public int compareTo(StudentTest st){
       return  this.sno - st.sno;
    }

    public static void main(String args[]){
        StudentTest st1= new StudentTest(20,"krishna");
        StudentTest st2= new StudentTest(10,"rama");
        List<StudentTest> lists = new ArrayList<StudentTest>();
        lists.add(st1);
        lists.add(st2);
        Collections.sort(lists);
        System.out.println(lists.get(0).getsName().toString());
        Collections.sort(lists, new Comparator<StudentTest>() {
            @Override
            public int compare(StudentTest o1, StudentTest o2) {
                return o1.sName.compareTo(o2.sName);
            }
        });
        System.out.println(lists.get(0).getsName().toString());
    }

}
