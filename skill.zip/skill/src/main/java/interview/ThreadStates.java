package interview;

public enum ThreadStates {
    START,
    RUNNING,
    WAITING,
    DEAD;
}


