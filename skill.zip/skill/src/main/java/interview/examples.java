package interview;

//import com.test.printNumberWordsinStaring;
//import org.apache.commons.collections.bag.SynchronizedSortedBag;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import sun.jvm.hotspot.oops.Array;

import javax.swing.text.html.parser.Entity;
import java.io.UnsupportedEncodingException;
import java.util.*;


public class examples {

    public static void printCommonElementsFromArays(String[] arr, String[] arr1) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr1.length; j++) {
                if (arr[i].equals(arr1[j])) {
                    System.out.println(arr[i]);
                }
            }
        }
    }

    public static void printCommonElementsFromAraysUsingHashSet(String[] arr, String[] arr1) {
        HashSet<String> hashSet = new HashSet<String>(Arrays.asList(arr));
        HashSet<String> hashSet1 = new HashSet<String>(Arrays.asList(arr1));
        hashSet.retainAll(hashSet1);
    }

    public static boolean isNumber(String input) {
        try {
            Integer.parseInt(input); // refer Integer class lo parseInt methods
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    public static void EachCharCountInString(String str) {
        HashMap<Character, Integer> chr = new HashMap<Character, Integer>();
        char[] ch = str.toCharArray();
        int numCh;
        int len = ch.length;
        for (numCh = 0; numCh < len; numCh++) {
            if (chr.containsKey(ch[numCh])) {
                chr.put(ch[numCh], chr.get(ch[numCh]) + 1);
            } else {
                chr.put(ch[numCh], 1);
            }
        }
        System.out.println(chr);
    }

    // Prime numbers can never be an even number as even numbers are all divisible by 2.
    // so checking number is even or not
    public static boolean isPrimeBruteForce(int number) {
        for (int i = 2; 2 * i < number; i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean _isPrimeBruteForce(int number) {
        for (int i = 2; i < number / 2; i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void primeNum() {
        int num = 29;
        boolean flag = false;
        for (int i = 2; i <= num / 2; ++i) {
            // condition for nonprime number
            if (num % i == 0) {
                flag = true;
                break;
            }
        }

        if (!flag)
            System.out.println(num + " is a prime number.");
        else
            System.out.println(num + " is not a prime number.");
    }

    public static void fibonacci(int n) {
        int init1 = 0;
        int init2 = 1;
        System.out.println(init1);
        System.out.println(init2);
        for (int i = 1; i <= n; i++) {
            int sum = init1 + init2;
            System.out.println(sum);
            init1 = init2;
            init2 = sum;
        }
        //output: 0 1 1 2 3 5 8
    }

    public static void findCommonElementFromUnsortedArrays(Integer[] in1, Integer[] in2) {

        //Integer[] in = in1;
        //Integer[] din = in2;
        HashSet<Integer> hin = new HashSet<Integer>(Arrays.asList(in1));
        HashSet<Integer> hin1 = new HashSet<Integer>(Arrays.asList(in2));

        for (Integer c : hin) {
            if (!hin1.add(c)) {
                System.out.println(c);
            }
        }

    }

    public static void findUniqueArrayList(List<String> list) {
        Set<String> has = new HashSet<String>(list); // unique only
        System.out.println(has);
        Set<String> has1 = new TreeSet<String>(list); // unique + sorted
        System.out.println(has1);
    }

    public void printDuplicateNum(int[] in) {

        for (int i = 0; i < in.length - 1; i++) {
            for (int j = 1; j < in.length - 1; j++) {
                if (in[i] == in[j]) {
                    System.out.println("Duplicate Num is " + in[i]);

                }
            }
        }
    }

    public void printMaxTwoNumbers(int[] arr) {
        int maxOne = 0;
        int maxTwo = 0;

        for (int n : arr) {
            if (maxOne < n) {
                maxTwo = maxOne;
                maxOne = n;
            }
        }

        System.out.println(maxOne);
        System.out.println(maxTwo);
    }

//    public String printStringInReverseUsingRecursively(String str){
//        char a=str.charAt(str.length()-1);
//       // printStringInReverseUsingRecursively()
//    }

    public void checkGivenCharAlphabet(char ch) {
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            System.out.println("alphabet");
        } else {
            System.out.println("Not Alphabet");
        }

    }

    public void convertMapValToArrayList() {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("rama", 10);
        map.put("krishna", 20);
        map.put("sreenadhu", 1);

        List<String> ls = new ArrayList<String>(map.keySet());
        Collections.sort(ls);
        System.out.println(ls);

        List<Integer> ls1 = new ArrayList<Integer>(map.values());
        Collections.sort(ls1);
        System.out.println(ls1);
        // convert to Array 
        String[] targetArray = ls1.toArray(new String[ls1.size()]);


    }

    public void numberOfWords(String str) {
        Map<String, Integer> val = new HashMap<String, Integer>();
        String[] arrStr = str.split(" ");
        for (int i = 0; i < arrStr.length; i++) {
            if (val.containsKey(arrStr[i])) {
                val.put(arrStr[i], val.get(arrStr[i]).intValue() + 1);
            } else {
                val.put(arrStr[i], 1);
            }
        }

        System.out.println(val);
        Set<Map.Entry<String, Integer>> set = val.entrySet();
        ArrayList<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(set);
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });
        for (Map.Entry<String, Integer> entry : list) {
            System.out.println(entry.getKey() + " ==== " + entry.getValue());
        }
    }

    /*
      == compares the reference and should not be used for String comparison. Rather use methods equals() or equalsIgnoreCase() for string comparison.
     */

    public void stringCompare() {
        String s1 = new String("Hello");
        String s2 = "Hello";
        System.out.println(s1 == s2);   // false
    }


    public void printStringInReverseOrder() {
        String str = "abc";
        char[] arr = str.toCharArray();
        for (int i = 0; i < arr.length - 1; i++) {
            arr[i + 1] = arr[i];
            System.out.println(arr[i]);
        }
    }


    public void sortMapByKey() {
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        map.put("Rama", 100);
        map.put("Arishna", 100);
        map.put("Breenadhu", 100);
        map.put("Kamakrishna", 100);
        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(map.entrySet());
        Comparator<Map.Entry<String, Integer>> cmp = new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
        };
        Collections.sort(list,cmp);
        System.out.println(list);
    }

    public void printAvgArray(double[] darry){
        double total=0;
        for(int i=0; i< darry.length-1;i++){
            total=total+darry[i];
        }
        System.out.println("Avg:"+ total/darry.length);
    }

    public void printMaxValInArr(int[] arr){
        int max=arr[0];
        for(int i=0; i<arr.length;i++){
            if(max<arr[i]){
                max=arr[i];
            }
        }
        System.out.println(max);
    }

    public void armstrongExample(int n){ //  153 = 1*1*1 + 5*5*5 + 3*3*3
        int c=0, temp,a;
        temp=n;
        while(n>0){
            a=n%10;
            n=n/10;
            c=c+(a*a*a);
        }
        if(temp==c){
            System.out.println("its armstron number ");
        }
    }

    public void secondsmallestNum(Integer[] num){
        Arrays.sort(num);
        System.out.println(num[1]);
    }

    public void secondHighersttNum(Integer[] num){
        Arrays.sort(num,new Intcomp());
        System.out.println(num[1]);
    }

    public void sortArrayLowToHigh(int[] num){
        int temp;
        for(int i=0;i<num.length;i++){
             for(int j=i+1; j<num.length;j++){
                 if(num[j]<num[i]){
                     temp=num[i];
                     num[i]=num[j];
                     num[j]=temp;
                 }
             }
        }

        for(int k=0;k<num.length;k++){
            System.out.println(num[k]);
        }
    }

    public void binarySearchSortedArray(int[] num,int last,int val){
        int first=0;
        int mid=(first+last)/2;

        while(first<=last)
        if(num[mid] < val){
            first=mid+1;
        }else if(num[mid] > val){
            last=mid=1;
        }else if(num[mid]==val){
            System.out.println("index is : "+mid);
            break;
        }
        mid= (first+last)/2;
    }

    public void printMaxMinArray(int[] num){
        Arrays.sort(num);
        int s =num.length;
        int[] in =new int[s];
        for(int i=0;i<s;i++){
            in[i]=num[s-i];
        }
    }

    public void findDuplicateCharsInString(String str){
        Set s = new HashSet();
        StringBuilder sb = new StringBuilder();
        char[] ch =str.toCharArray();
        for(int i=0; i<ch.length;i++){
            if(s.add(ch[i])){
                sb.append(ch[i]);


            }
        }
        System.out.println(sb.toString());
    }

    public void checkAlphaNumeric(String str){
        char[] ch =str.toCharArray();
        boolean ischeckAlphaNumeric = false;
        for(int i=0;i<ch.length;i++) {
            if (Character.isAlphabetic(ch[i])) {
                ischeckAlphaNumeric =true;
            }
        }
        if(ischeckAlphaNumeric){
            System.out.println("String has AlphaNumeric");
        }else{
            System.out.println("String has no AlphaNumeric");
        }
    }

    public void checkPalindromeString(String str){
        char[] ch =str.toCharArray();
        String orgStr =str;
        StringBuilder actStr = new StringBuilder();

        for(int i=ch.length-1;i>=0;i--){
            actStr= actStr.append(ch[i]);
        }

        if(orgStr.equals(actStr.toString())){
            System.out.println("its PalindromeString");
        }else{
            System.out.println("its not PalindromeString");
        }
    }

    public void printByteToString(String str){
        byte[] bytes =str.getBytes();
        try {
           String str1 = new String(bytes,"UTF-8");
           System.out.println(str1);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public void palindromeNum(int[] num){


    }

    public void printFirstFiveElementsInLoop(int[] in){
        for(int i=0;i<in.length && i<5;i++){
            System.out.println(in[i]);
        }

        // other way
        for(int i = 1, len = Math.min(in.length, 5); i < len; i++){
            System.out.println(in[i]);
        }
    }

    public void printuniqueElementsFromArray(String[] in){
       Set<String> st = new HashSet<String>(Arrays.asList(in));
       System.out.println(st);
    }

    public void printNumberOfSundaysBtn1901To2000(){
        int count=0;
       Calendar cal=  Calendar.getInstance();
       for(int i =1901;i<2000;i++){
           for(int j=1;j<=12;j++) {
               cal.set(Calendar.YEAR, i);
               cal.set(Calendar.MONTH, j);
               cal.set(Calendar.DAY_OF_MONTH,1);
               if(cal.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY){
                   count++;
               }
           }
       }
       System.out.println(count);
    }

    public void printArraydescendingOrder(String[] str){
        Arrays.sort(str,Collections.reverseOrder());
        System.out.println(Arrays.toString(str));

        //other way
//        Comparator comparator = new Comparator() {
//
//            @Override
//            public int compare(Integer o1, Integer o2) {
//                return o2.compareTo(o1);
//            }
//        };
//        Integer[] array = new Integer[] { 9,1, 0, 7, 0, 0, 0, 5, 0 };
//        Arrays.sort(array, comparator);
//        System.out.println(Arrays.toString(array));
    }

    public void numberOfOcuurenceInString(String line, String c){
        System.out.println(line.length() - line.replace(c, "").length());
    }

    public static int countOccurrences(String haystack, char needle)
    {
        int count = 0;
        for (int i=0; i < haystack.length(); i++)
        {
            if (haystack.charAt(i) == needle)
            {
                count++;
            }
        }
        return count;
    }

    public static Object[] reverseAnArray(Object[] arr) {
        List<Object> list = Arrays.asList(arr);
        Collections.reverse(list);
        return list.toArray();
    }

    public void printWordsInString(String s){
        System.out.println(Arrays.asList(s.split("\\W+")));
    }

    public void _printStringInReverseOrder(String str){
        char[] chaArr =str.toCharArray();
        int j =chaArr.length-1;
        char ch;
        for(int i=0; j>0 && i<j;i++,j--){
         ch=chaArr[j];
         chaArr[j]=chaArr[i];
         chaArr[i]=ch;
        }
        System.out.println(Arrays.toString(chaArr));
    }

    public void findNumbersFromString(){
//        + Between one and unlimited times, as many times as possible, giving back as needed
//        -? One of the characters “-?”
//        0-9 A character in the range between “0” and “9”
        String str = "qwerty1qwerty2";
        str = str.replaceAll("[^0-9]+", " ");
        System.out.println(str);
    }

    public void printNumbersFromString(String str){
       char[] chr=  str.toCharArray();
       for(int i=0; i< chr.length-1;i++){
           if(Character.isDigit(chr[i])){
               System.out.println(chr[i]);
           }
       }
    }

    public void findMaxMinInArray(int[] in){
        int min = in[0];
        int temp;
        for(int i =1; i< in.length;i++){
            if(min>in[i]){
                temp=in[i];
                min=temp;
            }
        }
        System.out.println(min);

        //  Math.min(ret,values[i]); // 2nd way
    }

    public void printArrayToSet(String[] str){
        Set<String> st = new HashSet<String>(Arrays.asList(str));
        System.out.println(st);
        List<String> ls =new ArrayList<String>(st);
        Collections.sort(ls);
        System.out.println(ls);
        Collections.sort(ls, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o2.compareTo(o1);
            }
        });

        System.out.println(ls);

//        // iterate collections set,List using loop
//        for (String s : ls) {
//            System.out.println(s);
//        }
    }

    public void printHashMap(){
       Map<String,String> map= new HashMap<String,String>();
       map.put("rama","sreenadhu");
       map.put("krishna","xyz");
      Set<Map.Entry<String,String>> si = map.entrySet();
      for(Map.Entry<String,String> s:si){
          System.out.println(s.getKey()+" "+s.getValue());
      }
    }

    public void printListWithDifferentObjects(){
       List<Object> list = new ArrayList<Object>();
       list.add("rama");
       list.add(100);
       list.add("C");
       list.add(100.90);

       for(Object o: list){
           if(o instanceof Integer){
               System.out.println((((Integer) o).intValue()));
           }else if(o instanceof String){
               System.out.println(o.toString());
           }
       }
    }

    public void removeallNonAlphabetFromString(String str){
        str.replaceAll("[\\d]","");
    }

    public void findElementInList( ){
       List<String> str=  new ArrayList<String>();
       str.add("rama");
       str.add("krishna");
       Collections.sort(str);
       int i= Collections.binarySearch(str,"krishna");
       System.out.println(i);
    }
   /*

    */


   public void intToChar(int in){
       System.out.println((char)in);// output d
       System.out.println((double)in);
   }

   public void printStars(){
       for(int i=0; i<10;i++){
           for(int j=0; j<=i;j++){
               System.out.println("* ");
           }
       }
   }

   public void twoDArray(){
       String[][] str ={{"r","S"},{"E","S"},{"S","D"}};
       int[][] a = { {15, 25, 35}, {45, 55, 65} };  // 2 rows & 3 columns
       int i=0;

       for(int j=0; j<a[i].length-1; j++ ){

           System.out.println(a[i][j]);

           if(j==2){
               i++;
               j=0;
           }

       }

   }

   public void printBitWise(){
       int i =60;
       int j =13;
       System.out.println(i & j); // 12 //111100
       System.out.println(Integer.toBinaryString(i)); // 111100
       System.out.println(Integer.toBinaryString(j)); //

       //a = 0011 1100
       //b = 0000 1101

//       a&b = 0000 1100
//
//       a|b = 0011 1101
//
//       a^b = 0011 0001
//
//       ~a  = 1100 0011
   }

   public void printArrayInReverse(){

       int[] arr =new int[] {10,20,30,40};
       int temp,lastInt;
       for(int i =0; i<arr.length/2;i++){
           temp =arr[i];
           arr[i]=arr[arr.length-i-1];
           arr[arr.length-i-1] = temp;
       }
       System.out.println(Arrays.toString(arr));

       // 2nd way
//       List<Object> list = Arrays.asList(arr);
//       Collections.reverse(list);
   }

   public void printMaxValFromArray(){
       int[] arr =new int[] {10,20,30,40,-1};
       int minval= arr[0];
       for(int i =1; i< arr.length;i++){
           if(minval>arr[i]){
               minval=arr[i];
           }

       }

       System.out.println(minval);

   }

   public void printSortArray(){
       int[] arr =new int[] {10,20,30,40,-1};
       int sortedArr[] = new int[arr.length];
      ;
       for(int i=0; i< arr.length;i++){
           for(int j =0; j<arr.length;j++){
               if(arr[i]>arr[j]){
                   sortedArr[i] =  arr[j];
               }
           }
       }

       System.out.println(Arrays.toString(arr));
   }

   public void removeDuplicateElements(){
      List<String> list =  new ArrayList<String> ();
      list.add("rama");
      list.add("krishna");
      list.add("sreenadbhu");
      list.add("rama");
      Set<String> set = new HashSet<String>(list);
      System.out.println(Arrays.toString(set.toArray()));
   }

   public void print2DArray(){
       String[][] deepArray = new String[][] {{"John", "Mary",null}, {"Alice", "Bob",null}};
       for(int i=0; i< deepArray.length;i++){
           for(int j=0; j<deepArray[i].length;j++){
               if(deepArray[i][j]==null){
                   deepArray[i][j]="default";
               }
               System.out.println(deepArray[i][j]);
           }
       }
   }

  public void copyArray(){
    int[] a = {1,2,3,4,5};
    int[] b = Arrays.copyOf(a,a.length);
  }

   public void sortArray(){
       int[] array = {2, 3, 4, 5, 3, 4, 2, 34, 2, 56, 98, 32, 54};

       for (int i = 0; i < array.length; i++) {
           for (int j = 0; j < array.length; j++) {
               if (array[i] < array[j]) {
                   int temp = array[i];
                   array[i] = array[j];
                   array[j] = temp;
               }
           }
       }

       System.out.println(Arrays.toString(array)); //[2, 2, 2, 3, 3, 4, 4, 5, 32, 34, 54, 56, 98]
   }

   public int arrayIndexOfElement(int val){
       int[] array = {2, 3, 4, 5, 3, 4, 2, 34, 2, 56, 98, 32, 54};
       for(int i=0;i< array.length;i++)
           if(val==array[i]) return i;
               return -1;

       // other way

   }



   public void sortMapByVal(){
      Map<Integer,EmployeeData> map = new HashMap<Integer,EmployeeData>();
      map.put(1001,new EmployeeData(1001,"rama"));
      map.put(1002,new EmployeeData(1002,"krishna"));
      Set<Map.Entry<Integer,EmployeeData>> set= map.entrySet();
      List<Map.Entry<Integer,EmployeeData>> list = new ArrayList<Map.Entry<Integer,EmployeeData>>(set);
      Collections.sort(list, new Comparator<Map.Entry<Integer, EmployeeData>>() {
          @Override
          public int compare(Map.Entry<Integer, EmployeeData> o1, Map.Entry<Integer, EmployeeData> o2) {
              return o1.getValue().getEmpName().compareTo(o2.getValue().getEmpName());
          }
      });
   }

   public void printMatrix(){

       String[][] arry = new String[2][2];
   }

   public void printDulicateNumFromArray(){
       int[] num ={10,20,30,40,30,50};
       int j=0;
       for(int i =1; i<num.length-1;i++){
            if(num[j]==num[i]){
                System.out.println("Duplicate Number is .."+num[j]);
            }else if(num[j]!=num[i]){
                j++;
            }
       }
   }

    public void _printDulicateNumFromArrayUsingSet(){
        Integer[] num ={10,20,30,40,30,50};
        Set<Integer> dup = new HashSet<Integer>(Arrays.asList(num));
        System.out.println(dup);
    }

//    public void MinMaxValue(){
//        char[] a = {'3', '5', '1', '4', '2'};
//        List b = Arrays.asList(a);
//        System.out.println(Collections.min(b));
//        System.out.println(Collections.max(b));
//
//        // using streams
//        int[] tab = {12, 1, 21, 8};
//        int min = Arrays.stream(tab).min().getAsInt();
//        int max = Arrays.stream(tab).max().getAsInt();
//        System.out.println("Min = " + min);
//        System.out.println("Max = " + max);
//    }

    public void interSectionOfArrys(){
       Integer[] in1 ={10,20,30,40,50};
       Integer[] in2 ={10,30,70,80,90};
        Set<Integer> s1=new HashSet<Integer>(Arrays.asList(in1));
       Set<Integer> s2 =new HashSet<Integer>(Arrays.asList(in2));
       s1.retainAll(s2); // Delete the elements s1 that are not in s2
       Integer[] result= s1.toArray(new Integer[s1.size()]);
       System.out.println(result); // {10,30}
    }

    public void getShuffle(){
        Integer[] solutionArray = {1, 2, 3, 4, 5, 6, 6, 5, 4, 3, 2, 1};
        List<Integer> solution =Arrays.asList(solutionArray);
        Collections.shuffle(solution);
        System.out.println(solution);
    }

    public void checkArrayContainVal(){


    }

    public void removeElementDuringIteration(){
        List<Integer> elementList = new ArrayList<>();
        elementList.add(10);
        elementList.add(20);
        elementList.add(30);
        elementList.add(40);
        elementList.add(50);
        Iterator<Integer> elementListIterator = elementList.iterator();
        while (elementListIterator.hasNext()) {
            Integer element = elementListIterator.next();

            if((element > 45) || (element < 25)) {
                elementListIterator.remove();
            }
        }

        System.out.println(elementList);

    }


    public void print2ndHighestElement(){

    }

    public void missingNumsFromArray(){
        int[] input = { 1, 1, 2, 3, 5, 5, 7, 9, 9, 9 };
        int[] mis = new int[input.length];
        for(int i:input){
            mis[i]=1;
        }

        for(int i=0;i<mis.length;i++){
            if(mis[i]==0){
                System.out.println("Missing num:"+i);
            }
        }
    }

    public void printDuplicateCharacters(){
        String str = "geeksforgeeks";
        char[] characters = str.toCharArray();
        Map<Character, Integer> charMap = new HashMap<Character, Integer>();
        for (Character ch : characters) {
            if (charMap.containsKey(ch)) {
                charMap.put(ch, charMap.get(ch) + 1);
            }
            else {
                charMap.put(ch, 1);
            }
        }


        System.out.println(charMap);

        Set<Map.Entry<Character, Integer>> entrySet = charMap.entrySet();
        for (Map.Entry<Character, Integer> entry : entrySet) {
            if (entry.getValue() > 1) {
                System.out.printf("%s : %d %n", entry.getKey(), entry.getValue());
            }
        }
    }

    public void printStringInReverse(){
       // since String is Immutaable, string can't chage hence using stringbuilder
        final StringBuilder builder = new StringBuilder("1234");
        int length = builder.length();
        for (int i = 0; i < length / 2; i++) {
            final char current = builder.charAt(i);
            final int otherEnd = length - i - 1;
            builder.setCharAt(i, builder.charAt(otherEnd)); // swap
            builder.setCharAt(otherEnd, current);
        }
        System.out.println(builder.toString());
    }

    public void VowelCounter() {
        char[] letters = "Please enter some text".toCharArray();
        int count = 0;
        for (char c : letters) {
            switch (c) {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                    count++;
                    break;
                default:
            }
        }
        System.out.println(count);
    }

    public void _VowelCounter() {
        char[] letters = "Please enter some text".toCharArray();
        int count = 0;
        for(int i=0;i<letters.length;i++){
            if(letters[i]=='a' || letters[i]=='e' ||letters[i]=='i'|| letters[i]=='o' || letters[i]=='u') {
                count++;
            }
        }
        System.out.println(count);
    }

    public void sortListAlphabetsSensitive(){
     List<String> ls = new ArrayList<String>();
     ls.add("rama");
     ls.add("Sreenadhu");
     Collections.sort(ls, new sortImpl());
     System.out.println(ls);
    }

    public void howToSaveUniqueElementsInList(){
        List<String> oldList = new ArrayList<String>();
        oldList.add("rama");
        oldList.add("krishna");
        oldList.add("rama");
        System.out.println(oldList);
        List<String> newList = new ArrayList<String>(new HashSet<String>(oldList));
        System.out.println(newList);
    }

    public void mapExample(Map<String,Integer> map){
        System.out.println(map.getClass().getName());
        map.put("Zero",  0);
        map.put("One",   1);
        map.put("Two",   2);
        map.put("Three", 3);
        map.put("Four",  4);
        for (Map.Entry<String,Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }
    }

    public void printMap(){
        mapExample(new HashMap<String,Integer>());
        mapExample(new TreeMap<String,Integer>());
        mapExample(new LinkedHashMap<String,Integer>());

        /*

        LinkedHashMap: "with predictable iteration order [...] which is normally the order in which keys were inserted into the map (insertion-order)."
HashMap: "makes no guarantees as to the order of the map"
TreeMap: "is sorted according to the natural ordering of its keys, or by a Comparator"
i.e. it's a SortedMap


           java.util.HashMap          // unordered, results may vary
Three => 3
Zero => 0
One => 1
Four => 4
Two => 2
java.util.TreeMap          // ordered by String keys lexicographically
Four => 4
One => 1
Three => 3
Two => 2
Zero => 0
java.util.LinkedHashMap    // insertion order
Zero => 0
One => 1
Two => 2
Three => 3
Four => 4
         */
    }

   public void findingDuplicateElements(){
     List<String> ls = new ArrayList<String>();
     ls.add("Rama");
     ls.add("Rama");
     ls.add("krishna");
     System.out.println(ls);
    Set<String> st =  new HashSet<String>();
    for(String s:ls){
        if(st.add(s)){

        }else{
            System.out.println("Duplicate Elements: "+ s);
        }
    }

   }

   public void printDiffInSet(){
       // Given sets
       Set<Character> ab = new HashSet<Character>(Arrays.asList('a', 'b'));
       Set<Character> bc = new HashSet<Character>(Arrays.asList('b', 'c'));

// Symmetric difference of two sets
       Set<Character> intersection = new HashSet<Character>(ab);
       intersection.retainAll(bc); // -> [b]
       Set<Character> symmetricDifference = new HashSet<Character>(ab);
       symmetricDifference.addAll(bc);
       symmetricDifference.removeAll(intersection); // -> [a, c]
   }

   public void randomElementFromSET(){
       Set<Integer> set = new LinkedHashSet<Integer>(3);
       set.add(1);
       set.add(2);
       set.add(3);
       List asList = new ArrayList(set);
       Collections.shuffle(asList);
       System.out.println(asList.get(0));
   }

    public static void permutation(String str) {
        permutation("", str);
    }

    private static void permutation(String prefix, String str) {
        int n = str.length();
        if (n == 0) System.out.println(prefix);
        else {
            for (int i = 0; i < n; i++)
                permutation(prefix + str.charAt(i), str.substring(0, i) + str.substring(i+1, n));
        }
    }

    public static int[] getUnionOfTwoArrays(int[] a, int[] b){
//        a[] = {2, 10, 14, 19, 51, 71}
//        b[] = {2, 9, 19, 40, 51}
//        Union = {2, 9, 10, 14, 19, 40, 51}

        int u[] = new int[a.length+b.length];
        int i=0,j=0,k=0;
        boolean flag =true;
        while(flag){
            if(a[i] == b[j]){
                u[k] =b[j];
                k+=1;
                j+=1;
                i+=1;
            }
            else if(a[i]<b[j]){
                u[k]=a[i];
                k+=1;
                i+=1;
            }
            else{
                u[k]=b[j];
                k+=1;
                j+=1;
            }
            if(j==b.length){
                flag=false;
            }
        }
        return u;
    }

    public static void removeNullFromList(){
        List<String> list = new ArrayList<String>();

        list.add("s1");
        list.add("s2");
        list.add(null);
        list.add("s3");
        list.add(null);
        list.add("s4");

        System.out.println(list);
        list.removeAll(Collections.singleton(null));
        System.out.println(list);
    }

    public static void countOccuranceOfCharsInString(){
       String mat ="abcdabh";
       int count =0;
       char[] ch = mat.toCharArray();
       for(int i=0;i<ch.length;i++){
           if(ch[i]=='a'){
               count= count+1;
           }
        }
        System.out.println(count);
    }

    public static void reverseStr(){
       String res ="rama";
       char[] ch = res.toCharArray();
       char[] nch =new char[ch.length];
       int j=0;
       for(int i=res.length()-1; i>=0; i--){
           nch[j] = ch[i];
           j++;
       }

       System.out.println(nch);

    }

    public static void permtations(){
       String str ="abc";

    }

    public static void _printMatrix(){

    }


//    Running output of string "abcd":
//
//    Step 1: Merge [a] and b: [ba, ab]
//
//    Step 2: Merge [ba, ab] and c: [cba, bca, bac, cab, acb, abc]
//
//    Step 3: Merge [cba, bca, bac, cab, acb, abc] and d: [dcba, cdba, cbda, cbad, dbca, bdca, bcda, bcad, dbac, bdac, badc, bacd, dcab, cdab, cadb, cabd, dacb, adcb, acdb, acbd, dabc, adbc, abdc, abcd]

    public static void main(String args[]){
//        String[] str ={"rama","krishna","sreenadhu"};
//        System.out.println(str.length); // 3
//        String[] str1={"rama","krishna","sreenadhu","yuwanth","ratheesh"};
//        examples.printCommonElementsFromArays(str1,str);
//        examples.printCommonElementsFromAraysUsingHashSet(str1,str);

        //==============================================================
       // System.out.println(isNumber("100"));
        //System.out.println(Integer.parseInt("33",16)); // (3)*16^1 + (3)*16^0 = 51,
        //Runtime.getRuntime().exec();

        //==============================================================
        //String str= "Java Java Java";
        //new examples().EachCharCountInString(str);
        //==============================================================

        //System.out.println(new examples()._isPrimeBruteForce(19));
        //examples.fibonacci(7);
//        Integer[] in ={10,20,30,40,50,60,70,80};
//        Integer[] in1 ={10,20,30,10};
//
//        examples.findCommonElementFromUnsortedArrays(in,in1);
//        String[] str ={"Rama","krishna","sreenadhu","rama","Rama"};
//        examples.findUniqueArrayList(Arrays.asList(str));
        //int [] in={1,2,1,1};
        //new examples().printDuplicateNum(in);
        //new examples().printMaxTwoNumbers(new int[]{23,34,10,119});
        //new examples().checkGivenCharAlphabet('<');
        // new examples().convertMapValToArrayList();

        //String str ="Rama Krishna Rama Sreenadhu Krishna";
        //new printNumberWordsinStaring().numberOfWords(str);
        //new examples().sortMapByKey();
        //new examples().printAvgArray(new double[]{10.20,20.90,12.9});
        //new examples().printMaxValInArr(new int[]{101,300,40,60,2000});
//        String paymentDate="10";
//        paymentDate=paymentDate.startsWith("0")? paymentDate.substring(1):paymentDate;
//        System.out.println(paymentDate);
      //  new examples().armstrongExample(153);
        //new examples().secondsmallestNum(new Integer[]{10,20,9,1,8});
       // new examples().sortArrayLowToHigh(new int[] {10,2,0,14});
        new examples().binarySearchSortedArray(new int[] {10,11,12},4,12);
        //new examples().findDuplicateCharsInString("RAMAKrishna");
        //new examples().checkAlphaNumeric("^^^@#$");
       // new examples().checkPalindromeString("abccba");
        //new examples().printByteToString("rama");
        //new examples().printFirstFiveElementsInLoop(new int[]{10,20,30,40,50,60,70,80});
        //new examples().printuniqueElementsFromArray(new String[]{"rama","rama","krishna","krishna"});
       // new examples().printNumberOfSundaysBtn1901To2000();
        //new examples().printArraydescendingOrder(new String[]{"rama","rama","krishna","krishna"});
        //new examples().numberOfOcuurenceInString("abcabd","c");
        //new examples().printWordsInString("Rama S Krishna");
        //new examples()._printStringInReverseOrder("Rama");
        //new examples().printNumbersFromString("Ram1027Rama");
        //new examples().findMaxMinInArray(new int[]{10,90,1,-1,9,100,290});
        //new examples().printArrayToSet(new String[]{"rama","krishna","sreenadhu"});
        //new examples().printHashMap();
        //new examples().printListWithDifferentObjects();
        //new examples().findElementInList();
        //new examples().intToChar(100);
        //new examples().printArrayInReverse();
        //new examples().printMaxValFromArray();
        //new examples().removeDuplicateElements();
        //new examples().arrayIndexOfElement(3);
        //new examples().sortMapByVal();

         //System.out.println("7th".substring(0,1));
         //https://stackoverflow.com/questions/22572617/number-patterns-using-loops-in-java
      //new examples().interSectionOfArrys();
       // new examples().sortListAlphabetsSensitive();
        //new examples().randomElementFromSET();
        //examples.permutation("rama");
       // System.out.println(new Random().nextInt(5));
        //System.out.println(System.getProperty("user.dir")+"/test/resources/conf/");
        //examples.countOccuranceOfCharsInString();
        examples.reverseStr();
    }


}
