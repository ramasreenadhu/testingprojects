package interview;

import java.util.ArrayList;
import java.util.List;

public class fndDuplicateNumber  {

    public static void main(String a[]){
        List<Integer> numbers = new ArrayList<Integer>();
        for(int i=1;i<30;i++){
            numbers.add(i);
        }
        //add duplicate number into the list
        numbers.add(22);
        //DuplicateNumber dn = new DuplicateNumber();
       // System.out.println("Duplicate Number: "+dn.findDuplicateNumber(numbers));
    }
}
