package interview;

public class forloopexp {

    // loop with condition
//    for (int i = 0; 4 > i && i < banners.size() ; i++) {
//    }

    // loop inside condition

//    for (int i = 0; i < banners.size() ; i++) {
//        if(4 > i){
//            continue;
//        }
//    }

}
