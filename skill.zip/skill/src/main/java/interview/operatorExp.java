package interview;

public class operatorExp {
//    int var = 0;
//System.out.println(var++); // returns 0;
//
//    var = 0;
//System.out.println(++var); // returns 1
}
