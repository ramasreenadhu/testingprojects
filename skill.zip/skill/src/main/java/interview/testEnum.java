package interview;

public class  testEnum {

    public static void testemuns(ThreadStates th){
        if(th==ThreadStates.START){
            System.out.println("its START..");
        }
    }
    public static void main(String args[]){
        testEnum.testemuns(ThreadStates.START);
    }
}


