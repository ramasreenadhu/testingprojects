package leetcode;

import java.util.Arrays;

public class Aug09 {

     /*
         Input:"abccccdd"
         Output: 7
         Explanation:
              One longest palindrome that can be built is "dccaccd", whose length is 7.
      */

        public int longestPalindrome(String s) {
            int[] count = new int[128];
            for (char c: s.toCharArray())
                count[c]++;
            System.out.println(Arrays.toString(count));
//[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 4, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            int ans = 0;
            for (int v: count) {
                ans += v / 2 * 2;
                if (ans % 2 == 0 && v % 2 == 1)
                    ans++;
            }
            System.out.println(ans);
            return ans;
        }

    public static void main(String args[]){

    }
}
