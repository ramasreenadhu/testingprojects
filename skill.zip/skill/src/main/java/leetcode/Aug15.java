package leetcode;

public class Aug15 {

    /*
Input: nums = [2,4,5,5,5,5,5,6,6], target = 5
Output: true
Explanation:
The value 5 appears 5 times and the length of the array is 9.
Thus, 5 is a majority element because 5 > 9/2 is true.

Input: nums = [10,100,101,101], target = 101
Output: false
Explanation:
The value 101 appears 2 times and the length of the array is 4.
Thus, 101 is not a majority element because 2 > 4/2 is false.
     */

    public boolean isMajorityElement(int[] nums, int target) {
        int highest = findIndex(nums, target, true);
        if (highest == -1) return false;
        int lowest = findIndex(nums, target, false);

        return highest - lowest + 1 > nums.length / 2;
    }

    private int findIndex(int[] nums, int target, boolean isHighIndex) {
        int low = 0;
        int high = nums.length - 1;
        int mid = 0;
        int index = -1;
        while (low <= high) {
            mid = low + (high - low) / 2;
            if (nums[mid] == target) {
                index = mid;
                if (isHighIndex) {
                    low = mid + 1;
                } else {
                    high = mid - 1;
                }
            } else if (nums[mid] > target) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        return index;
    }


    /*
Input: [5,7,3,9,4,9,8,3,1]
Output: 8
Explanation:
The maximum integer in the array is 9 but it is repeated. The number 8 occurs only once, so it's the answer.
     */

    public int largestUniqueNumber(int[] A) {
        int res = -1;
        int[] temp = new int[1001];
        for(int i = 0; i < A.length; i++) {
            temp[A[i]]++;
        }
        for(int i = temp.length-1; i >= 0; i--) {
            if(temp[i] == 1) {
                res = i;
                break;
            }
        }
        return res;
    }


    public static void main(String args[]){
        System.out.println(new Aug15().isMajorityElement(new int[]{2,4,5,5,5,5,5,6,6},5));
        System.out.println(new Aug15().isMajorityElement(new int[]{10,100,101,101},4));
    }
}
