package leetcode;

public class Aug18 {
    /*
       Given a sorted array and a target value, return the index if the target is found. If not, return the index where it would be if it were inserted in order.
                  Input: [1,3,5,6], 5
                  Output: 2

                  Input: [1,3,5,6], 2
                  Output: 1
     */

    public int __searchInsert(int[] arr, int target){

        int low = 0, high = arr.length-1;
        while(low<=high){
            int mid = (low+high)/2;
            if(arr[mid] == target) return mid;
            else if(arr[mid] > target) high = mid-1;
            else low = mid+1;
        }
        return low;
    }

    public int searchInsert(int[] nums, int target) {
        for(int i = 0; i < nums.length; i++){
            if(target <= nums[i]) return i;
        }
        return nums.length;
    }

    public int _searchInsert(int[] nums, int target) {
        int result = 0 ;
        int max = nums[nums.length-1];
        int min = nums[0];
        if (target > max) {
            result = nums.length;
        }
        if (target < min) {
            result = 0;
        }
        for (int i = 0; i <= nums.length-1; i++) {
            if (target == nums[i]) {
                result = i;
            }
            if (target > nums[i] && target < nums[i+1]) {
                result = i + 1;
            }
        }
        return result;
    }

    /*
        Input: [-2,1,-3,4,-1,2,1,-5,4],
        Output: 6
        Explanation: [4,-1,2,1] has the largest sum = 6.
     */


    public static void main(String args[]){
        //System.out.println(new Aug18()._searchInsert(new int[]{1,2,3,5},4));
        String loanType="OneClick Loan Offer";
        System.out.println(loanType.indexOf("O"));
    }
}

