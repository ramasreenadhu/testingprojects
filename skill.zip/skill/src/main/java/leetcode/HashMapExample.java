package leetcode;


import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class HashMapExample {

    public static void callHaspMapMethods(){
        Map<String,String> map= new HashMap<String,String>();
        map.put("Sreenadhu", "Rama");
        map.put("123", "456");
        map.put("123", "890");
        map.put("345", "890");// doesn't allow duplicate keys

        System.out.println(map.get("123")); // return 890
        System.out.println(map.get("345")); // return 890

        System.out.println(map.containsKey(null)); // returns false
        System.out.println(map.containsValue("890")); // returns true

        System.out.println( map.put("Sreenadhu","Rama")=="Rama"); // return Value

        Set<Entry<String, String>> entrySet = map.entrySet();
        System.out.println(entrySet); // return set

        System.out.println(map.get("Krishna"));  // return value
        System.out.println(map.get("abc"));  // returns null if key doesn't exist

        System.out.println(map.remove("Sreenadhu")); // returns Value

        Set<String> keySet = map.keySet();
        System.out.println("map keys = " + keySet);

        Collection<String> values = map.values();
        System.out.println("map values = " + values);
    }

    public static void main(String args[]){
        HashMapExample.callHaspMapMethods();
    }
}
