package leetcode;

public class Jan31 {
    /*
        String s1 = "Geeks";
        s1=s1+"forgeeks"  // s1 is not changed (Immutable)
        System.out.println("String: " + s1);

        StringBuilder s2 = new StringBuilder("Geeks");
        s2.append("forgeeks") // s2 is changed (mutable) (modifiedable)
        System.out.println("StringBuilder: " + s2);

        StringBuffer s3 = new StringBuffer("Geeks");
        s3.append("forgeeks")  // s3 is changed
        System.out.println("StringBuffer: " + s3);
Output:
String: Geeks
StringBuilder: Geeksforgeeks
StringBuffer: Geeksforgeeks

     */

    public String removeVowels(String str){

        StringBuilder sb = new StringBuilder();

      for(int i=0;i<str.length();i++){
          if(str.charAt(i)!='a' && str.charAt(i)!='e' && str.charAt(i)!='i'&& str.charAt(i)!='o'&& str.charAt(i)!='u'){
              sb.append(str.charAt(i));
          }
      }
        return sb.toString();
    }

    public static void main(String args[]){
       String mStr = new Jan31().removeVowels("rama");
       System.out.println(mStr);
    }

}

