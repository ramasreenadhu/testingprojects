package leetcode;

public class July01 {

    public int removeDuplicateElementsFromSortedArray(int num[]){
        if (num.length == 0) return 0;
        int i=0;
        for(int j=1;j<num.length;j++){
            if(num[j]!=num[i]){
                i++;
                num[i] = num[j];
            }
        }
        return i+1;
    }


    public static void main(String args[]){
        int num[] = new int[]{10,10,20,20,20,30,40,40,50,50};
        int len = new July01().removeDuplicateElementsFromSortedArray(num);
        System.out.println(len);
    }
}
