package leetcode;

import java.util.Arrays;

public class July05 {

    public int[] rotateArray(int[] arr, int k){
        if(arr==null || arr.length==0) return  arr;
        int a= arr.length;
        int[] arr1= new int[a];
        int i=0;
        int l =k;
        int m=l;

        for (i = 0; k < arr.length; i++) {
                arr1[i] = arr[k];
                k++;

        }

//        for(int j=0; j<l;j++){
//            m++;
//            arr1[m] =arr[j];
//        }

        return arr1;
    }

    public static void main(String args[]){
        System.out.println(Arrays.toString(new July05().rotateArray(new int[]{1,2,3,4,5,6,7}, 5)));
    }
}
