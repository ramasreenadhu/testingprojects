package leetcode;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class July13 {
    public boolean containsDuplicates(int arr[]){
        Arrays.sort(arr);
        for(int i=0; i<arr.length-1;i++){
            if(arr[i]==arr[i+1]){
                return true;
            }
        }
        return false;
    }

    public boolean containsDuplicate(int[] nums) {
        Set<Integer> set = new HashSet<>(nums.length);
        for (int x: nums) {
            if (set.contains(x)) return true;
            set.add(x);
        }
        return false;
    }


    public static void main(String args[]){
        int[] arr ={10,20,50,30,40};
        System.out.println(new July13().containsDuplicates(arr));
    }
}
