package leetcode;

import java.util.LinkedList;
import java.util.Queue;

public class July14 {

/*
Input:

          4
        /    \
        2     7
        / \   / \
        1  3  6   9

 Output:

         4
        /   \
        7     2
        / \   / \
        9   6 3   1
 **/

    public Node invertTree(Node root) {
        if (root == null) return null;
        Queue<Node> queue = new LinkedList<Node>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node current = queue.poll();
            Node temp = current.left;
            current.left = current.right;
            current.right = temp;
            if (current.left != null) queue.add(current.left);
            if (current.right != null) queue.add(current.right);
        }
        return root;
    }

    /*
      Input: 1->2->3->4->5->NULL
      Output: 5->4->3->2->1->NULL
     */

    public ListNode reverseList(ListNode head) {
        ListNode prev = null;
        ListNode curr = head;
        while (curr != null) {
            ListNode nextTemp = curr.next;
            curr.next = prev;
            prev = curr;
            curr = nextTemp;
        }
        return prev;
    }

}




