package leetcode;

import java.util.Arrays;

public class July16 {

    /*
       Input: [1,2,3,4,5,6,7] and k = 3
       Output: [5,6,7,1,2,3,4]
Explanation:
rotate 1 steps to the right: [7,1,2,3,4,5,6]
rotate 2 steps to the right: [6,7,1,2,3,4,5]
rotate 3 steps to the right: [5,6,7,1,2,3,4]
     */
    public void rotate(int[] nums, int k) {
        int[] a = new int[nums.length];
        for (int i = 0; i < nums.length; i++) {
            a[(i + k) % nums.length] = nums[i];
        }
        for (int i = 0; i < nums.length; i++) {
            nums[i] = a[i];
        }
    }

    public void printDuplicateElementsFromArray(int[] aa){
        Arrays.sort(aa);
        int i=0;
        for(int j=1; j<aa.length;j++){
            if(aa[i]==aa[j]){
                System.out.println(aa[i]+" is duplicate element");
            }
            i++;
        }
    }

    public static void main(String args[]){
        int[] a = new int[]{10,20,20,30,30,40,100,50,40};
        new July16().printDuplicateElementsFromArray(a);
    }
}
