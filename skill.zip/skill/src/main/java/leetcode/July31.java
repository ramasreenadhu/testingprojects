package leetcode;

public class July31 {

    /*
      find the contiguous subarray
      Input: [-2,1,-3,4,-1,2,1,-5,4],
      Output: 6
      Explanation: [4,-1,2,1] has the largest sum = 6.
     */

    public int findMaximunSumFromArray(int[] nums){
        int currMax=nums[0],max=nums[0];
        for(int i=1;i<nums.length;i++){
            currMax=Math.max(currMax+nums[i],nums[i]);
            max=Math.max(max,currMax);
        }
        return max;
    }

    public int lengthLastWord(String str){
        String[] arrStr = str.split(" ");
        int len = arrStr.length;
        return arrStr[len-1].length();
    }

    /*
         Input: [1,3,5,6], 5
         Output: 2
     */

    public int searchInsert(int[] nums, int target) {
        int i = 0;
        for ( ; i<nums.length; ) {
            if (nums[i]<target) {
                i++;
            }
            else {
                return i;
            }
        }
        return i;
    }

    public static void main(String args[]){
        //int max= new July31().findMaximunSumFromArray(new int[]{-2,1,-3,5});
       // System.out.println(max);

        //System.out.println(new July31().lengthLastWord("Hello World ra"));

        //int i= new July31().searchInsert(new int[] {10,30,50,90},30);
        //System.out.println(i);
        System.out.println("ramakris".indexOf("rama"));
    }
}
