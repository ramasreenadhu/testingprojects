package leetcode;

public class June03 {

    public int binarySearch(int[] val, int target){
        int left=0, right = val.length-1;
        int mid=0;
        while(left<=right) {
            mid =(left+right)/2;
            if(val[mid]==target) return mid;
            mid = (left+right)/2;
            if (target < val[mid]) right = right - 1;
            else
                left = left + 1;
        }
        return mid;
    }

    public static void main(String args[]){
        int[] num =new int[]{-1,0,3,5,9,12};
        System.out.println(new June03().binarySearch(num,9));
    }
}
