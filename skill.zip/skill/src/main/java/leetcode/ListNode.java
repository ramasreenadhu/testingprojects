package leetcode;

public class ListNode {

    int val;
    ListNode next;
    public ListNode(int x) { val = x; }
}
