package leetcode;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class May14 {

    /*
       Given nums = [2, 7, 11, 15], target = 9,
       Because nums[0] + nums[1] = 2 + 7 = 9,
       return [0, 1].
     */

    public int[] twoSum(int[] a, int target){
        Map<Integer,Integer> map =new HashMap<Integer,Integer>();
        for(int i=0; i<a.length;i++){
            int ex =target - a[i];
            if(map.containsKey(ex)){
               return new int[]{map.get(ex),i};
            }
            map.put(a[i],i);
        }
        throw new IllegalArgumentException("No two sum solution");
    }

    public int reverseNum(int num){
        int res=0;
        int pop=0;
        while(num!=0){
            pop = num%10; // reminder
            num = num/10; //right hand
            res = res*10+pop;
        }
        return res;
    }

    public static void main(String args[]){

     int[] b = new May14().twoSum(new int[]{2, 5, 1, 0}, 9);
     System.out.println(Arrays.toString(b));

      //int resv= new May14().reverseNum(878);
      //System.out.println(resv);
    }
}
