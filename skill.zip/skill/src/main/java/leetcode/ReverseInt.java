package leetcode;


public class ReverseInt {

    public static int reverserIntVal(int x){
        int rev = 0;
        while(x!=0) {
            int pop = x % 10;
            x = x / 10;
            rev = rev * 10 + pop;
        }
       return rev;
    }

    public static void main(String args[]){
       int rev= ReverseInt.reverserIntVal(123);
        System.out.println(rev);
    }

}


