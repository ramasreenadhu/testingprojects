package leetcode;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class RomanToIntTest {

    /*
         Input: "LVIII", Output: 58 , Explanation: L = 50, V= 5, III = 3.
         Input: "MCMXCIV", Output: 1994 , Explanation: M = 1000, CM = 900, XC = 90 and IV = 4.
         hint1: I - 1 V - 5 X - 10 L - 50 C - 100 D - 500 M - 1000
         hint2: Rules:* If I comes before V or X, subtract 1 eg: IV = 4 and IX = 9
                      * If X comes before L or C, subtract 10 eg: XL = 40 and XC = 90
                      * If C comes before D or M, subtract 100 eg: CD = 400 and CM = 900
     */


        static Map<String, Integer> values = new HashMap<>();

        static {
            values.put("M", 1000);
            values.put("D", 500);
            values.put("C", 100);
            values.put("L", 50);
            values.put("X", 10);
            values.put("V", 5);
            values.put("I", 1);
        }

        public int romanToInt(String s) {

            int sum = 0;
            int i = 0;
            while (i < s.length()) {
                String currentSymbol = s.substring(i, i + 1);
                int currentValue = values.get(currentSymbol);
                int nextValue = 0;
                if (i + 1 < s.length()) {
                    String nextSymbol = s.substring(i + 1, i + 2);
                    nextValue = values.get(nextSymbol);
                }

                if (currentValue < nextValue) {
                    sum += (nextValue - currentValue);
                    i += 2;
                }
                else {
                    sum += currentValue;
                    i += 1;
                }

            }
            return sum;
        }

       /*
           The entire logic for reversing a string is based on using the opposite directional two-pointer approach!
           picture available in notepad leetcodepics
        */

    public void reverseString(char[] s) {
        int left = 0, right = s.length - 1;
        while (left < right) {
            char tmp = s[left];
            s[left++] = s[right];
            s[right--] = tmp;
        }
        System.out.println(Arrays.toString(s));
    }


    /*

     */

        public static void main(String args[]){
           // int sum = new Mar28().romanToInt("MCMXCIV");
           // new Mar28().reverseString(new char[]{'h','e','l','l','o'});

        }
    }
