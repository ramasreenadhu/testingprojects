package leetcode.StringLeetcode;

public class AddBinary {
    public static String addBinary(String num1, String num2){
        if(num1==null && num2==null){
            return null;
        }
        StringBuffer sb = new StringBuffer();
        int sum=0;
        int carry=0;
        int i =num1.length()-1;
        int j= num2.length()-1;
        while(i>=0 && j>=0){
            sum=carry;
            if(i>=0) sum=sum+num1.charAt(i--)-'0';
            if(j>=0) sum=sum+num2.charAt(j--)-'0';
            sb.append(sum%10);
            carry = sum/10;
        }

        if(carry==1){
            sb.append("1");
        }

        return sb.reverse().toString();
    }

    public static void main(String args[]){
        System.out.println(AddBinary.addBinary("11","1"));
    }
}
