package leetcode.StringLeetcode;

import java.util.Stack;

public class ValidateParenthesys {

    Stack<Character> st = new Stack<>();
    public boolean isValidParehthesys(String input){
        if(input.length()==0){
            return false;
        }

        char[] ch = input.toCharArray();
        for(int i=0; i<ch.length;i++){
            if(ch[i]=='{' || ch[i]=='[' || ch[i]=='('){
                st.push(ch[i]);
            }else{
                if(!st.isEmpty() && isValid(st.peek(),ch[i])){
                    st.pop();
                }else{
                    return false;
                }
            }
        }
       return st.isEmpty();
    }

    public boolean isValid(char ch1, char ch2){
        return ch1=='{' && ch2=='}' || ch1=='[' && ch2==']' || ch1=='(' && ch2==')';
    }

    public static void main(String args[]){
       System.out.println(new ValidateParenthesys()
               .isValidParehthesys("{[]}}"));
    }

}
