package leetcode.arrays;

import java.util.HashMap;
import java.util.Map;

/*
Input: nums = [1,2,3,1], k = 3
Output: true
https://www.youtube.com/watch?v=Fmmzy5Jg-Mw
at most mean <=K
*/
public class ContainsDuplicateII {
    public static boolean containsNearbyDuplicate(int[] nums, int k) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            if (map.containsKey(nums[i]) && (i - map.get(nums[i])) <= k) {
                return true;
            }
            map.put(nums[i], i);
        }
        return false;
    }

    public static void main(String args[]){
      boolean result = ContainsDuplicateII.containsNearbyDuplicate(new int[]{1,2,3,1},3);
       System.out.println(result);
    }
}
