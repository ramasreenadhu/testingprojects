package leetcode.arrays;

/*
F(0) = 0,   F(1) = 1
F(N) = F(N - 1) + F(N - 2), for N > 1.

 */

public class FibonacciNumber {

    public static int fib(int N) {
        if(N==0){
            return 0;
        }
        if(N==1){
            return 1;
        }
        int[] fibonacciNumber = new int[N+1];
        fibonacciNumber[0] = 0;
        fibonacciNumber[1] = 1;
        for(int i = 2; i < N+1; i++){
            fibonacciNumber[i] = fibonacciNumber[i-1] + fibonacciNumber[i-2];
        }
        return fibonacciNumber[N];
    }

    public static void main(String args[]){
       int rrs= FibonacciNumber.fib(10);
       System.out.println(rrs);
    }
}
