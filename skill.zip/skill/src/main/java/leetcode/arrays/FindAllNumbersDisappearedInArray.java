package leetcode.arrays;

/*
Input:
[4,3,2,7,8,2,3,1]
subtract with 1 [4,3,2,7,8,2,3,1]
Output:
[5,6]

https://www.youtube.com/watch?v=CTBEcmzLAuA
*/

import java.util.*;

public class FindAllNumbersDisappearedInArray {
    public static List<Integer> findDisappearedNumbers(int[] a) {
        int[] count = new int[a.length+1];
        for(int i : a) {
            count[i]++;
        }

        List<Integer> res = new ArrayList<>();
        for(int i=1; i<count.length; i++) {
            if(count[i] == 0) res.add(i);
        }
        return res;
    }

    public static void main(String args[]){
        //FindAllNumbersDisappearedInArray.findDisappearedNumbers(new int[]{4,3,2,7,8,2,3,1});
    }
}
