package leetcode.arrays;

public class FindPivotIndex {
    /*
        pivot index as the index where the sum of all the numbers to the left of the index is
        equal to the sum of all the numbers to the right of the index.

        Input: nums = [1,7,3,6,5,6]
        Output: 3
        Explanation:
The sum of the numbers to the left of index 3
(nums[3] = 6) is equal to the sum of numbers to the right of index 3.
Also, 3 is the first index where this occurs.
    */
    // https://www.youtube.com/watch?v=wKXEviRbLtY
    public static int pivotIndex(int[] nums) {
        int totalSum=0, leftSum=0, rightSum=0;
        for(int i=0; i< nums.length; i++){
            totalSum = totalSum+nums[i];
        }
        for(int j=0; j<nums.length ;j++){
            rightSum = totalSum - leftSum -nums[j];
            if(rightSum==leftSum){
                return j;
            }
            leftSum = leftSum+nums[j];

        }
        return -1;
    }

    public static void main(String args[]){
        System.out.println("qatester+9980306326@tlcqa.com".replaceAll("\\D+",""));
    }


}
