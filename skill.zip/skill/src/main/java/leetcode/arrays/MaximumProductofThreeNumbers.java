package leetcode.arrays;

/*
Given an integer array, find three numbers
whose product is maximum and output the maximum product.
Input: [1,2,3,4]
Output: 24

3 positive -> 3 largest (+)
2 positive + 1 negative -> 1 largest (+) 2 smallest (-)
1 positive + 2 negative -> 1 largest (+) 2 smallest (-)
3 negative -> 3 largest (-)
 */

import java.util.Arrays;

public class MaximumProductofThreeNumbers {
    public static int maximumProduct(int[] nums) {
        Arrays.sort(nums);
        int n = nums.length;
        return Math.max(nums[n - 1] * nums[n - 2] * nums[n - 3], nums[0] * nums[1] * nums[n - 1]);
    }

    public static void main(String args[]){
        int rs = MaximumProductofThreeNumbers.maximumProduct(new int[]{6,-2,3,-4});
        System.out.println(rs);
    }
}
