package leetcode.arrays;

import java.util.Arrays;

/**
 * This class contains method which merge two given sorted arrays
 * return new int[]
 **/

public class MergeSortedArray {
    /*
        Assume Given arrays arr1 & arr2 are always sorted and may contains duplicate,negative numbers
        Length of arr1 & arr2 might be different
     */
    public static int[] mergeSortedArrays(int[] arr1, int[] arr2)
    {
        if(arr1.length==0){
            return arr2;
        }

        if(arr2.length==0){
            return arr1;
        }

        int i = 0, j = 0, k = 0;
        int n1= arr1.length;
        int n2= arr2.length;
        int[] arr3 = new int[n1+n2];
        while (i<n1 && j <n2)
        {
            if (arr1[i] < arr2[j])
                arr3[k++] = arr1[i++];
            else
                arr3[k++] = arr2[j++];
        }

        while (i < n1)
            arr3[k++] = arr1[i++];

        while (j < n2)
            arr3[k++] = arr2[j++];

        return arr3;
    }

    public static void main (String[] args) {
//        int[] arr1 = {2, 5, 6,6,6, 10,};
//        int[] arr2 = {1, 4, 5, 15,-1};
//
//       int[] arr= mergeSortedArrays(arr1, arr2);
//       System.out.println(Arrays.toString(arr));

        int k=0;
        System.out.println(k++);
        System.out.println(++k);
        System.out.println(k);

    }
}
