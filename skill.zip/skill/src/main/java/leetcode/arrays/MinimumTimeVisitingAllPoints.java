package leetcode.arrays;

/*
Input: points = [[1,1],[3,4],[-1,0]]
=>  firstXYPoints = [1,1], secondXYPoints=[3,4] => firstDiff= math.abs(1-3, 1-4) = 3
Output: 7
Explanation: One optimal path is [1,1] -> [2,2] -> [3,3] -> [3,4] -> [2,3] -> [1,2] -> [0,1] -> [-1,0]
Time from [1,1] to [3,4] = 3 seconds
Time from [3,4] to [-1,0] = 4 seconds
Total time = 7 seconds
https://www.youtube.com/watch?v=cqM8HqhuPe8
 */

public class MinimumTimeVisitingAllPoints {
    public static int minimumTimeVisitingPoints(int[][] points){
        int minimumTimeVisiting=0;
        for(int i=0; i<points.length-1; i++){
            int[] firstXYPoints = points[i];
            int[] secondXYPoints = points[i+1];
           int firstDiff =  Math.abs(firstXYPoints[0]-secondXYPoints[0]);
           int secondDiff = Math.abs(firstXYPoints[1]-secondXYPoints[1]);
           minimumTimeVisiting =  minimumTimeVisiting+firstDiff+secondDiff;
        }

        return minimumTimeVisiting;
    }

    public static void main(String[] args){
        System.out.println(Math.abs(-3)); // 3
    }

}
