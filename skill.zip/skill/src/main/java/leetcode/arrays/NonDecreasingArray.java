package leetcode.arrays;

/*
non-decreasing array  -- increasing array
Given an array nums with n integers, your task is to check if it could become non-decreasing by modifying at most 1 element.
Input: nums = [4,2,3]
Output: true
Explanation: You could modify the first 4 to 1 to get a non-decreasing array.

Input: nums = [4,2,1]
Output: false
Explanation: You can't get a non-decreasing array by modify at most one element.

https://www.youtube.com/watch?v=3UgvNI02ai4&t=129s
 */

public class NonDecreasingArray {
    public boolean checkPossibility(int[] nums) {
        int change = 0;
        int k = 0;
        for (int i=1; i<nums.length; i++) {
            if (nums[i] < nums[i-1]) {
                change++;
                k = i;
            }
        }
        if (change > 1) {
            return false;
        }
        if (change == 0) {
            return true;
        }
        if (k == 1 || k == nums.length-1) {
            return true;
        }
        if (nums[k+1] < nums[k-1] && nums[k] < nums[k-2]) {
            return false;
        }
        return true;
    }
}
