package leetcode.arrays;
/*
Given an array of integers nums.
A pair (i,j) is called good if nums[i] == nums[j] and i < j.
Return the number of good pairs.
Input: nums = [1,2,3,1,1,3]
Output: 4
Explanation: There are 4 good pairs (0,3), (0,4), (3,4), (2,5) 0-indexed.
 */

import java.util.HashMap;
import java.util.Map;

/*
Input: nums = [1,2,3,1,1,3]
Output: 4
Explanation: There are 4 good pairs (0,3), (0,4), (3,4), (2,5) 0-indexed.

A pair (i,j) is called good if nums[i] == nums[j] and i < j.
Return the number of good pairs.

 */

public class NumberofGoodPairs {
    public static int numIdenticalPairs1(int[] n) {
        HashMap<Integer,Integer> map = new HashMap();
        int count=0;
        for(int i=0;i<n.length;i++){
            if(map.containsKey(n[i])){
                int value = map.get(n[i]);
                count+=value;
            }
            map.put(n[i],map.getOrDefault(n[i],0)+1);
        }
        return count;
    }

    public static void main(String args[]){
         int rs =NumberofGoodPairs.numIdenticalPairs1(new int[]{1,2,3,1,1,3});
          System.out.println(rs);
    }
}
