package leetcode.arrays;

/*
  Given a non-empty array of digits representing a non-negative integer, increment one to the integer.
   Input: [1,2,3]
   Output: [1,2,4]
Explanation: The array represents the integer 123.
 */

import java.util.Arrays;

public class PlusOne {
    public static int[] plusOneTest(int[] digits) {
        int n = digits.length;
        for(int i=n-1; i>=0; i--) {
            if(digits[i] < 9) {
                digits[i]++;
                return digits;
            }

            digits[i] = 0;
        }

        int[] newNumber = new int [n+1];
        newNumber[0] = 1;
        return newNumber;
    }

    public static void main(String args[]){
        int num[] = PlusOne.plusOneTest(new int[]{9,9});
        System.out.println(Arrays.toString(num));
    }
}
