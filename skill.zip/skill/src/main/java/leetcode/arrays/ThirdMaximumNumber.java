package leetcode.arrays;

/*
Input: nums = [2,2,3,1]
Output: 1
Explanation:
The first distinct maximum is 3.
The second distinct maximum is 2 (both 2's are counted together since they have the same value).
The third distinct maximum is 1.
 */

import java.util.PriorityQueue;
public class ThirdMaximumNumber {
    public static int thirdMax(int[] nums) {
    PriorityQueue<Integer> pq = new PriorityQueue<>();
        for(int num: nums){
        if(!pq.contains(num)){
            pq.add(num);
            if(pq.size()>3){
                pq.poll();
            }
        }
    }
        return pq.poll();
}


    public static void main(String args[]){
     //ThirdMaximumNumber.checkPriorityQueue();
       int k = ThirdMaximumNumber.thirdMax(new int[]{20,100,4,10});
       System.out.println(k);
    }
}
