package leetcode.arrays;

import java.util.Arrays;
import java.util.HashMap;

/*
 Input: nums = [2,7,11,15], target = 9
Output: [0,1]
Output: Because nums[0] + nums[1] == 9, we return [0, 1].
 */

public class TwoSum {

    public static int[] twoSumSol(int[] arr, int val){
        int startVal =0;
        int endVal = arr.length-1;
        int[] result= new int[2];

        for(int j=0; j< arr.length;j++){
            int sum = arr[startVal]+arr[endVal];
            if(sum < val){
                startVal++;
            }else if(sum > val){
                endVal--;
            }else {
                result[0] = arr[startVal];
                result[1] = arr[endVal];

            }
        }
        return  result;
    }

    /* alternative way */

    public static int[] findSum(int[] arr, int target){
        HashMap<Integer,Integer> hashMap = new HashMap<Integer, Integer>();
        for(int i =0; i<arr.length; i++){
            if(hashMap.containsKey(target-arr[i])){
                return new int[]{arr[hashMap.get(target-arr[i])], arr[i]};
            }else{
                hashMap.put(arr[i],i);
            }
        }
        return new int[]{-1,-1};
    }

    public static int[] twoSum(int[] nums, int target) {
        int start=0;
        int last = nums.length-1;
        for(int k=start; k<=last;k++){
            int sum= nums[start]+nums[last];
            if(sum<target){
                start++;
            }else if(sum>target){
                last--;
            }
        }
        return new int[]{start,last};
    }

    public static void main(String args[]){
        System.out.println(Arrays.toString(TwoSum.twoSum(new int[]{1,2,3,5},8)));
    }
}

