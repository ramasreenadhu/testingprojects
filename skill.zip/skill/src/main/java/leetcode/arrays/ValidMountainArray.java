package leetcode.arrays;

/*
  https://www.youtube.com/watch?v=-gL730m25v8

 */

public class ValidMountainArray {
    public static boolean validMountainArrays(int[] A) {
        if(A.length<3)return false;
        int hi=A.length-1, lo=0;

        //Strictly decreasing
        while(hi>lo && A[hi-1]>A[hi]){
            hi--;
        }

        //Strictly increasing
        while(lo<hi && A[lo]<A[lo+1]){
            lo++;
        }
        return lo==hi && lo>0 && lo<A.length-1;
    }

    public static void main(String args[]){
        boolean result = ValidMountainArray.validMountainArrays(new int[]{0,1,2,3,2,1});
        System.out.println(result);
    }
}
