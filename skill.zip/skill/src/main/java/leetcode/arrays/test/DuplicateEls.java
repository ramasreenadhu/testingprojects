package leetcode.arrays.test;

import java.util.*;

public class DuplicateEls {
    public static int getDuplicates(int[] arr) {
        if (arr.length == 0) {
            return 0;
        }
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < arr.length; i++) {
            if (!map.containsKey(arr[i])) {
                map.put(arr[i], 1);
            } else {
                map.put(arr[i], map.get(arr[i]) + 1);
            }
        }
        for (Integer m : map.keySet()) {
            if (map.get(m) > 1) {
                return m;
            }
        }

        return -1;
    }

    public static void main(String args[]){
        System.out.println(DuplicateEls.getDuplicates(new int[]{4,2,4,4,1}));
    }
}