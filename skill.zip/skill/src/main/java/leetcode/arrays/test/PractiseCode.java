package leetcode.arrays.test;

import java.util.Arrays;

public class PractiseCode {
    public static String reverseStr(String str){
        char[] ch = str.toCharArray();
        int i=0;
        int j = ch.length;
        char temp;
        while(i<=j/2){
            temp = ch[i];
            ch[i]=ch[j-i-1];
            ch[j-1-i] = temp;
            i++;
        }

        return new String(ch);
    }

    public static int[] twoSum(int[] arr, int target){
        Arrays.sort(arr);
        int start=0;
        int end=arr.length-1;
        for(int i=0; i<arr.length-1; i++){
            int sum= arr[start] + arr[end];
            if(sum< target){
                start = start+1;
            }else if(sum > target){
                end=end-1;
            }else if(sum==target){
                return new int[]{start, end};
            }
        }

        return new int[]{-1,-1};
    }

    public static void main(String args[]){
       int[] arr= PractiseCode.twoSum(new int[]{2,7,9,11}, 9);
       System.out.println(Arrays.toString(arr));
    }
}
