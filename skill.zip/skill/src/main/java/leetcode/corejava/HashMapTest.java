package leetcode.corejava;

/*
Hashmap works on principle of hashing and internally uses hashcode as a base, for storing key-value pair.
With the help of hashcode, Hashmap distribute the objects across the buckets in such a way that hashmap put the objects and retrieve it in constant time O(1).
Hashmap put and get operation time complexity is O(1)
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HashMapTest {
    public static void main(String args[]){
        Map<String,Integer> map =new HashMap<String,Integer>();
        map.put("rama",10);
        map.put("krishna",20);
        for(Integer val : map.values()){
            System.out.println(val);
        }
    }

}
