package leetcode.corejava;

/*
HashSet is Implemented using a hash table. Elements are not ordered.
The add, remove, and contains methods has constant time complexity O(1).
 */

import java.util.HashSet;
import java.util.Set;

public class HashSetTest {
    public static void main(String args[]){
       Set<Integer> set = new HashSet<Integer>();
       set.add(100);
       set.add(200);
       for(Integer val : set){
           System.out.println(val);
       }
    }
}
