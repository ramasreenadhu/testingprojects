package leetcode.dfs;

/*
   https://www.youtube.com/watch?v=2HTbGsXmDQc&t=229s

Input:
image = [[1,1,1],[1,1,0],[1,0,1]]
sr = 1, sc = 1, newColor = 2
Output: [[2,2,2],[2,2,0],[2,0,1]]
ExplanationBorrowerController:
From the center of the image (with position (sr, sc) = (1, 1)),
all pixels connected
by a path of the same color as the starting pixel are colored with the new color.
Note the bottom corner is not colored 2, because it is not 4-directionally connected
to the starting pixel.
 */

import java.util.Arrays;

public class FloodFill {
    public static int[][] floodFill(int[][] image, int startRow, int startCol, int newColor) {
        if (image == null || image[startRow][startCol] == newColor) {
            return image;
        }
        fill(image, startRow, startCol, newColor, image[startRow][startCol]);
        return image;
    }

    private static void fill(int[][] image, int row, int col, int newColor, int firstColor) {
        if (row < 0 || row >= image.length || col < 0 || col >= image[0].length) {
            return;
        }
        if (image[row][col] == firstColor) {
            image[row][col] = newColor;
            fill(image, row - 1, col, newColor, firstColor);
            fill(image, row + 1, col, newColor, firstColor);
            fill(image, row, col - 1, newColor, firstColor);
            fill(image, row, col + 1, newColor, firstColor);
        }
    }

    public static void main(String args[]){
      int[][] rs = FloodFill.floodFill(new int[][]{{1,1,1},{1,1,0},{1,1,0}},1,1,2);
      for(int i=0; i<rs.length;i++){
          System.out.println(Arrays.toString(rs[i]));
      }
    }
}
