package leetcode.dfs;

/*
Input: [[1,1],2,[1,1]]
Output: 10
Explanation: Four 1's at depth 2, one 2 at depth 1.
[1,1] depth 2 so 1*2 + 1*2 = 2+2
2 depth 1 so 2*1 = 2
[1,1] depth 2 so 1*2 + 1*2 = 2+2
so 2+2+2+2+2=10


Input: [1,[4,[6]]]
Output: 27
Explanation: One 1 at depth 1, one 4 at depth 2, and one 6 at depth 3; 1 + 4*2 + 6*3 = 27.
[1,[4,[6]]]  = its nestedList so [1 depth 1, [1,[4 -depth 2 , [1,[4,[6 -depth 3
so 1*1 + 4*2+ 6*3 = 1+8+18 =27
using BFS

 */

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
// BFS
public class NestedListWeightSum {
    class NestedInteger{

        int getInteger(){
            return 0;
        }

        List<NestedInteger> getList(){
            return null;
        }


        boolean isInteger(){
            return true;
        }

    }

    public int depthSum(List<NestedInteger> nestedList) {
        int depth = 1, sum = 0;
        Queue<NestedInteger> q = new LinkedList<NestedInteger>();
        //Add level 1 elements to queue.
        for(NestedInteger ni : nestedList){
            q.offer(ni);
        }
        while(!q.isEmpty()){
            int size = q.size();
            while(size > 0){
                NestedInteger ni = q.poll();
                if(ni.isInteger()){
                    //add to sum if the current polled nestedInteger is actually an Integer.
                    sum += ni.getInteger() * depth;
                }
                else{
                    //add the elements of list to queue if the current polled nestedInteger is a list.
                    List<NestedInteger> tempList = ni.getList();
                    for(NestedInteger niTemp : tempList){
                        q.offer(niTemp);
                    }
                }
                size--;
            }
            depth++;
        }
        return sum;
    }
}
