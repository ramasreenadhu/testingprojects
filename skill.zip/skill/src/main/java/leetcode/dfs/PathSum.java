package leetcode.dfs;

/*
sum = 22
      5
     / \
    4   8
   /   / \
  11  13  4
 /  \      \
7    2      1

return true, as there exist a root-to-leaf path 5->4->11->2 which sum is 22.

 */


import java.util.Stack;

public class PathSum {
    class TreeNode{
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x){
            val=x;
        }

    }
    public boolean hasPathSum(TreeNode root, int sum) {
        if(root==null){
            return false;
        }
        Stack<TreeNode> node_stack = new Stack();
        Stack<Integer> sum_stack= new Stack();
        node_stack.add(root);
        sum_stack.add(sum - root.val);

        while(!node_stack.isEmpty()) {
            TreeNode current_node = node_stack.pop();
            int current_sum = sum_stack.pop();

            if(current_node.left==null && current_node.right==null
                    && current_sum==0){
                return true;
            }

            if(current_node.left!=null){
                node_stack.add(current_node.left);
                sum_stack.add(current_sum-current_node.left.val);
            }

            if(current_node.right!=null){
                node_stack.add(current_node.right);
                sum_stack.add(current_sum-current_node.right.val);
            }

        }
         return false;
    }
}
