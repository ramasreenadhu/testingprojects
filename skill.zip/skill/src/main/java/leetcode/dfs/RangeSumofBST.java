package leetcode.dfs;

/*

 */

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class RangeSumofBST {
    class TreeNode{
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x){
            val=x;
        }
    }
    public int rangeSumBST(TreeNode root, int L, int R) {
        int range_sum=0;
        Stack<TreeNode> stack= new Stack<TreeNode>();
        stack.push(root);
        while(!stack.isEmpty()){

            TreeNode node=  stack.pop();

           if(node.val >=L && node.val <=R){
                range_sum=range_sum+node.val;
            }

            if(node.left!=null){
              stack.push(node.left);
            }


            if(node.right!=null){
                stack.push(node.right);
            }
        }
        return range_sum;
    }
}
