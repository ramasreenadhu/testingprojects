package leetcode.dfs;


import java.util.LinkedList;
import java.util.Queue;

/*
  symmetric tree leetcode iterative
     Given a binary tree, check whether it is a mirror of itself
     https://www.youtube.com/watch?v=tNkDZvGsdAs
 */
public class SymmetricTree {
    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            this.val = x;
        }

        public boolean testSymmetricTree(TreeNode node) {
            if(node==null){
                return false;
            }
            Queue<TreeNode> q1= new LinkedList<>();
            Queue<TreeNode> q2= new LinkedList<>();
            q1.offer(node.left);
            q2.offer(node.right);

            while(!q1.isEmpty() && !q2.isEmpty()){
             TreeNode n1=q1.poll();
             TreeNode n2=q1.poll();
             if((n1==null && n2!=null) || (n1!=null && n2==null)){
                 return false;
             }
             if(n1!=null){
                 if(n1.val !=n2.val){
                     return false;
                 }
             }
                q1.offer(n1.left);
                q1.offer(n1.right);
                q2.offer(n2.left);
                q2.offer(n2.right);
            }
            return true;
        }
    }
}
