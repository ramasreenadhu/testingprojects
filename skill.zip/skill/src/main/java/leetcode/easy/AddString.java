package leetcode.easy;

public class AddString {
    /*
         49 + 58 => 105
         https://www.youtube.com/watch?v=mrawYKHoIcc
     */

    public static String addStrings(String num1, String num2){
        if(num1==null && num2==null){
            return null;
        }
        int n = num1.length()-1;
        int s = num2.length()-1;
        int sum=0;
        int carry=0;
        StringBuilder sb= new StringBuilder();
        while(n>=0 || s>=0){
            sum=carry;
            if(n>=0){
                sum = sum+num1.charAt(n--)-'0';
            }
            if(s>=0){
                sum= sum+num2.charAt(s--)-'0';
            }

            sb.append(sum%10);
            carry = sum/10;
        }

        if(carry==1){
            sb.append(1);
        }

        return sb.reverse().toString();
    }

    public static void main(String[] args){

        System.out.println("1".charAt(0)+"1".charAt(0));  // returns 98 (1 ANSCI is 49)
        System.out.println("1".charAt(0)-'0'+"1".charAt(0)-'0');    // return 49-48 because 0 ansci is 48
        //System.out.println(AddString.addStrings("49", "58"));
    }
}
