package leetcode.easy;

/*
   https://www.youtube.com/watch?v=FsigpyvLPHA
 */
public class BestTimeToBuyandSellStock {
    public int maxProfit(int[] a) {
        int minPrice = Integer.MAX_VALUE;
        int maxProfit = 0;
        for(int i=0;i<a.length;i++){
            if(a[i]<minPrice){
                minPrice = a[i];
            }
            else{
                int temp = a[i]-minPrice;
                if(temp>maxProfit){
                    maxProfit = temp;
                }
            }
        }
        return maxProfit;
    }

    //my version
    public static int buySellStock(int[] prices){
        int n=prices.length;
        if(n<=1){
            return prices[0];
        }

        int maxProfit=0;
        int minPrice=Integer.MAX_VALUE;

        for(int i=0; i<prices.length-1; i++){
            minPrice = Math.min(minPrice,prices[i]);
            maxProfit = Math.max(maxProfit,prices[i]-minPrice);
        }
        return maxProfit;
    }
}
