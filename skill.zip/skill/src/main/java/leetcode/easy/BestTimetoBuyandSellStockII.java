package leetcode.easy;

/*
   https://leetcode.com/problems/best-time-to-buy-and-sell-stock-ii/
   https://www.youtube.com/watch?v=05Yn7MlV924

 */

public class BestTimetoBuyandSellStockII {
    public static int maxProfit(int[] price){
        if(price.length==0){
            return 0;
        }
        int profit=0;
        for(int i=0; i<price.length-1; i++){
            if(price[i] < price[i+1]){
                profit= profit+price[i+1]-price[i];
            }
        }
        return profit;
    }

    public static void main(String args[]){
        int res=  BestTimetoBuyandSellStockII.maxProfit(new int[]{7,1,5,3,6,4});
        System.out.println(res);
    }
}
