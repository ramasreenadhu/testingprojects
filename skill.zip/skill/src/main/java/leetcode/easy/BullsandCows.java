package leetcode.easy;

/*
  https://www.youtube.com/watch?v=V_rZZ0kMFiw

 */

import java.util.HashMap;
import java.util.Map;

public class BullsandCows {
    public String getHint(String secret, String guess) {
        int countA=0;
        for(int i=0;i<secret.length();i++) {
            if(secret.charAt(i)==guess.charAt(i)) {
                countA++;
            }
        }
        Map<String, Integer> map = new HashMap<>();
        for(int i=0;i<secret.length();i++) {
            String key=secret.substring(i,i+1);
            if(map.containsKey(key)) {
                map.put(key, map.get(key)+1);
            }
            else
                map.put(key, 1);
        }
        int countB=0;
        for(int i=0;i<guess.length();i++) {
            String key = guess.substring(i,i+1);
            if(map.containsKey(key)) {
                map.put(key, map.get(key)-1);
                if(map.get(key)>=0) {
                    countB++;
                }
            }
        }
        String result=countA+"A"+(countB-countA)+"B";
        return result;
    }
}
