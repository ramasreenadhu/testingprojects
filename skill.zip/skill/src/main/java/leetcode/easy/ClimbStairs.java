package leetcode.easy;

public class ClimbStairs {
    /*
       https://www.youtube.com/watch?v=_RrNV8oMMug
       formula : n = (n-1) + (n-2)
       Input: 2
       Output: 2
       Explanation: There are two ways to climb to the top.
       1. 1 step + 1 step
       2. 2 steps
   */
    public static int climbStairsSol(int n) {
        if(n <=1){
            return 1;
        }

        int[] ways = new int[n+1];
        ways[0] =1;
        ways[1] =1;
        //ways[2] = ways[1] + ways[0]
        //ways[3] = ways[2] + ways[1]


        for(int i=2; i<=n; i++){
            ways[i] = ways[i-1] + ways[i-2];
        }
        return ways[n]; // last element in array
    }
    public static void main(String args[]){
        int[] c= new int[]{1,2,3};
        System.out.println(c[2]);
    }
}
