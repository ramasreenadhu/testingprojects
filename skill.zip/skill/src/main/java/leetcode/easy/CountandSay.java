package leetcode.easy;

/*
   https://www.youtube.com/watch?v=INl9Ha294E0s
 */

public class CountandSay {
    public String countAndSay(int n) {
        String val = "1";
        for(int i = 1; i < n; i++){
            val = countIdx(val);
        }
        return val;
    }

    public String countIdx(String s){
        StringBuilder sb = new StringBuilder();
        char val = s.charAt(0);
        int count = 1;
        for(int i = 1; i < s.length(); i++){
            if(s.charAt(i) == val){
                count++;
            }
            else
            {
                sb.append(count);
                sb.append(val);
                val = s.charAt(i);
                count = 1;
            }
        }
        sb.append(count);
        sb.append(val);
        return sb.toString();
    }

    public static void main(String args[]){
        String s = new CountandSay().countAndSay(3);
        System.out.println(s);
    }
}
