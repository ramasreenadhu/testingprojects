package leetcode.easy;

import java.util.Arrays;

/*
   https://www.youtube.com/watch?v=IZY-HJog5Jg
   put(key, value) : Insert a (key, value) pair into the HashMap. If the value already exists in the HashMap, update the value.
   get(key): Returns the value to which the specified key is mapped, or -1 if this map contains no mapping for the key.
   remove(key) : Remove the mapping for the value key if this map contains the mapping for the key.
 */
public class DesignHashMap {
    int[] a;
    /** Initialize your data structure here. */
    public DesignHashMap() {
       a =new int[10000];
        Arrays.fill(a,-1);
    }

    /** value will always be non-negative. */
    public void put(int key, int value) {
       a[key]=value;
    }

    /** Returns the value to which the specified key is mapped, or -1 if this map contains no mapping for the key */
    public int get(int key) {
        return a[key];
    }

    /** Removes the mapping of the specified value key if this map contains a mapping for the key */
    public void remove(int key) {
          a[key]=-1;
    }

}
