package leetcode.easy;

import java.util.HashMap;

public class DesignHashSet {
    HashMap<Integer,Integer> map=null;
    public DesignHashSet() {
        map = new HashMap<Integer, Integer>();
    }

    public void add(int key) {
       map.put(key,1);
    }

    public void remove(int key) {
        map.remove(key);
    }

    /** Returns true if this set contains the specified element */
    public boolean contains(int key) {
       return map.containsKey(key);
    }
}
