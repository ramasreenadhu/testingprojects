package leetcode.easy;

/*
    The diameter of a binary tree is the length of the longest path between any two nodes in a tree. This path may or may not pass through the root.
    https://www.youtube.com/watch?v=opxuvlAgyaM
 */
public class DiameterofBinaryTree {
    int ans=0;
    class TreeNode{
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x){
            this.val=x;
        }

       public int findLongestPath(TreeNode t1){
         getDiameters(t1);
         return ans==0?0:ans-1;
       }

      public int  getDiameters(TreeNode t1){
      if(t1==null) return 0;
      int l = getDiameters(t1.left);
      int r = getDiameters(t1.right);
      ans = Math.max(ans, l+r+1);
      return Math.max(l,r)+1;
    }
    }
}
