package leetcode.easy;

public class ExcelSheetColumnTitle {
}
