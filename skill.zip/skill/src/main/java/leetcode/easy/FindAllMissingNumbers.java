package leetcode.easy;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//https://www.youtube.com/watch?v=efU_3Da3DV0

public class FindAllMissingNumbers {
    public static List<Integer> missingNumbers(int[] nums){
        List<Integer> list = new ArrayList<Integer>();
        Set<Integer> set= new HashSet<Integer>();
        for(int i : nums){
           set.add(i);
       }
       for(int i=0; i<=nums.length; i++){
            if(!set.contains(i)){
                list.add(i);
            }
       }
      return list;
    }

    public static void main(String args[]){
        System.out.println(FindAllMissingNumbers.missingNumbers(new int[]{5,6,4,1}));
    }
}
