package leetcode.easy;

/*
Input: ["bella","label","roller"]
Output: ["e","l","l"]

Analysis:
Time: O(n), where n is the total number of characters in A;
extra space: O(1), excludes output/return space.

 */


import java.util.*;

public class FindCommonCharacters {
    public List<String> commonChars(String[] A) {
        List<String> res = new ArrayList<String>();
        int[] min = new int[26];
        for (int i = 0; i < 26; i++) {
            min[i] = Integer.MAX_VALUE;
        }

        for (String s : A) {
            int[] cur = new int[26];
            char[] ca = s.toCharArray();
            for (char c : ca) {
                cur[c - 'a']++;
            }
            for (int i = 0; i < 26; i++) {
                min[i] = Math.min(min[i], cur[i]);
            }
        }

        for (char c = 'a'; c <= 'z'; ++c) {
            while (min[c - 'a']-- > 0) {
                res.add("" + c);
            }
        }

        return res;
    }


    public static void main(String args[]) {
        System.out.println(new FindCommonCharacters().commonChars(new String[]{"bella", "label", "roller"}));

        char[] c = {'d', 'f', 'd', 'e', 'a'};
        int[] rs = new int[26];
        for (char a : c) {
            rs[a - 'a']++;
        }
        System.out.println(Arrays.toString(rs));
    }


}
