package leetcode.easy;

import java.util.*;

public class FindDuplicateNumberorString {
    public static List<String> findDuplicates(String str){
        String[] strArray = str.split(" ");
        Map<String,Integer> map =new HashMap<String,Integer>();
        List<String> list = new ArrayList<String>();
        for(int i=0; i< strArray.length; i++){
            if(map.containsKey(strArray[i])){
                map.put(strArray[i],map.get(strArray[i])+1);
            }else{
                map.put(strArray[i],1);
            }
        }

       Set<Map.Entry<String,Integer>> set = map.entrySet();
        for(Map.Entry<String,Integer> s : set){
           if(s.getValue() >1){
               list.add(s.getKey());
           }
        }
        return list;
    }

    public static Map<String,List<Integer>> _findDuplicates(String str) {
        String[] strArray = str.split(" ");
        Map<String,List<Integer>> map =new HashMap<String,List<Integer>>();
        Map<String,List<Integer>> rs =new HashMap<String,List<Integer>>();
        List<String> list = new ArrayList<String>();
        for(int i=0; i< strArray.length; i++){
            if(map.containsKey(strArray[i])){
                map.put(strArray[i],map.get(strArray[i])).add(i);
            }else{
                map.put(strArray[i],new ArrayList<>());
                map.get(strArray[i]).add(i);
            }
        }

        Set<Map.Entry<String,List<Integer>>> set = map.entrySet();
        for(Map.Entry<String,List<Integer>> s : set){
            if(s.getValue().size() >1){
                rs.put(s.getKey(),s.getValue());
            }
        }
        return rs;
    }

    public String removeDuplicates(String S) {
        Stack<Character> stack = new Stack();
        for (char c : S.toCharArray()) {
            if (!stack.isEmpty() && stack.peek() == c) {
                //remove
                stack.pop();
            } else {
                //add to stack
                stack.push(c);
            }
        }

        StringBuilder sb = new StringBuilder();
        while (!stack.isEmpty())
            sb.append(stack.pop());
        return sb.reverse().toString();
    }

    public static void main(String args[]){
      System.out.println(FindDuplicateNumberorString._findDuplicates("leet code leet code leet java"));
    }
}
