package leetcode.easy;

import java.util.HashMap;
import java.util.Map;

/*
    s = "leetcode" return 0.
    s = "loveleetcode", return 2.
 */

public class FirstUniqChar {
    public static int firstUniqChar(String s) {
        HashMap<Character, Integer> count = new HashMap<Character, Integer>();
        int n = s.length();
        // build hash map : character and how often it appears
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            count.put(c, count.getOrDefault(c, 0) + 1);
        }

        // find the index
        for (int i = 0; i < n; i++) {
            if (count.get(s.charAt(i)) == 1)
                return i;
        }
        return -1;
    }

    public static int findFirstCharIndex(String str){
        Map<Character,Integer> map = new HashMap<Character,Integer>();
        for(int i=0; i<str.length();i++){
            if(map.containsKey(str.charAt(i))){
                map.put(str.charAt(i),map.get(str.charAt(i))+1);
            }else{
                map.put(str.charAt(i),1);
            }
        }

        for (int i = 0; i < str.length(); i++) {
            if (map.get(str.charAt(i)) == 1)
                return i;
        }
        return -1;
    }

    public static void main(String args[]){
        //System.out.println(FirstUniqChar.findUniqueChars("ramas"));
        System.out.println(FirstUniqChar.findFirstCharIndex("leetcode"));
    }
}
