package leetcode.easy;

import java.util.Arrays;

/*
For example, flipping [1, 1, 0]
horizontally results in [0, 1, 1].
To invert an image means that each 0 is replaced by 1, and each 1 is replaced by 0. For example,
inverting [0, 1, 1] results in [1, 0, 0].
Input: [[1,1,0],[1,0,1],[0,0,0]]
Output: [[1,0,0],[0,1,0],[1,1,1]]
Explanation: First reverse each row: [[0,1,1],[1,0,1],[0,0,0]].
Then, invert the image: [[1,0,0],[0,1,0],[1,1,1]]
 */
public class FlippinganImage {
    public int[] reverse(int[] nums) {
        int[] b = new int[nums.length];
        int k = nums.length;
        for(int i =0; i<k/2; i++){
            int temp = b[i];
            b[i]= b[k-1-i];
            b[k-1-i] = temp;
        }
        return b;
    }

    public int[] flip(int[] arr) {

        for(int i=0; i<arr.length; i++) {
            arr[i] = arr[i] == 0 ? 1 : 0;
        }
        return arr;
    }

    public int[][] flipAndInvertImage(int[][] A) {

        for(int i=0; i<A.length; i++) {
            A[i] = reverse(A[i]);
        }

        for(int i=0; i<A.length; i++) {
            A[i] = flip(A[i]);
        }
        return A;
    }
}
