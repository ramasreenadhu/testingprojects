package leetcode.easy;

/*
  Input: nums = [1,2,3,1]
  Output: 4
Explanation: Rob house 1 (money = 1) and then rob house 3 (money = 3).
             Total amount you can rob = 1 + 3 = 4.

    https://www.youtube.com/watch?v=yYtItcJXTjk
 */

public class HouseRobber {
    public static int maxMoneyRob(int[] arr){
        int n = arr.length;
        if(n==0){
            return 0;
        }

        if(n==1){
            return 1;
        }

        int[] dp = new int[n]; //[1,2,3,1]
        dp[0] = arr[0]; //1
        dp[1] = Math.max(arr[0],arr[1]); //2

        for(int i=2; i<n; i++){
          dp[i] = Math.max(dp[i-1],dp[i-2]+arr[i]); // math.max(dp[1]-dp[0]+arr[2]
        }
        return dp[n-1];
    }

    public static void main(String args[]){
        int rs =HouseRobber.maxMoneyRob(new int[]{1,2,3,1});
        System.out.println(rs);
    }
}


//    int rob = 0; //max monney can get if rob current house
//    int notrob = 0; //max money can get if not rob current house
//    for(int i=0; i<num.length; i++) {
//        int currob = notrob + num[i]; //if rob current value, previous house must not be robbed
//        notrob = Math.max(notrob, rob); //if not rob ith house, take the max value of robbed (i-1)th house and not rob (i-1)th house
//        rob = currob;
//        }
//        return Math.max(rob, notrob);