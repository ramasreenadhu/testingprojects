package leetcode.easy;

/*
    https://www.youtube.com/watch?v=Lt6VBVUs5k4
 */

public class InvertBinaryTree  {
}
