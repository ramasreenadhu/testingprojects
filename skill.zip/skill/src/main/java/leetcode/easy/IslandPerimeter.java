package leetcode.easy;

/*
  https://www.youtube.com/watch?v=Ugf7iLJke68
 */
public class IslandPerimeter {
    public static int islandPerimeter(int[][] grid){
        if(grid == null || grid.length ==0 || grid[0].length == 0)
            return 0;
        int count = 0;
        for(int i=0;i<grid.length;i++){
            for(int j=0;j<grid[0].length;j++){
                if(grid[i][j] == 1){
                    if(j-1 == -1 || grid[i][j-1] ==0) // check left
                        count++;
                    if(j+1 == grid[0].length || grid[i][j+1] ==0) // check right
                        count++;
                    if(i-1 == -1 || grid[i-1][j] ==0)  //check top
                        count++;
                    if(i+1 == grid.length || grid[i+1][j] ==0)//check bottom
                        count++;
                }
            }
        }
        return count;
    }

    public static void main(String args[]){
        int[][] grid=new int[][]{{0,1,0,0},{1,1,1,0},{0,1,0,0},{1,1,0,0}};
       int rs =  IslandPerimeter.islandPerimeter(grid);
       System.out.println(rs);
    }
}
