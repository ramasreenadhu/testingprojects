package leetcode.easy;

/*
Given two strings s and t, determine if they are isomorphic.
Two strings are isomorphic if the characters in s can be replaced to get t.
Input: s = "egg", t = "add"  => Output: true
Input: s = "foo", t = "bar"  =>Output: false
Input: s = "paper", t = "title" => Output: true

https://www.youtube.com/watch?v=B-qgcLN8mQM
 */

import java.util.HashMap;
import java.util.Map;

public class Isomorphic {

    public static boolean isIsomorphic(String s1, String s2){
        if(s1.length()!=s2.length()){
            return false;
        }

      Map<Character,Character> map = new HashMap<Character,Character>();
        for(int i=0; i<s1.length();i++){
            if(map.containsKey(s1.charAt(i))){
                if(map.get(s1.charAt(i))!=s2.charAt(i)) return false;
            }else{
                if(map.containsValue(s2.charAt(i))) return false;
                map.put(s1.charAt(i),s2.charAt(i));
            }
        }
        return true;
    }

    public static void main(String args[]){
        System.out.println(Isomorphic.isIsomorphic("egg","add"));
    }
}
