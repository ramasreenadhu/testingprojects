package leetcode.easy;

/*
   https://www.youtube.com/watch?v=6oes33jgAv0
 */

public class JewelsandStones {
    public int numJewelsInStones(String J, String S) {
        char []temp = S.toCharArray();
        int n = 0;
        for(int i = 0; i < temp.length; ++i){
            if(J.indexOf(temp[i]) != -1){
                n++;
            }
        }
        return n;
    }
}
