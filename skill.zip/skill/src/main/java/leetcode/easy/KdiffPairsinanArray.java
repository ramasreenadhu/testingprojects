package leetcode.easy;
/*
Input: [3, 1, 4, 1, 5], k = 2
Output: 2
Explanation:
There are two 2-diff pairs in the array, (1, 3) and (3, 5).
Although we have two 1s in the input,
we should only return the number of unique pairs.
 */

import java.util.Arrays;
import java.util.HashSet;

public class KdiffPairsinanArray {
    public static  int findPairs(int[] nums, int k) {
        if (k < 0) {
            return 0;
        }
        Arrays.sort(nums);
        int counter = 0;
        int left = 0;
        int right = 0;

        HashSet<Integer> set = new HashSet<>();

        while (right < nums.length) {
            int s = nums[right] - nums[left];

            if (s == k && left != right && !set.contains(nums[right])) {
                counter++;
                set.add(nums[right]);

                left++;
                right++;
            } else if (s < k) {
                right++;
            } else {
                left++;
            }
        }

        return counter;
    }

    public static void main(String args[]){
        System.out.println(KdiffPairsinanArray.findPairs(new int[]{3, 1, 4, 1, 5},2));
    }
}
