package leetcode.easy;

/*
  https://www.youtube.com/watch?v=aaWU4Bq1X-c
int k = 3;
int[] arr = [4,5,8,2];
KthLargest kthLargest = new KthLargest(3, arr);
kthLargest.add(3);   // returns 4
kthLargest.add(5);   // returns 5
kthLargest.add(10);  // returns 5
kthLargest.add(9);   // returns 8
kthLargest.add(4);   // returns 8
 */

import java.util.PriorityQueue;
import java.util.Random;

public class KthLargestElementInAStream {

    private PriorityQueue<Integer> pq;
    private int k;

    public KthLargestElementInAStream(int[] arr, int k){
        pq =new PriorityQueue<>();
        this.k=k;
        for(int i=0; i<arr.length;i++){
            add(arr[i]);
        }

    }

    public int add(int num){
        pq.offer(num);
        if(pq.size() >k){
            pq.poll(); // remove first element
        }
        return pq.peek();
    }

    public void printNum(){
        System.out.println(pq.peek());
    }

    //public static void main(String args[]){
    //new KthLargestElementInAStream(new int[]{4,5,8,2,9,10},3).printNum();

}
