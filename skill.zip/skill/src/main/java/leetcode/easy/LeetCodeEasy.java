package leetcode.easy;

import testCode.DocuSignLeetCode;
import testCode.LeetCode;
import testCode.LeetCodeUtility;

import java.util.*;

public class LeetCodeEasy {


    public static boolean isValidAnagram(String s, String t){
        if(s.length()!=t.length()){
            return false;
        }
        int[] count = new int[26];

        for(int i=0; i<s.length(); i++){
            count[s.charAt(i)-'a']++;
            count[t.charAt(i)-'a']--;
        }

        for(int k : count){
            if(k!=0){
                return false;
            }
        }

        return true;
    }

    /*
   https://www.youtube.com/watch?v=tQur3kprZQk
   Input: 1->2->3->4->5->NULL
   Output: 5->4->3->2->1->NULL

    public static LeetCode.ListNode reverseLinkedListNode(LeetCode.ListNode node){
        Stack<LeetCode.ListNode> stackNode = new Stack<LeetCode.ListNode>();
        while(node!=null){
            stackNode.push(node);
            node = node.next;
        }

        LeetCode.ListNode dummy=  new LeetCode.ListNode(-1);
        node= dummy;
        while(!stackNode.isEmpty()){
            LeetCode.ListNode current = stackNode.pop();
            node.next= new LeetCode.ListNode(current.val);
            node=node.next;
        }
        return dummy.next;
    }


    private int lo, maxLen;  */

    /* https://www.youtube.com/watch?v=1SDVa-p_CZs

   

    public static LeetCode.ListNode MergeSortedTwoList(LeetCode.ListNode node1, LeetCode.ListNode node2){
        LeetCode.ListNode dummy = new LeetCode.ListNode(0);
        LeetCode.ListNode l3 = dummy;

        while(node1 !=null && node2!=null){
            if(node1.val <= node2.val){
                l3.next=node1;
            }else{
                l3.next = node2;
            }
            l3= l3.next;
        }

        if(node1!=null){
            l3.next=node1;
        }

        if(node2!=null){
            l3.next=node2;
        }
        return dummy.next;
    } /*

    /*
        https://www.youtube.com/watch?v=qOyO7MCd1G8&t=964s
        https://leetcode.com/problems/add-two-numbers/
        Input: (2 -> 4 -> 3) + (5 -> 6 -> 4)
        Output: 7 -> 0 -> 8


    public LeetCode.ListNode addTwoNumbers(LeetCode.ListNode l1, LeetCode.ListNode l2) {

        LeetCode.ListNode dummy = new LeetCode.ListNode(0);
        LeetCode.ListNode l3 = dummy;
        int carry =0;

        //  12+9 11%10 =1 11/10 =1
        while(l1!=null && l2!=null){
            int digitalVal = (l1.val + l2.val+carry)%10;
            carry = (l1.val + l2.val+carry)/10;
            LeetCode.ListNode ll = new LeetCode.ListNode(digitalVal);
            l3.next=ll;
            l1= l1.next;
            l2= l2.next;
        }

        while(l1!=null){
            int digitalVal = (l1.val +carry)%10;
            carry = (l1.val +carry)/10;
            LeetCode.ListNode ll = new LeetCode.ListNode(digitalVal);
            l3.next=ll;
            l1= l1.next;

        }

        while(l2!=null){
            int digitalVal = (l2.val +carry)%10;
            carry = (l2.val +carry)/10;
            LeetCode.ListNode ll = new LeetCode.ListNode(digitalVal);
            l3.next=ll;
            l2= l2.next;
        }

        if(carry!=0){
            LeetCode.ListNode ll =new LeetCode.ListNode(carry);
            l3.next =ll;
            l3 = ll;
        }

        return dummy.next;
    } */

    /*
    https://leetcode.com/problems/reorder-data-in-log-files/discuss/362761/Java-Solution-Beats-99-both-runtime-and-memory
    https://www.youtube.com/watch?v=Ie7VMpZlLrY
    boolean result= Character.isDigit("dig1 8 1 5 1".charAt("dig1 8 1 5 1".length()-1));
    System.out.println(result);
    int out = s1.compareTo(s2); => This returns difference s1-s2.=>  Compares two string lexicographically.
     */
    public static String[] reorderLogFiles(String[] logs) {
        if(logs.length == 0) return logs;
        List<String> letterLogs = new ArrayList<>(), digitLogs = new ArrayList<>();
        LeetCodeUtility.separateLettersDigits(logs, letterLogs, digitLogs);
        LeetCodeUtility.sortLetterLogs(letterLogs);
        return LeetCodeUtility.generateOutput(letterLogs, digitLogs);
    }

    /*
        https://www.youtube.com/watch?v=_RrNV8oMMug
        formula : n = (n-1) + (n-2)
        Input: 2
        Output: 2
        Explanation: There are two ways to climb to the top.
        1. 1 step + 1 step
        2. 2 steps
    */
    public static int climbStairs(int n) {
        if(n <=1){
            return 1;
        }

        int[] ways = new int[n+1];
        ways[0] =1;
        ways[1] =1;

        for(int i=2; i<=n; i++){
            ways[i] = ways[i-1] + ways[i-2];
        }
        return ways[n];
    }

      /*
    https://www.youtube.com/watch?v=0I6IL3TnIZs
    https://leetcode.com/problems/group-anagrams/
       Input: ["eat", "tea", "tan", "ate", "nat", "bat"],
      Output:[["ate","eat","tea"],["nat","tan"],["bat"]]
     */

    public static List<List<String>> groupAnagrams(String[] strs) {
        if (strs.length == 0) return new ArrayList();
        Map<String, List> ans = new HashMap<String, List>();
        for (String s : strs) {
            char[] ca = s.toCharArray();
            Arrays.sort(ca);
            String key = String.valueOf(ca);

            if (!ans.containsKey(key))
                ans.put(key, new ArrayList());{
            }

            ans.get(key).add(s);
        }
        return new ArrayList(ans.values());
    }

    /*
         validate Parantheseses
     */

    public static boolean validParentheses(String str){
        Stack<Character> stack = new Stack<Character>();
        char[] ch = str.toCharArray();
        for(int i=0 ; i< ch.length; i++){
            if(ch[i]=='(' || ch[i]=='[' || ch[i]=='{'){
                stack.push(ch[i]);
            }else{
                if(!stack.isEmpty() && isParantheseses(stack.peek(),ch[i])){
                    stack.pop();
                }else{
                    return false;
                }
            }

        }

        return stack.isEmpty();
    }

    public static boolean isParantheseses(char left, char right){
        return left =='(' && right==')' || left=='{' && right=='}' || left=='[' && right==']';
    }

    public static int maxProfit2ndSol(int[] arr){
        int maxProfit=0;
        int minVal = Integer.MAX_VALUE;
        for(int i=0; i< arr.length; i++){
            minVal = Math.min(minVal, arr[i]); // 7  7,1 1
            maxProfit = Math.max(maxProfit, arr[i]-minVal); // 0, 0

        }
        return maxProfit;
    }

    public static int maxProfit2ndSol_(int[] arr){
        int maxProfit=0;
        for(int i=0; i< arr.length; i++){
            if(arr[i] <arr[i+1])
                maxProfit = Math.min(maxProfit, arr[i+1]-arr[i]); // 7  7,1 1

        }
        return maxProfit;
    }

    public static String reverseStr(String str){

        char temp;
        char[] ch = str.toCharArray();
        int n =ch.length;
        for(int i=0; i< n/2; i++){
            temp = ch[i];
            ch[i] = ch[n-i-1];
            ch[n-i-1] = temp;
        }
        return new String(ch);
    }

    /*
        Input: [-2,1,-3,4,-1,2,1,-5,4],
        Output: 6
        Explanation: [4,-1,2,1] has the largest sum = 6.
     */

    public static int maxSubArray(int[] nums) {
        int max = nums[0];
        int maxsofar = nums[0];
        for(int i=1;i<nums.length;i++){
            maxsofar = Math.max(maxsofar + nums[i], nums[i]);
            max = Math.max(max, maxsofar);
        }
        return max;
    }

     /*
      arr = {1, 21, 3, 14, 5, 60, 7, 6} , value = 27
      Sample Output #  arr = {21, 6} or {6, 21}
     */

    public static int[] returnSumVal(int[] arr, int val){

        int startVal =0;
        int endVal = arr.length-1;
        int[] result= new int[2];

        for(int j=0; j< arr.length;j++){
            int sum = arr[startVal]+arr[endVal];
            if(sum < val){
                startVal++;
            }else if(sum > val){
                endVal--;
            }else {
                result[0] = arr[startVal];
                result[1] = arr[endVal];

            }
        }
        return  result;
    }

    public static int[] findSum(int[] arr, int target){
        HashMap<Integer,Integer> hashMap = new HashMap<Integer, Integer>();
        for(int i =0; i<arr.length; i++){
            if(hashMap.containsKey(target-arr[i])){
                return new int[]{arr[hashMap.get(target-arr[i])], arr[i]};
            }else{
                hashMap.put(arr[i],i);
            }
        }
        return new int[]{-1,-1};
    }

      /*Sample Input # arr = {1, 2, 3, 4, 5}
       Sample Output # arr = {5, 1, 4, 2, 3*/

        public static void maxReArrangeWithMaxMin(int[] arr) {
            //Create a result array to hold re-arranged version of given arr
            int[] result = new int[arr.length];

            int pointerSmall = 0;     //PointerSmall => Start of arr
            int pointerLarge = arr.length - 1;   //PointerLarge => End of arr

            //Flag which will help in switching between two pointers
            boolean switchPointer = true;

            for (int i = 0; i < arr.length; i++) {
                if (switchPointer)
                    result[i] = arr[pointerLarge--]; // copy large values
                else
                    result[i] = arr[pointerSmall++]; // copy small values

                switchPointer = !switchPointer;   // switching between samll and large
            }

            for (int j = 0; j < arr.length; j++) {
                arr[j] = result[j];    // copying to original array
            }
        }

  /*Sample Input #arr = {1, 2, 3, 4, 5} Sample Output #arr = {5, 1, 2, 3, 4}*/

    public static int[] rotateArr(int[] arr){
        int val = arr[arr.length-1];
        for(int i = arr.length-1; i>0; i--){
            arr[i] =arr[i-1];
        }
        arr[0]=val;
        return arr;
    }

    /*
        How many times 'balloon' words appears in given String
        Input: text = "loonbalxballpoon"
        Output: 2
     */

    //https://www.youtube.com/watch?v=LGgMZC0vj5s
    //https://leetcode.com/problems/maximum-number-of-balloons/
    public static int maxNumberOfBalloons(String text) {
        int[] count = new int[26];
        for(char c : text.toCharArray()){
            count[c-'a']++;
        }
        System.out.println(Arrays.toString(count));
        // [1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 2, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        return Math.min(count[1],Math.min(count[0],Math.min(count[11]/2,Math.min(count[14]/2,count[13]))));
    }


    /*
        pivot index as the index where the sum of all the numbers to the left of the index is
        equal to the sum of all the numbers to the right of the index.

         totalsum=28
         L=1
         R=27

         L=8
         R=20

         L=11
         R=17

         L=17
        if(L==R)
        return i;

        Input: nums = [1,7,3,6,5,6]
        Output: 3
        Explanation:
               The sum of the numbers to the left of index 3 (nums[3] = 6) is equal to the sum of numbers to the right of index 3.
                Also, 3 is the first index where this occurs.
    */
    // https://www.youtube.com/watch?v=wKXEviRbLtY
    public static int pivotIndex(int[] nums) {
        int totalSum=0, leftSum=0, rightSum=0;
        for(int i=0; i< nums.length; i++){
            totalSum = totalSum+nums[i];
        }
        for(int j=0; j<nums.length ;j++){
            rightSum = totalSum - leftSum -nums[j];
            if(rightSum==leftSum){
                return j;
            }
            leftSum = leftSum+nums[j]
            ;
        }
        return -1;
    }

    /*
          Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
          Output: 5
          Explanation: As one shortest transformation is "hit" -> "hot" -> "dot" -> "dog" -> "cog", return its length 5.
          https://www.youtube.com/watch?v=PeyYhb8lJJU
          https://leetcode.com/problems/word-ladder/

          // core logic: classic BFS: starting from the begin word, do a BFS till you encounter the end word. if you don't find end word by the end of the process, return 0
    // level 1: hit  level 2: hot  level 3: dot, lot   level 4: dog, log   level 5: cog  (this is for example 1)
    // TC: O(m * n) -> where m is the length of word list and n is the length of each word

    BFS uses Queue to find the shortest path. DFS uses Stack to find the shortest path. BFS is better when target is closer to Source. DFS is better when target is far from source.

     */

    private static int ladderLength(String beginWord, String endWord, List<String> wordList) {
        if (!wordList.contains(endWord)) {
            return 0;
        }

        int level = 0;
        Queue<String> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>(wordList);
        queue.offer(beginWord);

        while (!queue.isEmpty()) {
            int queueSize = queue.size();
            for (int i = 0; i < queueSize; i++) {
                String word = queue.poll();
                if (word.equals(endWord)) {
                    return level + 1;
                }
                wordMatch(queue, visited, word);
            }
            level++;
        }
        return 0;
    }

    private static void wordMatch(Queue<String> queue, Set<String> visited, String word) {
        for (int i = 0; i < word.length(); i++) {
            char[] wordArray = word.toCharArray();
            for (char ch = 'a'; ch < 'z'; ch++) {
                wordArray[i] = ch;

                String newWord = String.valueOf(wordArray);
                if (visited.contains(newWord)) {
                    visited.remove(newWord);
                    queue.offer(newWord);
                }
            }
        }
    }

    /*
          https://www.youtube.com/watch?v=oRllj-ObrBU
          https://leetcode.com/problems/search-in-rotated-sorted-array/solution/
          Input: nums = [4,5,6,7,0,1,2], target = 0
          Output: 4
          step1: start < middle => start < taget && target < middle ( target is btw start & middle) -- end = mid-1;
          step2: middle < end =>  (target is bwt middle & end) -- start = middle+1
     */

    public static int searchInRotatedSortedAray(int[] nums, int target) {
        int start = 0, end = nums.length - 1;
        while (start <= end) {
            int mid = start + (end - start) / 2;
            if (nums[mid] == target) return mid;

            else if (nums[start] <= nums[mid]) {
                if (nums[start] <= target && target < nums[mid]) end = mid - 1; // target is btw start & middle
                else start = mid + 1;
            }
            else {
                if (target <= nums[end] && target > nums[mid]) start = mid + 1; // target is btw middle & end
                else end = mid - 1;
            }
        }
        return -1;
    }

    public static int reverseInt(int num){
        int rev =0;
        while(num!=0){
            int pop = num %10;
            num = num/10;
            rev = rev *10 + pop;
        }

        return rev;
    }


    public static void main(String args[]){
        System.out.println(DocuSignLeetCode.isValidAnagram("anagram", "nagaram"));
    }
}
