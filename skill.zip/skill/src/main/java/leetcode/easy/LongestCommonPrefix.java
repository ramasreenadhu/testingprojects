package leetcode.easy;

/*
   https://www.youtube.com/watch?v=Tj0VRPcj8pQ&t=3s
 */

public class LongestCommonPrefix {

    public static String longestCommonPrefix(String[] str){
        if(str.length<=1){
            return "";
        }

        String lcp = str[0];
        for(int i=1; i<str.length;i++){
            int count=0;
            String currentString = str[i];
            for(int j=0; j<lcp.length() &&
                    j<currentString.length(); j++){
                if(lcp.charAt(j)==currentString.charAt(j)){
                    count++;
                }
            }

            lcp=lcp.substring(0,count);
        }
        return lcp;
    }
    public static void main(String args[]){
        String prefix =LongestCommonPrefix.longestCommonPrefix(new String[]{"folwer","flow","flight"});
        System.out.println(prefix);
    }

}
