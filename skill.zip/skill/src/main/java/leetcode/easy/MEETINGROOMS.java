package leetcode.easy;

import java.util.Arrays;

/*
https://www.youtube.com/watch?v=i2bBG7CaVxs
Input: [[0,30],[5,10],[15,20]]
Output: false

Input: [[7,10],[2,4]]
Output: true
 */

public class MEETINGROOMS {
    public class Interval {
        int start;
        int end;
        Interval(){
            start=0;
            end=0;
        }
        Interval(int s, int e){
            start=s;
            end=e;
        }
    }

    public static boolean canAttendMeetings(Interval[] intervals){
        int len=intervals.length;
        if(len==0){
            return true;
        }
        int[]start=new int[len];
        int[]end=new int[len];
        for(int i=0;i<len;i++){
            start[i]=intervals[i].start;
            end[i]=intervals[i].end;
        }
        Arrays.sort(start);
        Arrays.sort(end);

        for(int i=0; i<len;i++){
            if(end[i]>start[i+1]){
                return false;
            }
        }
        return true;
    }
}
