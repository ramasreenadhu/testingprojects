package leetcode.easy;

import java.util.Stack;

public class MaxStack {
    int max;
    Stack stack;
    Stack stack2;

    public MaxStack() {
        max = Integer.MIN_VALUE;
        stack = new Stack<Integer>();
        stack2 = new Stack<Integer>();
    }

    public void push(int x) {
        if (x >= max) {
            stack.push(max);
            max = x;
        }
        stack.push(x);
    }

    public int pop() {
        int ret = (int) stack.pop();
        if (ret == max) {
            max = (int) stack.pop();
        }
        return ret;
    }

    public int top() {
        return (int) stack.peek();
    }

    public int peekMax() {
        return max;
    }

    public int popMax() {
        int ret = max;
        int tmp = pop();
        // use stack2 to temporarily store the numbers before max appears.
        while (tmp != ret) {
            stack2.push(tmp);
            tmp = pop();
        }
        while (!stack2.isEmpty())
            push((Integer) stack2.pop());
        return ret;
    }
}
