package leetcode.easy;

public class MaximumDepthofBinaryTree {
    //https://www.youtube.com/watch?v=jN7xVW2Qtbs

    class TreeNode{
        TreeNode leftNode;
        TreeNode rightNode;
        int val;
        TreeNode(int x){
            val=x;
        }

    }

    public int getMaxDepth(TreeNode t1){
        if(t1==null){
            return 0;
        }

        if(t1.leftNode==null && t1.rightNode==null){
            return 1;
        }

       int left = getMaxDepth(t1.leftNode);
       int right =  getMaxDepth(t1.rightNode);
       int max = Math.max(left,right)+1;
       return max;
    }
}
