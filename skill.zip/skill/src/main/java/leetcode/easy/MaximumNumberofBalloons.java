package leetcode.easy;

import java.util.Arrays;

public class MaximumNumberofBalloons {
    //https://www.youtube.com/watch?v=LGgMZC0vj5s
    //https://leetcode.com/problems/maximum-number-of-balloons/
    public static int maxNumberOfBalloons(String text) {
        int[] count = new int[26];
        for(char c : text.toCharArray()){
            count[c-'a']++;
        }
        System.out.println(Arrays.toString(count));
        // [1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 2, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        return Math.min(count[1],Math.min(count[0],Math.min(count[11]/2,Math.min(count[14]/2,count[13]))));
    }
}
