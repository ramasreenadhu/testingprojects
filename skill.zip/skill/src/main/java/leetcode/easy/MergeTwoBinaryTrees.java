package leetcode.easy;


//https://www.youtube.com/watch?v=Rt-mneSQg9E

public class MergeTwoBinaryTrees {
    class TreeNode{
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x){
            this.val=x;
        }
    }
    public TreeNode mergeTwoNodes(TreeNode t1, TreeNode t2){
      if(t1==null & t2==null){
          return null;
      }

      if(t1==null && t2!=null){
          return t2;
      }

        if(t1!=null && t2==null){
            return t1;
        }

        TreeNode sum = new TreeNode(t1.val+t2.val);
        sum.left = mergeTwoNodes(t1.left, t2.left);
        sum.right = mergeTwoNodes(t1.right, t2.right);
      return sum;
    }
}
