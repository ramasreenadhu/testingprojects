package leetcode.easy;

/* https://www.youtube.com/watch?v=1SDVa-p_CZs
ListNode l1 = new ListNode();
ListNode l2 = new ListNode();
ListNode l3 = new ListNode();
l1.item = 1;
l2.item = 2;
l3.item = 3;
link them together
l1.next = l2
l2.next = l3
l3.next = null

l1 - > l2 -> l3 -> null

A dummy head node is a node that always points to the
beginning of the list or has a NULL pointer field if the list is empty.
This node is called a dummy node since it does not contain data included in the list.

Linked lists are linear data structures that hold data in individual
objects called nodes. ... Linked lists are often used because of their
efficient insertion and deletion. They can be used to implement stacks,
queues, and other abstract data types
* */

public class MergeTwoSortedLists {

    class ListNode{
        int val;
        ListNode next;
        ListNode(int x){
            val=x;
        }
    }

    public  ListNode MergeSortedTwoList(ListNode node1,ListNode node2){
        ListNode dummy = new ListNode(0);
        ListNode l3 = dummy;

        while(node1 !=null && node2!=null){
            if(node1.val <= node2.val){
                l3.next=node1;
            }else{
                l3.next = node2;
            }
            l3= l3.next; // move l3 to next node
        }

        if(node1!=null){
            l3.next=node1;
        }

        if(node2!=null){
            l3.next=node2;
        }
        return dummy.next;
    }
}
