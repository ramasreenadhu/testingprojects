package leetcode.easy;

public class MiddleoftheLinkedList {
}
