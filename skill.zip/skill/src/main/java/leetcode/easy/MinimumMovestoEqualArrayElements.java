package leetcode.easy;

/*
Given a non-empty integer array of size n,
find the minimum number of moves required
to make all array elements equal,
where a move is incrementing n - 1 elements by 1.

Input:
[1,2,3]

Output:
3

Explanation:
Only three moves are needed (remember each move increments two elements):

[1,2,3]  =>  [2,3,3]  =>  [3,4,3]  =>  [4,4,4]
https://leetcode.com/problems/minimum-moves-to-equal-array-elements/discuss/299009/Java-easy-with-detailed-explanation...
 */

public class MinimumMovestoEqualArrayElements {
    public static int minMoves(int[] nums) {
        int min = nums[0], sum = nums[0];
        for(int i=1; i < nums.length; i++){
            min = Math.min(min, nums[i]);
            sum += nums[i];
        }
        return sum-min*nums.length;
    }
    public static void main(String args[]){
       //int rs=  MinimumMovestoEqualArrayElements.minMoves(new int[]{1,2,3,4});
       //System.out.println(rs);
        //System.out.println(String.format("qatester+%s@tlcqa.com","123"));
        String body ="{\n" +
                "    \"keyId\": \"LOW_NPI\", \n" +
                "    \"value\": \"%s\"\n" +
                "}";

        System.out.println(String.format(body,"hhwwqh^%^&bhjbjjj2***&"));
    }
}
