package leetcode.easy;

/*
Return the minimum positive value of startValue
such that the step by step sum is never less than 1.
https://www.youtube.com/watch?v=Tj1gCl_gG5I
Input: nums = [-3,2,-3,4,2] //
Output: 5
 */

public class MinimumValueGetPositive {
    public static int minStartValue(int[] nums) {
        int sum = 0, min_sum = 0;
        for (int n : nums) {
            sum += n;
            min_sum = Math.min(min_sum, sum);
        }
        return 1 - min_sum;
    }

    public static void main(String args[]){
       int rs= MinimumValueGetPositive.minStartValue(new int[]{-3,2,-3,4,2});
       System.out.println(rs);
    }
}
