package leetcode.easy;

import java.util.HashMap;
import java.util.HashSet;

/*
Input: paragraph = "Bob hit a ball, the hit BALL flew far after it was hit."
banned = ["hit"]
Output: "ball"
Explanation:
"hit" occurs 3 times, but it is a banned word.
"ball" occurs twice (and no other word does), so it is the most frequent non-banned word in the paragraph.
Note that words in the paragraph are not case sensitive,
that punctuation is ignored (even if adjacent to words, such as "ball,"),
and that "hit" isn't the answer even though it occurs more because it is banned.
 */

public class MostCommonWord {
    public static String mostCommonWord(String paragraph, String[] banned) {
        String[] words = paragraph.toLowerCase().split("\\W");
        HashMap<String,Integer> map = new HashMap<>();
        HashSet<String> ban_set = new HashSet<>();
        for(String s:banned){
            ban_set.add(s);
        }
        for(String s:words){
            //if(ban_set.contains(s)) continue;
            if(map.containsKey(s)){
                map.put(s,map.get(s)+1);
            }else{
                map.put(s,1);
            }
        }

        String res = "";
        int max = 0;    // find max from HashMap
        for(String s:map.keySet()){
            if(map.get(s)>max){
                res = s;
                max = map.get(s);
            }
        }

        return res;
    }

    public static void main(String args[]){
        String strCommon = MostCommonWord.mostCommonWord("Bob hit a ball, the hit BALL flew far after it was hit.", new String[]{"hit"});
        System.out.println(strCommon);
    }
}
