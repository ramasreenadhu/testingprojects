package leetcode.easy;

/*
      Move zeros to at end of array, Input: [0,1,0,3,12] => Output: [1,3,12,0,0]
 */

import java.util.Arrays;

public class MoveZeros {
    public static int[] moveZerosToArray(int[] arr){
        int index=0;
        for(int i=0; i< arr.length; i++){
            if(arr[i]!=0) {
                arr[index++] = arr[i];
            }
        }

        for(int i=index; i<arr.length; i++){
            arr[i]=0;
        }
        return arr;
    }

    public static void main(String args[]){
       System.out.println(Arrays.toString(MoveZeros.moveZerosToArray(new int[]{0,1,0,3,12})));
    }
}
