package leetcode.easy;

/*
  https://www.youtube.com/watch?v=E-kjYOZEBxY
Given a stream of integers and a window size,
calculate the moving average of all integers in the sliding window.
Example:
MovingAverage m = new MovingAverage(3);
m.next(1) = 1
m.next(10) = (1 + 10) / 2
m.next(3) = (1 + 10 + 3) / 3
m.next(5) = (10 + 3 + 5) / 3
 */

import java.util.LinkedList;
import java.util.Queue;

public class MovingAveragefromDataStream {
    private int size;
    private int total = 0;
    private Queue<Integer> queue = new LinkedList<>();

    public MovingAveragefromDataStream(int size) {
        this.size = size;
    }

    public double next(int val) {
        if(queue.size() >= this.size) {
            int remove = queue.poll();
            queue.offer(val);
            total = total - remove;
            total = total + val;
        } else {
            total = total + val;
            queue.offer(val);
        }

        return (double) total / queue.size();
    }
}
