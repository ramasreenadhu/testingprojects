package leetcode.easy;

public class Palindrome {
    public static boolean isPalindrome(String s) {
        int n = s.length()-1;
        int j = n;
        for (int i = 0; i < n / 2; ++i) { // n / 2 is right-leaning
            if (s.charAt(i) != s.charAt(j)) return false;
            j=j-1;
        }
        return true;
    }

    public static boolean _isPalindrome(String s) {
        int end = s.length()-1;
        int start=0;
        for (int i = start; i < end / 2; i++) {
            if (s.charAt(start) != s.charAt(end)) return false;
            end =end-1;
        }
        return true;
    }

    public static void main(String args[]){
       System.out.println(Palindrome.isPalindrome("abac"));
    }
}
