package leetcode.easy;

/*
Given a non-empty string s,
you may delete at most one character.
Judge whether you can make it a palindrome.
Example 1:  Input: "aba" Output: True
Example 2:  Input: "abca" Output: True (Explanation: You could delete the character 'c').
 */

public class PalindromeII {
    public boolean validPalindrome(String s) {
        int left = 0;
        int right = s.length() - 1;
        while (left < right) {
            if (s.charAt(left) != s.charAt(right))
                return checkPalindrome(left + 1, right, s) ||
                        checkPalindrome(left, right - 1, s);
            left++;
            right--;
        }
        return true;
    }
    private boolean checkPalindrome(int left, int right, String s) {
        while (left < right) {
            if (s.charAt(left++) != s.charAt(right--))
                return false;
        }
        return true;
    }
}
