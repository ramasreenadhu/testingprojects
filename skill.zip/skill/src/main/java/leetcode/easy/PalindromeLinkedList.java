package leetcode.easy;


//https://www.youtube.com/watch?v=3thY0z3Pf5k
public class PalindromeLinkedList {

    class ListNode {
        int val;
        ListNode next;
        ListNode(int x){
            this.val=x;
        }

        public boolean isPalindromicList(ListNode head){
         ListNode sp = head, fp=head, mid=null;
         while(fp!=null && fp.next!=null){
             sp =sp.next;
             fp =fp.next.next;
         }

         if(fp!=null){
             mid = sp.next;
         }else{
             mid = sp;
         }

         ListNode prev =null, next=null;
         while(mid!=null){
             next = mid.next;
             mid.next = prev;
             prev =mid;
             mid=next;
         }

         while(prev!=null){
             if(prev.val !=head.val){
                 return false;
             }

             prev =prev.next;
             head= head.next;
         }
         return true;
        }
    }
}
