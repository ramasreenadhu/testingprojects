package leetcode.easy;

import java.util.HashMap;
import java.util.Map;

/*
  https://www.youtube.com/watch?v=RjKu8O1yFN8

 */

public class PalindromePermutation {
    // s should have 0 or 1 odd number character
    public boolean canPermutePalindrome(String s) {
        Map<Character, Integer> map = new HashMap<>();
        for(int i=0; i<s.length(); i++) {
            char c = s.charAt(i);
            if (!map.containsKey(c))
                map.put(c, 1);
            else
                map.put(c, map.get(c)+1);
        }
        int count = 0;
        for (int v: map.values())
            if (v%2==1)
                count++;
        return count == 1 || count == 0;
    }
}
