package leetcode.easy;

/*
   USE BFS which touch every element in Node so BFS follows queue
   https://www.youtube.com/watch?v=SIdrJwWp3H0
 */

import java.util.LinkedList;
import java.util.Queue;

public class RangeSumofBST {
    class TreeNode{
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x){
            val=x;
        }
    }
    public int rangeSumBST(TreeNode root, int L, int R) {
        //BFS Approach
        Queue<TreeNode> q = new LinkedList<>();
        int sum=0;
        q.add(root);
        while(!q.isEmpty()){
            root=q.poll();
            if(root.val>=L && root.val<=R){
                sum+=root.val;
            }
            if(root.left!=null)
                q.add(root.left);
            if(root.right!=null)
                q.add(root.right);
        }
        return sum;
    }

}
