package leetcode.easy;

/*
   write a function that will return true if the ransom note can be constructed from the magazines ; otherwise, it will return false.
   Input: ransomNote = "a", magazine = "b" Output: false
   Input: ransomNote = "aa", magazine = "ab" Output: false
   Input: ransomNote = "aa", magazine = "aab"  Output: true

    https://www.youtube.com/watch?v=-moq8WgNRsY
 */

import java.util.HashMap;
import java.util.Map;

public class RansomNote {
    public static boolean canConstruct(String ransomNote, String magazine) {
        int[] arr = new int[26];
        for (int i = 0; i < magazine.length(); i++) {
            arr[magazine.charAt(i) - 'a']++;
        }
        for (int i = 0; i < ransomNote.length(); i++) {
            if(--arr[ransomNote.charAt(i)-'a'] < 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean canConstructUsingMap(String ransomNote, String magazine) {
        Map<Character, Integer> magM = new HashMap<>();
        for (char c:magazine.toCharArray()){
            int newCount = magM.getOrDefault(c, 0)+1;
            magM.put(c, newCount);
        }
        for (char c:ransomNote.toCharArray()){
            int newCount = magM.getOrDefault(c,0)-1;
            if (newCount<0)
                return false;
        }
        return true;
    }


    public static void main(String[] args){
       System.out.println(RansomNote.canConstructUsingMap("aaac","aaab"));
    }

}
