package leetcode.easy;


/*
 their x's overlap (rec1[0] < rec2[2] && rec2[0] < rec1[2])
their y's overlap (rec1[1] < rec2[3] && rec2[1] < rec1[3])
https://www.youtube.com/watch?v=o6hHUk4DOW0
 */
public class RectangleOverlap {
    public boolean isRectangleOverlap(int[] rec1, int[] rec2) {
        return (rec1[0] < rec2[2] && rec2[0] < rec1[2]) &&
                (rec1[1] < rec2[3] && rec2[1] < rec1[3]);
    }
}
