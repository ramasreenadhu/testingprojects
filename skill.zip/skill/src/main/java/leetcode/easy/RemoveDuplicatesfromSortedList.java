package leetcode.easy;



public class RemoveDuplicatesfromSortedList {

    public static int removeDuplicates(int[] nums) {
        if(nums.length==0){
            return 0;
        }
        int j=0;
        for(int i=1;i<nums.length;i++){
            if(nums[j]!=nums[i]){
                nums[++j]=nums[i];
            }
        }
        return j+1;
    }



    public static void main(String args[]){
        System.out.println(RemoveDuplicatesfromSortedList.removeDuplicates(new int[]{1,1,2}));
    }
}
