package leetcode.easy;

import testCode.LeetCodeUtility;

import java.util.ArrayList;
import java.util.List;

public class ReorderDataInLogFiles {

    /*
   https://leetcode.com/problems/reorder-data-in-log-files/discuss/362761/Java-Solution-Beats-99-both-runtime-and-memory
   https://www.youtube.com/watch?v=Ie7VMpZlLrY

   Reorder the logs so that all of the letter-logs
   come before any digit-log.
   The letter-logs are ordered lexicographically ignoring identifier,
   with the identifier used in case of ties.
   The digit-logs should be put in their original order.

   Input: logs = ["dig1 8 1 5 1","let1 art can","dig2 3 6","let2 own kit dig","let3 art zero"]
   Output: ["let1 art can","let3 art zero","let2 own kit dig","dig1 8 1 5 1","dig2 3 6"]

   boolean result= Character.isDigit("dig1 8 1 5 1".charAt("dig1 8 1 5 1".length()-1));
   System.out.println(result);
   int out = s1.compareTo(s2); => This returns difference s1-s2.=>  Compares two string lexicographically.
    */
    public static String[] reorderLogFiles(String[] logs) {
        if(logs.length == 0) return logs;
        List<String> letterLogs = new ArrayList<>(),
                digitLogs = new ArrayList<>();
        LeetCodeUtility.separateLettersDigits(logs, letterLogs, digitLogs);
        LeetCodeUtility.sortLetterLogs(letterLogs);
        return LeetCodeUtility.generateOutput(letterLogs, digitLogs);
    }

    public static void main(String args[]){
       //boolean rs = Character.isDigit("dig1 8 1 5 1".charAt("dig1 8 1 5 1".length()-1));
       //System.out.println(rs);
     System.out.println(Character.isDigit("8 1 5 1 dig".charAt("8 1 5 1 dig".length()-1)));
    }
}
