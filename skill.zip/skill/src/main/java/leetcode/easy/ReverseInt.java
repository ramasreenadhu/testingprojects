package leetcode.easy;

public class ReverseInt {
    public static int reverseInt(int num){
        int rev =0;
        while(num!=0){
            int pop = num %10;  // remainder
            num = num/10; //
            rev = rev *10 + pop;
        }

        return rev;
    }
}
