package leetcode.easy;

import java.util.Stack;

/*
    https://www.youtube.com/watch?v=tQur3kprZQk
   Input: 1->2->3->4->5->NULL
   Output: 5->4->3->2->1->NULL
 */
public class ReverseLinkedListNode {

    class ListNode{
        int val;
        ListNode next;
        ListNode(int x){
            val=x;
        }
    }

    public ListNode reverseLinkedListNode(ListNode node){
        Stack<ListNode> stackNode = new Stack<ListNode>();
        while(node!=null){
            stackNode.push(node);
            node = node.next;
        }

        ListNode dummy=  new ListNode(-1);
        node= dummy;
        while(!stackNode.isEmpty()){
            ListNode current = stackNode.pop();
            node.next= new ListNode(current.val);
            node=node.next;
        }
        return dummy.next;
    }
}
