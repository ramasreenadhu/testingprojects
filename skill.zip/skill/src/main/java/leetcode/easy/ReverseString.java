package leetcode.easy;

public class ReverseString {
    public static String reverseStr(String str){

        char temp;
        char[] ch = str.toCharArray();
        int n =ch.length;
        for(int i=0; i< n/2; i++){
            temp = ch[i];
            ch[i] = ch[n-i-1];
            ch[n-i-1] = temp;
        }
        return new String(ch);
    }

    public static void main(String args[]){
       //String rs = ReverseString.reverseStr("sreekrisha");
       //System.out.println(rs);
       System.out.println("000006oDVFQEJeOqJ7JAAhNuWtJ8qCSF".length());
    }
}

