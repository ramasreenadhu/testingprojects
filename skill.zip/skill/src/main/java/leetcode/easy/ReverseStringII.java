package leetcode.easy;

/*
   https://www.youtube.com/watch?v=SUrrSVfk7pk
   Input: s = "abcdefg", k = 2 => Output: "bacdfeg"
   you need to reverse the first k characters for every 2k characters counting from the start of the string.
   If there are less than k characters left, reverse all of them.
   If there are less than 2k but greater than or equal to k characters,
   then reverse the first k characters and left the other as original.
 */

public class ReverseStringII {
    public String reverseStr(String s, int k) {

        int i = 0;
        char[] chars = s.toCharArray();
        while (i < chars.length) {
            int end = i + k - 1;
            if (end > chars.length - 1)
                end = chars.length - 1;

            reverse(chars, i, end);

            i = i + 2 * k;
        }

        return new String(chars);
    }

    private void reverse(char[] chars, int left, int right) {

        while (left < right) {
            char tmp = chars[left];
            chars[left] = chars[right];
            chars[right] = tmp;
            left++;
            right--;
        }
    }

    public static void main(String args[]){
       System.out.println(new ReverseStringII().reverseStr("abcdefg",2));
    }
}
