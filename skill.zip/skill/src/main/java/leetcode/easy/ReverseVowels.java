package leetcode.easy;

import java.util.Stack;

public class ReverseVowels {
    public String reverseVowels(String s) {
        if(s == null || s.length() == 0)
            return s;
        char[] arr = s.toCharArray();
        Stack<Character> vowels = new Stack();
        for(char c : arr){
            if(isVowel(c))
                vowels.push(c);
        }
        for(int i = 0; i < arr.length; i++){
            if(isVowel(arr[i]))
                arr[i] = vowels.pop();
        }

        return new String(arr);
    }
    public boolean isVowel(char c){
        return c == 'a' || c == 'A' ||
                c == 'e' || c == 'E' ||
                c == 'i' || c == 'I' ||
                c == 'o' || c == 'O' ||
                c == 'u' || c == 'U';
    }

    public static void main(String args[]){
        System.out.println(new ReverseVowels().reverseVowels("hello"));
    }
}
