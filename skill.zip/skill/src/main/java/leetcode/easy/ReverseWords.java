package leetcode.easy;

/*
    Input: "Let's take LeetCode contest"
    Output: "s'teL ekat edoCteeL tsetnoc"
 */

public class ReverseWords {
    public String reverseWords(String s) {
        String[] strArray = s.split("\\s+");
        StringBuilder result = new StringBuilder();
        int n = strArray.length;
        for (int i = 0; i < n; ++i) {
            StringBuilder sb = new StringBuilder(strArray[i]);
            result.append(sb.reverse());
            if (i < n - 1) result.append(" ");
        }
        return result.toString();
    }
}
