package leetcode.easy;

/*
     Symbol       Value
I             1
V             5
X             10
L             50
C             100
D             500
M             1000

What is CXVII as an integer?
Recall that C = 100, X = 10, V = 5, and I = 1. Because the symbols are ordered from most significant to least,
we can simply add the symbols, i.e. C + X + V + I + I = 100 + 10 + 5 + 1 + 1 = 117.

What is DXCI as an integer?
Recall that D = 500.
Now, notice that this time the symbols are not ordered from most significant
to least—the X and C are out of numeric order. Because of this, we subtract
the value of X (10) from the value of C (100) to get 90.
So, going from left to right, we have D + (C - X) + I = 500 + 90 + 1 = 591
 */

import java.util.HashMap;
import java.util.Map;

public class RomanToInteger {
    static Map<String, Integer> values = new HashMap<>();

    static {
        values.put("M", 1000);
        values.put("D", 500);
        values.put("C", 100);
        values.put("L", 50);
        values.put("X", 10);
        values.put("V", 5);
        values.put("I", 1);
    }

    public static int romanToInt(String s) {

        int sum = 0;
        int i = 0;
        while (i < s.length()) {
            String currentSymbol = s.substring(i, i + 1);
            int currentValue = values.get(currentSymbol);
            int nextValue = 0;
            if (i + 1 < s.length()) {
                String nextSymbol = s.substring(i + 1, i + 2);
                nextValue = values.get(nextSymbol);
            }

            if (currentValue < nextValue) {
                sum += (nextValue - currentValue);
                i += 2;
            }
            else {
                sum += currentValue;
                i += 1;
            }

        }
        return sum;
    }
 public static void main(String args[]){
       int sum =RomanToInteger.romanToInt("DXCI");
       System.out.println(sum);
 }
}
