package leetcode.easy;

/*
Input: nums = [4,5,6,7,0,1,2], target = 0
Output: 4
 */

public class RotatedSortedArray {
}
