package leetcode.easy;

import java.util.ArrayList;
import java.util.List;

public class SelfDividingNumbers     {
      /*
         For example, 128 is a self-dividing number because 128 % 1 == 0, 128 % 2 == 0, and 128 % 8 == 0.
         Input: left = 1, right = 22
         Output: [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 15, 22]

         Logic :  System.out.println(Arrays.toString(String.valueOf(128).toCharArray())); -- [1,2,8]
     */

    public static List<Integer> selfDividingNums(int left, int right){
        List<Integer> list =new ArrayList<Integer>();
        for(int k =left; k<=right; k++){
            if(isSelfDividingNum(k)){
                list.add(k);
            }
        }
        return list;
    }

    public static boolean isSelfDividingNum(int num){
        // convert to string
        for(char c : String.valueOf(num).toCharArray()){
            if(num % c > 0){
                return false;
            }
        }
        return true;
    }
}
