package leetcode.easy;

/*
Given a list of words and two words word1 and word2,
return the shortest distance between these two words
in the list.

Assume that words = ["practice", "makes", "perfect", "coding", "makes"].
Input: word1 = “coding”, word2 = “practice”
Output: 3 // 3-0 index of coding : 3, index of practice : 0,

Input: word1 = "makes", word2 = "coding"
Output: 1
 */
public class ShortestWordDistance {
    public int shortestDistance(String[] words, String word1, String word2) {
        int p1 = -1, p2 = -1, min = Integer.MAX_VALUE;

        for (int i = 0; i < words.length; i++) {
            if (words[i].equals(word1))
                p1 = i;

            if (words[i].equals(word2))
                p2 = i;

            if (p1 != -1 && p2 != -1)
                min = Math.min(min, Math.abs(p1 - p2));
        }

        return min;
    }

    public static void main(String args[]){
       int k = new ShortestWordDistance().shortestDistance(new String[]{"practice", "makes", "perfect", "coding", "makes"},
                "coding","practice");
       System.out.println(k);
    }
}
