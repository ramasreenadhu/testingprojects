package leetcode.easy;

/*
   Given a non-empty array of integers, every element appears twice except for one. Find that single one.
   Input: [2,2,1]  => Output: 1
   https://www.youtube.com/watch?v=CvnnCZQY2A0
 */

import java.util.HashSet;

public class SingleNumber {
   public static int returnSingleNumber(int[] arr){
       HashSet<Integer> set = new HashSet<Integer>();
       for(int i: arr){
           if(set.contains(i)){
               set.remove(i);
           }else{
               set.add(i);
           }
       }
       for(int i :set){
           return i;
       }
       return -1;
   }
}
