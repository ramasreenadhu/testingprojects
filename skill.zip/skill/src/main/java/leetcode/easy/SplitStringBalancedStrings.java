package leetcode.easy;

/*
Input: s = "RLRRLLRLRL"
Output: 4
Explanation: s can be split into "RL", "RRLL", "RL", "RL",
each substring contains same number of 'L' and 'R'.
 */

public class SplitStringBalancedStrings {
    public static int balancedStringSplit(String s) {
        if (s == null || s.length() == 0)
            return 0;
        int left = 0, right = 0, score = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 'L')
                left++;
            else
                right++;
            if (left == right)
                score++;
        }
        return score;
    }

    public static void main(String args[]){
       int rs= SplitStringBalancedStrings.balancedStringSplit("RRLRRLLRLRL");
       System.out.println(rs);
    }
}
