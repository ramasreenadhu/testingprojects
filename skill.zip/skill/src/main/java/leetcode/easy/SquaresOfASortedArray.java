package leetcode.easy;

import java.util.Arrays;

/*
return an array of the squares of each number, also in sorted non-decreasing order.
Input: [-4,-1,0,3,10]
Output: [0,1,9,16,100]
 */
public class SquaresOfASortedArray {

    public static int[] sortedSquares(int[] A) {
        int[] res = new int[A.length];
        int lo = 0; int hi = A.length - 1;
        for (int i = A.length - 1; i >= 0; i--) {
            //check if abs left is less than or equal to abs right
            if (Math.abs(A[lo]) >= Math.abs(A[hi])) {
                res[i] = A[lo] * A[lo];
                lo++;
            } else {
                res[i] = A[hi] * A[hi];
                hi--;
            }
        }
        return res;
    }

    public static void main(String args[]){
        //int[] rs =SquaresOfASortedArray.sortedSquares(new int[]{-4,-1,0,3,10});
        //System.out.println(Arrays.toString(rs));
        System.out.println(Math.abs(-4));
    }
}
