package leetcode.easy;

/*
    Input: ["a","a","b","b","c","c","c"]
    Output:Return 6, and the first 6 characters of the input array should be: ["a","2","b","2","c","3"]
    Explanation:"aa" is replaced by "a2". "bb" is replaced by "b2". "ccc" is replaced by "c3"
 */

public class StringCompression {
    public static int compress(char[] chars) {
        String ans="";
        int count =1;
        char a=chars[0];
        for(int i=1;i<chars.length;i++){
            if(chars[i]==a){
                count++;
            }else{
                if(count==1){
                    ans=ans+Character.toString(a);
                }else{
                    ans=ans+Character.toString(a)+Integer.toString(count);
                }
                a=chars[i];
                count=1;
            }
        }

        if(count==1){
            ans=ans+Character.toString(a);
        }else{
            ans=ans+Character.toString(a)+Integer.toString(count);
        }
        System.out.println(ans);
        return ans.length();
    }


    public static void main(String[] args){
        int k =StringCompression.compress(new char[]{'a','b','b','c','c','c'});
        System.out.println(k);
    }
}
