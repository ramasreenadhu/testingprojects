package leetcode.easy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/*
A website domain like "discuss.leetcode.com" consists of various subdomains. At the top level,
we have "com", at the next level, we have "leetcode.com",
and at the lowest level, "discuss.leetcode.com". When we visit a domain like "discuss.leetcode.com",
we will also visit the parent domains "leetcode.com" and "com" implicitly.

Input: ["900 google.mail.com", "50 yahoo.com", "1 intel.mail.com", "5 wiki.org"]
Output: ["901 mail.com","50 yahoo.com","900 google.mail.com","5 wiki.org","5 org","1 intel.mail.com","951 com"]
Explanation:
We will visit "google.mail.com" 900 times, "yahoo.com" 50 times, "intel.mail.com" once and "wiki.org" 5 times.
For the subdomains, we will visit "mail.com"
900 + 1 = 901 times, "com" 900 + 50 + 1 = 951 times,
and "org" 5 times.
 */

public class SubdomainVisitCount {
    public List<String> subdomainVisits(String[] cpdomains) {
        HashMap<String, Integer> dictDom = new HashMap<>();
        List<String> res = new ArrayList<>();
        //Iterate over each String
        for(int i=0; i<cpdomains.length; i++){
            //Split with " " and get int and domain
            String[] arrIntDom = cpdomains[i].split(" ");
            int visits = Integer.parseInt(arrIntDom[0]);
            //second element contains "discuss.leetcode.com"
            dictDom.put(arrIntDom[1],dictDom.getOrDefault(arrIntDom[1],0)+visits);

            //Split the domain in at least 2 //array contains "discuss", "leetcode.com"
            String[] arrSubDom2 = arrIntDom[1].split("\\.",2);
            if(arrSubDom2.length == 2){
                dictDom.put(arrSubDom2[1],dictDom.getOrDefault(arrSubDom2[1],0)+visits);
            }
            //Split the domain in at least 3
            //array contains "discuss", "leetcode" ,"com"
            String[] arrSubDom3 = arrIntDom[1].split("\\.",3);
            if(arrSubDom3.length == 3){
                dictDom.put(arrSubDom3[2],dictDom.getOrDefault(arrSubDom3[2],0)+visits);
            }
        }
        //Construct the result
        for(String key: dictDom.keySet()){
            res.add(Integer.toString(dictDom.get(key))+" "+key);
        }
        return res;
    }

    public static void main(String args[]){
        System.out.println(Arrays.toString("google.mail.com".split("\\.",2))
        );
    }
}
