package leetcode.easy;


/*
     Given a binary tree, check whether it is a mirror of itself
     https://www.youtube.com/watch?v=tNkDZvGsdAs
 */
public class SymmetricTree {
    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            this.val = x;
        }

        public boolean testSymmetricTree(TreeNode t1, TreeNode t2) {
            if (t1 == null && t2 == null) return true;
            if (t1 == null || t2 == null) return false;
            return t1.val == t2.val
                    && testSymmetricTree(t1.left, t2.right)
                    && testSymmetricTree(t1.right, t2.left);
        }
    }
}
