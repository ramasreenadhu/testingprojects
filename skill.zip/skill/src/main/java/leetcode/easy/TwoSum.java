package leetcode.easy;

import java.util.HashMap;

public class TwoSum {

    public static int[] twoSumSol(int[] arr, int val){
        int startVal =0;
        int endVal = arr.length-1;
        int[] result= new int[2];

        for(int j=0; j< arr.length;j++){
            int sum = arr[startVal]+arr[endVal];
            if(sum < val){
                startVal++;
            }else if(sum > val){
                endVal--;
            }else {
                result[0] = arr[startVal];
                result[1] = arr[endVal];

            }
        }
        return  result;
    }

    /* alternative way */

    public static int[] findSum(int[] arr, int target){
        HashMap<Integer,Integer> hashMap = new HashMap<Integer, Integer>();
        for(int i =0; i<arr.length; i++){
            if(hashMap.containsKey(target-arr[i])){
                return new int[]{arr[hashMap.get(target-arr[i])], arr[i]};
            }else{
                hashMap.put(arr[i],i);
            }
        }
        return new int[]{-1,-1};
    }
}

