package leetcode.easy;

/*
Remove invalid characters (Character.isLetterOrDigit(ch)).
Convert all letters to lower cases (use s.toLowerCase()).
Given a string, determine if it is a palindrome, considering only alphanumeric characters and ignoring cases.
*/

public class ValidPalindrome {
    public static boolean isPalindrome(String s) {
        int start = 0;
        int end = s.length() - 1;
        while(start <= end) {
            if (!Character.isLetterOrDigit(start)) {
                start++;
            } else if(!Character.isLetterOrDigit(end)) {
                end--;
            } else {
                if (start <= end && Character.toLowerCase(s.charAt(start)) != Character.toLowerCase(s.charAt(end))) {
                    return false;
                }
                start++;
                end--;
            }
        }
        return true;
    }


    public boolean _isPalindrome(String s) {

        s=s.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        int start=0;
        int end=s.length()-1;
        while(start<end)
        {
            if(s.charAt(start++)!=s.charAt(end--))
                return false;
        }
        return true;
    }

    public static void main(String args[]){

        //System.out.println(ValidPalindrome.isPalindrome("!aba"));
        String rs ="A man, a plan, a canal: Panama".replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
         System.out.println(rs);
    }
}
