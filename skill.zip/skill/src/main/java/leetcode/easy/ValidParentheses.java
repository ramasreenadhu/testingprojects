package leetcode.easy;

import java.util.Stack;

public class ValidParentheses {
    public static boolean validParentheses(String str){
        Stack<Character> stack = new Stack<Character>();
        char[] ch = str.toCharArray();
        for(int i=0 ; i< ch.length; i++){
            if(ch[i]=='(' || ch[i]=='[' || ch[i]=='{'){
                stack.push(ch[i]);
            }else{
                if(!stack.isEmpty() && isParantheseses(stack.peek(),ch[i])){
                    stack.pop();
                }else{
                    return false;
                }
            }

        }

        return stack.isEmpty();
    }

    public static boolean isParantheseses(char left, char right){
        return left =='(' && right==')' || left=='{' && right=='}' || left=='[' && right==']';
    }
}
