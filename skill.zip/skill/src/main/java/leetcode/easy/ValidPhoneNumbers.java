package leetcode.easy;

public class ValidPhoneNumbers {

}
