package leetcode.easy;

/*
 https://www.youtube.com/watch?v=MIJG2SU8Y-g
 */

import java.util.HashMap;
import java.util.Map;

public class VerifyingAnAlienDictionary {
     /*

         h < l -- true
        Input: words = ["hello","leetcode"], order = "hlabcdefgijkmnopqrstuvwxyz"
        Output: true
        Explanation: As 'h' comes before 'l' in this language, then the sequence is sorted.

        Input: words = ["word","world","row"], order = "worldabcefghijkmnpqstuvxyz"
        Output: false
        Explanation: As 'd' comes after 'l' in this language, then words[0] > words[1], hence the sequence is unsorted.

        https://leetcode.com/problems/verifying-an-alien-dictionary/discuss/390005/java-solution-with-HashMap
     */

    Map<Character, Integer> map;
    public boolean isAlienSorted(String[] words, String order) {
        map = new HashMap<>();
        for (int i = 0; i < order.length(); i++) {
            map.put(order.charAt(i), i);
        }
        for (int i = 0; i < words.length - 1; i++) {
            if (compare(words[i], words[i + 1])) return true;
        }
        return false;
    }

    private boolean compare(String s1, String s2) {
        int l1 = s1.length(), l2 = s2.length();
        for (int i = 0, j = 0; i < l1 && j < l2; i++, j++) {
            if (s1.charAt(i) != s2.charAt(j)) {
                if (map.get(s1.charAt(i)) > map.get(s2.charAt(j))) {
                    return false;
                } else {
                    return true;
                }
            }
        }
        if (l1 > l2) return false;
        return true;
    }

    public static void main(String args[]){
       boolean status= new VerifyingAnAlienDictionary().isAlienSorted(new String[]{"lello","heetcode"},"hlabcdefgijkmnopqrstuvwxyz");
       System.out.println(status);
    }
}
