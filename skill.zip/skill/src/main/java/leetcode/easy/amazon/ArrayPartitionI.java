package leetcode.easy.amazon;

/*
    nums =                     [4,50,30,20,10,45]
 After sort:                [4,10,20,30,45,50]
 Pairs will be:             [ (4,10), (20,30), (45,50) ]
 Min of each pair will be =    4,      20,      45

 sum = 4+20+45 = 69
 so simply we can iterate i and increment every time by 2 so that we can add all min in pairs.
 */

import java.util.Arrays;

public class ArrayPartitionI {
    public int arrayPairSum(int[] nums) {

        int sum = 0;
        Arrays.sort(nums);

        for(int i=0; i<nums.length; i=i+2)
            sum += nums[i];

        return sum;
    }
}
