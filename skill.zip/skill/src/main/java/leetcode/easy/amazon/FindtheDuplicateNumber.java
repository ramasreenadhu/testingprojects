package leetcode.easy.amazon;

/*
https://leetcode.com/problems/find-the-duplicate-number/
 */

import java.util.*;

// using binary search
public class FindtheDuplicateNumber {
    public static Map<String,List<Integer>> _findDuplicates(String str){
        String[] strArray = str.split(" ");
        Map<String,List<Integer>> map =new HashMap<String,List<Integer>>();
        Map<String,List<Integer>> rs =new HashMap<String,List<Integer>>();
       // List<String> list = new ArrayList<String>();
        for(int i=0; i< strArray.length; i++){
            if(map.containsKey(strArray[i])){
                map.put(strArray[i],map.get(strArray[i])).add(i);
            }else{
                map.put(strArray[i],new ArrayList<>());
                map.get(strArray[i]).add(i);
            }
        }

        Set<Map.Entry<String,List<Integer>>> set = map.entrySet();
        for(Map.Entry<String,List<Integer>> s : set){
            if(s.getValue().size() >1){
                rs.put(s.getKey(),s.getValue());
            }
        }
        return rs;
    }

    public static void main(String args[]){
       //System.out.println(FindtheDuplicateNumber.findDuplicate(new int[]{4,3,2,1,3}));
    }
}
