package leetcode.easy.amazon;

/*
 https://leetcode.com/problems/powx-n/
 https://www.youtube.com/watch?v=id3HeylW6nQ
 */

public class Powxn {

    public static  double powSol2(double x, int n) {
        double result = 1.0;
        for(int i = n; i != 0; i /= 2, x *= x) {  // i = i/2 = > 4 = 4/2 => 1 =2
            if( i % 2 != 0 ) {
                result *= x;    // odd
            }
        }
        return n < 0 ? 1.0 / result : result;
    }

    // using recurrsive
    public static double pow(double x, int n) {
        if(n == 0)
            return 1;
        if(n<0){
            n = -n;
            x = 1/x;
        }
        return (n%2 == 0) ? pow(x*x, n/2) : x*pow(x*x, n/2);
    }


    public static void main(String args[]){
        System.out.println(Powxn.powSol2( 2.00000,10));
    }
}
