package leetcode.easy.amazon;

/*
 https://leetcode.com/problems/repeated-string-match/
 Given two strings A and B, find the minimum number of times A has to be repeated
 such that B is a substring of it. If no such solution, return -1.
 For example, with A = "abcd" and B = "cdabcdab".
 by repeating A three times (“abcdabcdabcd”),
 B is a substring of A
 so return 3
 */

public class RepeatedStringMatch {
    public static int repeatedStringMatch(String A, String B) {
        StringBuilder sb= new StringBuilder(A);
        int i=1;
        //while length of A is less than B append A to itself.
        while(sb.length()<B.length()){
            i++;
            sb.append(A);
        }
        //if B is substring of A return count which is i
        if(sb.indexOf(B)!=-1)
            return i;
        //else try appending A one more time
        sb.append(A);
        i++;
        //return answer
        return sb.indexOf(B)!=-1?i:-1;
    }

    public static void main(String args[]){
       System.out.println(RepeatedStringMatch.repeatedStringMatch("abcd","cdabcdab"));
    }
}
