package leetcode.easy.apple;

import java.util.HashSet;
import java.util.Set;

public class HappyNumber {
    public static int checkNum(int n) {
        int totalNum = 0;
        while (n >0) {
            int r = n % 10;
            n = n / 10;
            totalNum = totalNum + r * r;
        }
        return totalNum;
    }

    public static boolean isHappyNum(int n){
       Set<Integer> set= new HashSet<Integer>();
        while(n!=1 && !set.contains(n) ) {
            n = checkNum(n);
        }
       return n==1;
    }

    public static void main(String args[]){
        System.out.println(HappyNumber.isHappyNum(82));
    }
}