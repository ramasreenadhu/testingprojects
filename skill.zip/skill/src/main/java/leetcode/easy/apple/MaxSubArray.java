package leetcode.easy.apple;

import java.util.Random;

public class MaxSubArray {
    public static int getMaxSubArray(int[] arr){
        int max=arr[0];
        int maxSofar = arr[0];
        for(int i=1; i<arr.length;i++) {
            maxSofar = Math.max(arr[i],maxSofar+arr[i]);
            max= Math.max(max,maxSofar);
        }
        return max;
    }
    public static void main(String args[]){
       //int rs= MaxSubArray.getMaxSubArray(new int[]{2,1,-3,4,-1,2,1,-5,4});
       //System.out.println(rs);

        Random r = new Random();
        String ssn =String.format("2%08d", r.nextInt(100000000));
        System.out.println(ssn);
    }


}
