package leetcode.easy.apple;

public class MergeSortedNodes {
    public class ListNode{
        int val;
        ListNode next;
        ListNode(int x){
            this.val=x;
        }
    }

    public ListNode mergeNodes(ListNode node1, ListNode node2){
        if(node1==null){
            return node2;
        }
        if(node2==null){
            return node1;
        }
        if(node1==null && node2==null){
            return null;
        }

        ListNode dummy = new ListNode(-1);
        ListNode node =dummy;

        while(node1!=null && node2!=null ){
            if(node1.val <node2.val){
               node.next = new ListNode(node1.val);
            }else{
                node.next = new ListNode(node2.val);
            }
            node=node.next;
        }
        return dummy.next;
    }
}
