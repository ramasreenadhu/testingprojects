package leetcode.easy.apple;

import java.util.Arrays;

public class MergeTwoArrays {
    public static int[] mergeGivenArrays(int[] arr1, int[] arr2){
        int a1 = arr1.length;
        int a2 = arr2.length;
        int[] a3 = new int[a1+a2];
        int i=0;
        int j=0;
        int k=0;
        while(i<a1 && j<a2){
            if(arr1[i] <arr2[j]){
                a3[k++] =arr1[i++];
            }else{
                a3[k++] = arr2[j++];
            }
        }

        if(i<a1){
            a3[k++] = arr1[i++];
        }

        if(j<a2){
            a3[k++] = arr2[j++];
        }
        return a3;
    }

    public static void main(String args[]){
       int[] rs= MergeTwoArrays.mergeGivenArrays(new int[]{10,20,30}, new int[]{1,40,200});
       System.out.println(Arrays.toString(rs));
    }
}
