package leetcode.easy.apple;

import java.util.Stack;

public class MinStack {
    Stack<Integer> main=new Stack<Integer>();
    Stack<Integer> min=new Stack<Integer>();

    public void push(int x){
        main.push(x);
        if(min.isEmpty() || x< min.peek()){
            min.push(x);
        }
    }

    public void pop(){
        int x = main.pop();
        if(x<min.peek()){
            min.pop();
        }
    }

    public int getMin(){
        return min.peek();
    }

    public int top(){
        return main.peek();
    }
}
