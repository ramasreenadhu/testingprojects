package leetcode.easy.apple;

import testCode.ReArranageArr;

public class ReverseInt {
    public static int reverseIntTest(int num){
       int reverse=0;
       while(num!=0) {
           int d = num % 10;
           num = num/10;
           reverse =  reverse*10 +d;
       }
       return reverse;
    }
 public static void main(String args[]){
     int rs = ReverseInt.reverseIntTest(120);
     System.out.println(rs);
 }

}
