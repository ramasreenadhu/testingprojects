package leetcode.easy.apple;

import java.util.Stack;

public class ReverseLinkedList {
    public class ListNode{
        private int val;
        public ListNode next;
        ListNode(int x){
           this.val =x;
        }
    }

    public ListNode reverseList(ListNode node){
        Stack<ListNode> sNode= new Stack<ListNode>();
        while(node!=null){
            sNode.push(node);
            node =node.next;
        }

        ListNode dummy = new ListNode(-1);
        node=dummy;
        while(!sNode.isEmpty()){
            ListNode dnode = sNode.peek();
            node.next= new ListNode(dnode.val);
            node=node.next;
        }
        return dummy.next;
    }
}
