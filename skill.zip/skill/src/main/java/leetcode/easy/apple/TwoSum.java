package leetcode.easy.apple;

import java.util.Arrays;

public class TwoSum {
    public static int[] twoSumArray(int[] arr, int target){
        if(arr.length==1){
            return arr;
        }
        int len = arr.length;
        int start=0; int end=len-1;
        int[] rs = new int[2];
        for(int i=0; i<len; i++){
            if(arr[start]+arr[end]<target){
                start++;
            }else if(arr[start]+arr[end]>target){
                end--;
            }else{
                rs[0]=arr[start];
                rs[1]=arr[end];
            }
        }
        return rs;
    }
    public static void main(String args[]){
        System.out.println(Arrays.toString(TwoSum.twoSumArray(new int[]{2,7,11,15},18)));
    }
}
