package leetcode.easy.salesforce;

import java.util.*;

public class Friendship {

    // This is for you to implement
    //
    // This method takes 2 String parameters and
    // makes them "friends" of each other.
    //
    // Note: The order of names does not matter
    // Note: Do not forget to write tests to have good test coverage for this
    // method
    Map<String, List<String>> friendsMap = new HashMap<>();
    public void makeFriend(String nameKey, String friendName) {
        List<String> existingFriends1 = friendsMap.getOrDefault(nameKey,new ArrayList<String>());
        existingFriends1.add(friendName);
        List<String> existingFriends2 = friendsMap.getOrDefault(friendName,new ArrayList<String>());
        existingFriends2.add(nameKey);
    }


    // This is for you to implement
    //
    // This method takes 2 String parameters and
    // makes them no longer friends of each other.
    //
    // Note: The order of names does not matter
    // Note: Do not forget to write tests to have good test coverage for this
    // method
    public void unmakeFriend(String nameKey, String friendName) {
        List<String> existingFriends1 = friendsMap.get(nameKey);
        if(existingFriends1!=null && existingFriends1.contains(friendName)){
            existingFriends1.remove(friendName);
        }
        List<String> existingFriends2 = friendsMap.get(friendName);
        if(existingFriends2!=null && existingFriends2.contains(nameKey)){
            existingFriends2.remove(nameKey);
        }
    }


    // This is for you to implement
    //
    // This method takes a single argument (name) and
    // returns all immediate "friends" of that name
    //
    // For example, A & B are friends, B & C are friends, and C & D are friends.
    // getDirectFriends(B) would return A and C
    // getDirectFriends(D) would return C
    //
    // Note: It should not return duplicate names
    // Note: Do not forget to write tests to have good test coverage for this
    // method
    public List<String> getDirectFriends(String nameKey) {
        return friendsMap.get(nameKey);
    }


    // This is for you to implement (Seniors and above)
    //
    // This method takes a single argument (name) and
    // returns all the indirect "friends" of that name
    //
    // For example, A & B are friends, B & C are friends, and C & D are friends.
    // getInirectFriends(A) would return C and D
    //
    // Note: It should not return duplicate names
    // Note: Do not forget to write tests to have good test coverage for this
    // method

    public List<String> getIndirectFriends(String nameKey) {

        List<String> result = new ArrayList<String>();
        if(friendsMap.get(nameKey)==null ||
                friendsMap.get(nameKey)==null ||
                friendsMap.get(nameKey).isEmpty()) {
            return result;
        }
        Set<String> resultSet = new HashSet<>();
        Set<String> visited = new HashSet<>();
        visited.add(nameKey);
        traverse(nameKey,resultSet,visited);

        /**
         * remove direct friends or own name.
         */
        result.addAll(resultSet);
        result.removeAll(friendsMap.get(nameKey));
        if(result.contains(nameKey)){
            result.remove(nameKey);
        }
        return result;
    }

    private void traverse(String anotherFriend, Set<String> resultSet, Set<String> visited) {
        List<String> friends = friendsMap.get(anotherFriend);
        for(String friend:friends){
            if(!visited.contains(friend)){
                visited.add(friend);
                resultSet.add(friend);
                traverse(friend,resultSet,visited);
            }
        }

    }
}


