package leetcode.easy.sdet;

public class test {
    public static void main(String args[]){
        String body = "{\n" +
                "        \"partyId\": \"%s\",\n" +
                "            \"taxId\": \"EAAQF2DgY4QKrAAYdw4CnEdUQA==\",\n" +
                "            \"channelId\": \"Web\",\n" +
                "            \"startD\": \"2019-11-04T23:51:26.000Z\",\n" +
                "            \"nbOfferId\": \"PL003\",\n" +
                "            \"cmsId\": \"1\",\n" +
                "            \"modifyTs\": \"2019-08-26T20:20:10.802Z\",\n" +
                "            \"creditAcctId\": 383788,\n" +
                "            \"ranking\": 1,\n" +
                "            \"attributes\":\"{ \\\"income\\\":100100, \\\"loan_amount\\\":20000, \\\"loan_purpose\\\":\\\"debt_consolidation\\\",\\\"curr_addr_line_1\\\": { \\\"value\\\":\\\"EAAQRij+XReqpUPFfgktJgRLCA==\\\",\\\"key\\\":\\\"low_npi-pii_fek\\\",\\\"version\\\":\\\"1\\\" },\\\"curr_addr_line_2\\\": { \\\"value\\\":\\\"\\\",\\\"key\\\":\\\"\\\",\\\"version\\\":\\\"\\\" },\\\"curr_city_name\\\": { \\\"value\\\":\\\"EAAQH9IfKdKETPGbMja3aROvkw==\\\",\\\"key\\\":\\\"low_npi-pii_fek\\\",\\\"version\\\":\\\"1\\\" },\\\"curr_state_name\\\": { \\\"value\\\":\\\"EAAQm4EnYb1uQNPaYhxJZicFwA==\\\",\\\"key\\\":\\\"low_npi-pii_fek\\\",\\\"version\\\":\\\"1\\\" },\\\"curr_country_name\\\": { \\\"value\\\":\\\"\\\",\\\"key\\\":\\\"\\\",\\\"version\\\":\\\"\\\" },\\\"curr_postal_code\\\": { \\\"value\\\":\\\"EAAQg2UPhv5WubTtmnlO030epQ==\\\",\\\"key\\\":\\\"low_npi-pii_fek\\\",\\\"version\\\":\\\"1\\\" },\\\"curr_postal_code_ext\\\": { \\\"value\\\":\\\"\\\",\\\"key\\\":\\\"\\\",\\\"version\\\":\\\"\\\" },\\\"curr_addr_mod_ts\\\":\\\"2019-06-15 08:09:52.836264\\\" }\",\n" +
                "            \"offerEligibilityId\": \"399c48d3f97f3c49b58bf03dcc9cfa0f\"\n" +
                "    }\n";
        System.out.println(body);
    }

}
