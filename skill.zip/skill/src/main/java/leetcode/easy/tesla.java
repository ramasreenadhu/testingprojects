package leetcode.easy;

public class tesla {
}
