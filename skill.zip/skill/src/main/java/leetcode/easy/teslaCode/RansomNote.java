package leetcode.easy.teslaCode;

/*
   write a function that will return true if the ransom note can be constructed from the magazines ; otherwise, it will return false.
   Input: ransomNote = "a", magazine = "b" Output: false
   Input: ransomNote = "aa", magazine = "ab" Output: false
   Input: ransomNote = "aa", magazine = "aab"  Output: true

    https://www.youtube.com/watch?v=-moq8WgNRsY
 */

public class RansomNote {
    public static boolean canConstruct(String ransomNote, String magazine) {
        int[] hash = new int[26];
        for (char c : magazine.toCharArray())
            ++hash[c-'a'];
        for (char c : ransomNote.toCharArray())
            if (--hash[c-'a'] <0) /// ransomNote = "aaa", magazine = "aab"
                return false;
        return true;
    }



    public static void main(String[] args){
       System.out.println(RansomNote.canConstruct("aaa","aaab"));
    }

}
