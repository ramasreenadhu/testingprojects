package leetcode.medium;

import testCode.LeetCode;

public class AddTwoNumbers {

     /*
        https://www.youtube.com/watch?v=qOyO7MCd1G8&t=964s
        https://leetcode.com/problems/add-two-numbers/
        Input: (2 -> 4 -> 3) + (5 -> 6 -> 4)
        Output: 7 -> 0 -> 8

        understanding dummy : https://www.youtube.com/watch?v=3O_f_sk3mFc
     */

     class ListNode{
         int val;
         ListNode next;
         ListNode(int x){
             this.val=x;
         }
     }

    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {

        ListNode dummy = new ListNode(0);
        ListNode l3 = dummy;
        int carry =0;

        //  12+9 11%10 =1 11/10 =1
        while(l1!=null && l2!=null){
            int digitalVal = (l1.val + l2.val+carry)%10;
            carry = (l1.val + l2.val+carry)/10;
            ListNode ll = new ListNode(digitalVal);
            l3.next=ll;
            l1= l1.next;
            l2= l2.next;
        }

        while(l1!=null){
            int digitalVal = (l1.val +carry)%10;
            carry = (l1.val +carry)/10;
            ListNode ll = new ListNode(digitalVal);
            l3.next=ll;
            l1= l1.next;

        }

        while(l2!=null){
            int digitalVal = (l2.val +carry)%10;
            carry = (l2.val +carry)/10;
            ListNode ll = new ListNode(digitalVal);
            l3.next=ll;
            l2= l2.next;
        }

        if(carry!=0){
            ListNode ll =new ListNode(carry);
            l3.next =ll;
            l3 = ll;
        }

        return dummy.next;
    }

    public static void main(String args[]){
     }
}
