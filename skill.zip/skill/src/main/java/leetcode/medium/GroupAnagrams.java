package leetcode.medium;

import java.util.*;

public class GroupAnagrams {

      /*
    https://www.youtube.com/watch?v=0I6IL3TnIZs
    https://leetcode.com/problems/group-anagrams/
       Input: ["eat", "tea", "tan", "ate", "nat", "bat"],
      Output:[["ate","eat","tea"],["nat","tan"],["bat"]]
     */

    public static List<List<String>> groupAnagrams(String[] strs) {
        if (strs.length == 0) return new ArrayList();
        Map<String, List> ans = new HashMap<String, List>();
        for (String s : strs) {
            char[] ca = s.toCharArray();
            Arrays.sort(ca);
            String key = String.valueOf(ca);

            if (!ans.containsKey(key))
                ans.put(key, new ArrayList());{
            }

            ans.get(key).add(s);
        }
        return new ArrayList(ans.values());
    }
}
