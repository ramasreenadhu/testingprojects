package leetcode.medium;

import java.util.PriorityQueue;

/*
   A PriorityQueue is used when the objects are supposed to be processed based on the priority
   The elements of the priority queue are ordered according to the natural ordering

   Input: [3,2,1,5,6,4] and k = 2
   Output: 5
   https://www.youtube.com/watch?v=htqsw5NQMo4

   Better Understanding:
   // Creating empty priority queue
        PriorityQueue<Integer> pQueue = new PriorityQueue<Integer>();

        // Adding items to the pQueue using add()
        pQueue.add(20);
        pQueue.add(15);
        pQueue.add(10);

        // Printing the top element of PriorityQueue
        System.out.println(pQueue.peek());   // 10

        // Printing the top element and removing it
        // from the PriorityQueue container
        System.out.println(pQueue.poll()); // 10

        // Printing the top element again
        System.out.println(pQueue.peek()); // 15
 */
public class KthLargestElementInArray {
    public static int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> largeK = new PriorityQueue<Integer>(k + 1);
        for(int el : nums) {
            largeK.add(el);
            if (largeK.size() > k) {
                largeK.poll();
            }
        }
        return largeK.poll();
    }
    public static void main(String args[])
    {
        int k =KthLargestElementInArray.findKthLargest(new int[]{3,2,1,5,6,4},2);
        System.out.println(k);
    }

}
