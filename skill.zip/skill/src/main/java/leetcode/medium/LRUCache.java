package leetcode.medium;

public class LRUCache {
}
