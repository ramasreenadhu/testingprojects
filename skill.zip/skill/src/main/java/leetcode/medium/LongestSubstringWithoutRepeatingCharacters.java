package leetcode.medium;

import java.util.HashSet;
import java.util.Set;

/*
    https://www.youtube.com/watch?v=aIrbWbON63M
 */
public class LongestSubstringWithoutRepeatingCharacters {
    int left=0, right=0,maxLenght=0;
    Set<Character> set =new HashSet<Character>();
    public int findLongestSubString(String str){
       char[] ch= str.toCharArray();
       for(int i=0; i<ch.length; i++){
           if(!set.contains(ch[i])){
               set.add(ch[i]);
               right++;
               maxLenght=Math.max(maxLenght,right-left);
           }else{
               set.remove(ch[left]);
               left++;
           }
       }
       return maxLenght;
    }

    public static void main(String args[]){
       System.out.println(new LongestSubstringWithoutRepeatingCharacters().findLongestSubString("aabcbb"));
    }
}
