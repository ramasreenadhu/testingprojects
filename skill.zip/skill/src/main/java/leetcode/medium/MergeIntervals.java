package leetcode.medium;

/*
   https://www.youtube.com/watch?v=O44oSOfNvLM&t=378s
   Input: [[1,3],[2,6],[8,10],[15,18]]
   Output: [[1,6],[8,10],[15,18]]
   Explanation: Since intervals [1,3] and [2,6] overlaps, merge them into [1,6].
 */

import java.util.*;

public class MergeIntervals {

    public static int[][] merge(int[][] intervals) {
        if (intervals.length <= 1)
            return intervals;

        // Sort by ascending starting point
        Arrays.sort(intervals, (i1, i2) -> Integer.compare(i1[0], i2[0]));
        //[[1, 3],
        //[2, 4],
        //[9, 10]]

        List<int[]> result = new ArrayList<>();
        int[] newInterval = intervals[0];
        result.add(newInterval); // [1,3]
        for (int[] interval : intervals) { // [1,3]
            if (interval[0] <= newInterval[1]) // 1 <=3 ;
                newInterval[1] = Math.max(newInterval[1], interval[1]);
            else {
                newInterval = interval;
                result.add(newInterval);
            }
        }
        return result.toArray(new int[result.size()][]);
    }
    public static void main(String args[]){
        MergeIntervals.merge(new int[][]{{9,10},{1,3}, {2,4}});
    }
}
