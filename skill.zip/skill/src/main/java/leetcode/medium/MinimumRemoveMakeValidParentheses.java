package leetcode.medium;

import java.util.Stack;

public class MinimumRemoveMakeValidParentheses {
    public static String minRemoveToMakeValid(String s) {
        StringBuffer res=new StringBuffer();
        Stack<Character> ch=new Stack<>();
        Stack<Integer>pos=new Stack<>();
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)=='('||s.charAt(i)=='{'||s.charAt(i)=='[')
            {
                ch.push(s.charAt(i));
                pos.push(i);
            }
            else if(ch.size()>0&&s.charAt(i)==')'&&ch.peek()=='(')
            {
                ch.pop();
                pos.pop();
            }
            else if(ch.size()>0&&s.charAt(i)=='}'&&ch.peek()=='{')
            {
                ch.pop();
                pos.pop();
            }
            else if(ch.size()>0&&s.charAt(i)==']'&&ch.peek()=='[')
            {
                ch.pop();
                pos.pop();
            }
            else if(s.charAt(i)==')'||s.charAt(i)==']'||s.charAt(i)=='}')
            {
                ch.push(s.charAt(i));
                pos.push(i);
            }
        }
        for(int i=0;i<s.length();i++)
        {
            if(!pos.contains(i))
            {
                res.append(s.charAt(i));
            }
        }
        return res.toString();
    }

    public static void main(String args[]){
       String rs = MinimumRemoveMakeValidParentheses.minRemoveToMakeValid("lee(t(c)o)de)");
       System.out.println(rs);
    }
}
