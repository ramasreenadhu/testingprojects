package leetcode.medium;

/*
Input: s = "lee(t(c)o)de)"
Output: "lee(t(c)o)de"
Explanation: "lee(t(co)de)" , "lee(t(c)ode)" would also be accepted.
 */

import java.util.Stack;

public class MinimumRemoveToMakeValidParentheses {
    public static String minRemoveToMakeValid2(String s) {
        Stack<Integer> stack = new Stack<Integer>();
        String[] arr = s.split("");
        for (int i = 0; i < arr.length; i++) {
            if ("(".equals(arr[i])) {  //"lee(t(c)o)de)"
                stack.push(i);
            } else if (")".equals(arr[i])) {
                if (!stack.isEmpty()) {
                    stack.pop();
                } else {
                    arr[i] = "";
                }
            }
        }
        while(!stack.isEmpty()) {
            arr[stack.pop()] = "";
        }
        return String.join("", arr);
    }

    public static void main(String args[]){
       String rs = MinimumRemoveToMakeValidParentheses.minRemoveToMakeValid2("lee(t(c)o)de)");
       System.out.println(rs);
    }

}
