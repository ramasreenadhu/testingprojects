package leetcode.medium;

import java.util.Arrays;
/*
 https://www.youtube.com/watch?v=hPd4MFdg8VU&t=432s
 */

public class NextPermutations {
    public static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    public static void reverse(int[] nums, int i, int j) {
        while(i<j) {
            swap(nums, i,j);
            i++;
            j--;
        }
    }
    public static void nextPermutation(int[] nums) {

        if(nums.length==1) {
            return;
        } else if(nums.length == 2) {
            swap(nums, 0, 1);
        } else {
            int end = nums.length-2;
            while(end>=0 && nums[end] >= nums[end+1]) end--;

            reverse(nums, end+1, nums.length-1);

            if(end == -1) return;
            int newInd = end+1;

            while(newInd< nums.length && nums[newInd]<= nums[end]) newInd++;

            swap(nums, end, newInd);

        }
    }
  public static void main(String args[]){
        NextPermutations.nextPermutation(new int[]{1,2,7,9,6,4,1});
  }
}
