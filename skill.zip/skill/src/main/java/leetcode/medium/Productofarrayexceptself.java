package leetcode.medium;

/*
Given an array nums of n integers where n > 1,  return an array output such that output[i] is equal to the product of all the elements of nums except nums[i].
Example: Input:  [1,2,3,4] => Output: [24,12,8,6]
https://www.youtube.com/watch?v=5ZihTbQ_X6o
*/

import java.util.Arrays;

public class Productofarrayexceptself {


    public static int[] productExceptSelfV2(int[] nums) {
        int[] left = new int[nums.length];
        int[] right = new int[nums.length];

        left[0] = 1;
        for (int i = 1; i < nums.length; i++) {
            left[i] = left[i-1] * nums[i-1];
            // left[1] = 1*1 =1, left[2]=1*2=2, left[3] =2*3=6 left[4]=6*4 =24
            // left[] ={1,2,6,24}
        }

        right[nums.length - 1] = 1;
        for (int i = nums.length - 2; i >= 0; i--) {
            right[i] = right[i+1] * nums[i+1];
            // right[1] = 1*
        }

        int[] product = new int[nums.length];
        for (int i = 0; i < product.length; i++) {
            product[i] = left[i] * right[i];
        }

        return product;
    }

    //my version
    public static int[] productOfEle(int[] arr){
       int[] rs= new int[arr.length];
       int k = arr.length;
       for(int i=0; i<arr.length;i++){
           int sum=1;
           for(int j=0; j<k; j++){
               if(i==j){
                   continue;
               }
               sum = sum*arr[j];
           }
           rs[i] = sum;
       }
       return rs;
    }

    public static void main(String args[]){
        System.out.println(
                Arrays.toString(Productofarrayexceptself.productExceptSelfV2(new int[]{1,2,3,4})));
    }
}
