package leetcode.medium;

/*
https://www.youtube.com/watch?v=bqN9yB0vF08
Given an array of integers and an integer k,
you need to find the total number of continuous subarrays whose sum equals to k.
Example 1:
Input:nums = [3,4,7,2,-3,1,4,2], k = 7
steps:
1.sum : start with 0 +3 = 3, 3+4=7, 7+7=14, 14+2=16, 16-3 =13,..
2.add to map :{0,3,7,14,16,13,14,18,20}
3.subtract : map -7 (since k is 7)
=> 0-7 = -7, 3-7=-4, 7-7=0, 14-7=7, 16-7=9, 13-7=6, 14-7=7, 18-7=11,20-7=13
4.count is 4
{0:1,} // count 0 because -7 not available step2
{3:1,} // count 0 because -4 not available step2
{7:1,} // count 1 because 0 available step2
{14:1,} // count 1 because 7 available step2
{16:1,} // count 0 because 9 not available step2
{14:1,} // count 1 because 7 available step2
{18:1,} // count 0 because 11 not available step2
{20:1,} // count 1 because 13 available step2

Time/Space Complexity
Time Complexity: O(n)
Space Complexity: O(n)

 */

import java.util.HashMap;
import java.util.Map;

public class SubarraySumEqualsK {
    public static int subarraySum(int[] nums, int k) {
        int sum = 0, result = 0;
        Map<Integer, Integer> preSum = new HashMap<>();
        preSum.put(0, 1);
        for (int i = 0; i < nums.length; i++) {
            sum += nums[i];
            if (preSum.containsKey(sum - k)) {
                result += preSum.get(sum - k);
            }
            preSum.put(sum, preSum.getOrDefault(sum, 0) + 1);
        }

        System.out.println(preSum.toString());

        return result;
    }

    public static void main(String args[]){
        int rs = SubarraySumEqualsK.subarraySum(new int[]{3,4,7,2,-3,1,4,2,1},7);
         System.out.println(rs);
    }
}
