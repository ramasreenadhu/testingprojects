package leetcode.medium;

import java.util.*;

public class TestArrayList {
    public static void main(String args[]){

    }
}
