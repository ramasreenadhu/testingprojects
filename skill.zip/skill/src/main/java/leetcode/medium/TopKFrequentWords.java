package leetcode.medium;

/*
 Input: ["i", "love", "leetcode", "i", "love", "coding"], k = 2
Output: ["i", "love"]
Explanation: "i" and "love" are the two most frequent words.
Note that "i" comes before "love" due to a lower alphabetical order.
O(nlogk) time & O(n) space
 */

import java.util.*;

public class TopKFrequentWords {
    public static List<String> topKFrequent(String[] words, int k) {

        List<String> result = new LinkedList<>();
        Map<String, Integer> map = new HashMap<>();
        for(int i=0; i<words.length; i++)
        {
            if(map.containsKey(words[i]))
                map.put(words[i], map.get(words[i])+1);
            else
                map.put(words[i], 1);
        }

//        PriorityQueue<Map.Entry<String, Integer>> pq = new PriorityQueue<>(
//                (a,b) -> a.getValue()==b.getValue() ? b.getKey().compareTo(a.getKey()) : a.getValue()-b.getValue()
//        );
//
//        for(Map.Entry<String, Integer> entry: map.entrySet())
//        {
//            pq.offer(entry);
//            if(pq.size()>k)
//                pq.poll();
//        }
//
//        while(!pq.isEmpty())
//            result.add(0, pq.poll().getKey());

        return result;
    }

    public static void checkMap(){
        Map<String,Integer> map =new HashMap<String,Integer>();
        map.put("rama",2);
        map.put("krishna",1);
        for(String val: map.keySet()){
            if(map.get(val)==2){
                System.out.println(val);
            }
        }
    }

    public static void main(String args[]){
        //List<String> rs = TopKFrequentWords.topKFrequent(new String[]{"i", "love", "leetcode", "i", "love", "coding"},2);
        // System.out.println(rs);
        TopKFrequentWords.checkMap();
    }
}

 /*   Comparator<String> stringLengthComparator = new Comparator<String>() {
        @Override
        public int compare(String s1, String s2) {
            return s1.length() - s2.length();
        }
    };


        The above Comparator can also be created using lambda expression like this =>
        Comparator<String> stringLengthComparator = (s1, s2) -> {
            return s1.length() - s2.length();
        };

        Which can be shortened even further like this =>
        Comparator<String> stringLengthComparator = Comparator.comparingInt(String::length);


    // Create a Priority Queue with a custom Comparator
    PriorityQueue<String> namePriorityQueue = new PriorityQueue<>(stringLengthComparator);
    */