package leetcode.medium;

import java.util.HashSet;
import java.util.Set;

/*
Input: s = "leetcode", wordDict = ["leet", "code"]
Output: true
Explanation: Return true because "leetcode" can be segmented as "leet code".
https://www.youtube.com/watch?v=iWenZCZEBIA&t=5s
 */
public class WordBreak {
    public static boolean wordBreak(String s, Set<String> dict) {
        boolean[] f = new boolean[s.length() + 1];
        f[0] = true;

        //Second DP
        for(int i=1; i <= s.length(); i++){
            for(int j=0; j < i; j++){
                if(f[j] && dict.contains(s.substring(j, i))){
                    f[i] = true;
                    break;
                }
            }
        }
        return f[s.length()];
    }

    public static void main(String args[]){
        Set<String> set = new HashSet<String>();
        set.add("leet");
        set.add("code");
        WordBreak.wordBreak("leetcode", set );
    }
}
