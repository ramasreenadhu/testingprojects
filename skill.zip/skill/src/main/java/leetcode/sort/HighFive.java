package leetcode.sort;

/*
  Given a list of scores of different students,
  return the average score of each student's top five scores
  in the order of each student's id.

  https://www.youtube.com/watch?v=3iqC5J4l0Cc
 */

import java.util.PriorityQueue;
import java.util.TreeMap;

/* The Treemap is sorted according to the natural ordering of its keys

           A PriorityQueue is used when the objects are supposed to be processed based on the priority
           The elements of the priority queue are ordered according to the natural ordering
              pQueue.add(20);
              pQueue.add(15);
              pQueue.add(10);
        // Printing the top element of PriorityQueue
        System.out.println(pQueue.peek());   // 10

           Using a Tree map  as we need to return the output  in the order of each student's id.
          Using Priotiy queue as we need the average of top five scores
          Priority queue will store elements in order*/

public class HighFive {
    public static int[][] highFive(int[][] items) {
        TreeMap<Integer, PriorityQueue<Integer>> map = new TreeMap<>();
        for(int i=0;i<items.length;i++)
        {
            int id = items[i][0];
            int score = items[i][1];
            if(!map.containsKey(id))
            {
                PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
                priorityQueue.offer(score);
                map.put(id,priorityQueue);
            }

            else
            {
                PriorityQueue<Integer> priorityQueue = map.get(id);
                priorityQueue.offer(score);

                //we need only top five scores. so remove elements when the priorityQueue size exeeds five
                if(priorityQueue.size()>5)
                {
                    //remove smalles element in queue
                    priorityQueue.poll();
                }
            }
        }

        //intialize otput array
        int[][] outputArray = new int[map.size()][2];
        //array index
        int index=0;
        //loop through map to populate output array
        for(int id : map.keySet())
        {
            //populate student id
            outputArray[index][0] = id;
            //calculate avg student score
            PriorityQueue<Integer> priorityQueue = map.get(id);
            int sum =0;
            while(!priorityQueue.isEmpty())
            {
                sum = sum + priorityQueue.poll();
            }
            //populate avg student score
            outputArray[index][1] = sum/5;
            //increment array Index
            index++;
        }

        return outputArray;
    }

    public static void main(String args[]){
        int[][] grid = new int[][]{{1,91},{1,92},{2,93},{2,97},{1,60},{2,77},{1,65},{1,87},{1,100},{2,100},{2,76}};
        int[][] processedGrid  = HighFive.highFive(grid);
        System.out.println(processedGrid[0][0]); // student ID 1
        System.out.println(processedGrid[0][1]); // average 87
    }

}
