package leetcode.testleet;

import java.util.Arrays;

public class ArrayPartiation {
    public static int getMinMaxSum(int[] nums){
        if(nums.length<=1){
        return nums[0];
    }
       Arrays.sort(nums);
    int n =nums.length-1;
    int maxSum=0;
    int i=0;
       while(i<=n){
        int k = Math.min(nums[i],nums[i+1]);
        maxSum = Math.max(maxSum,maxSum+k);
        i=i+2;
    }
     return maxSum;
}

    public static void main(String args[]){
        int rs = ArrayPartiation.getMinMaxSum(new int[]{1,4,3,2});
        System.out.println(rs);
    }
}
