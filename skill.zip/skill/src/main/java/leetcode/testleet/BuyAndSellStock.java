package leetcode.testleet;

public class BuyAndSellStock {
    public static int buySellStock(int[] prices){
        int n=prices.length;
        if(n<=1){
            return prices[0];
        }

        int maxProfit=0;
        int minPrice=Integer.MAX_VALUE;

        for(int i=0; i<prices.length-1; i++){
            minPrice = Math.min(minPrice,prices[i]);
            maxProfit = Math.max(maxProfit,prices[i]-minPrice);
        }
        return maxProfit;
    }

    public static int multiBuySellStock(int[] prices){
        int n=prices.length;
        if(n<=1){
            return prices[0];
        }

        int maxProfit=0;
        //int minPrice=Integer.MAX_VALUE;

        for(int i=1; i<prices.length-1; i++){
            //minPrice = Math.min(minPrice,prices[i]);
            if(prices[i-1]<prices[i]) {
                maxProfit = maxProfit + prices[i] - prices[i-1];
            }
        }
        return maxProfit;
    }

    public static void main(String args[]){
        int k =BuyAndSellStock.buySellStock(new int[]{7,1,5,3,6,4});
        System.out.println(k);

        int m =BuyAndSellStock.multiBuySellStock(new int[]{7,1,5,3,6,4});
        System.out.println(m);
    }
}
