package leetcode.testleet;

public class ConvertTreeNodeFromArray {
    class TreeNode{
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x){
            val=x;
        }
    }

    public void getTreeNodeOnArray(int[] nums){
        int start=0;
        int end= nums.length-1;
        TreeNode node = helper(nums,start,end);
    }

    public TreeNode helper(int[] nums, int start, int end){
        int mid= start+end/2;
        TreeNode root = new TreeNode(nums[mid]);
        root.left = helper(nums,start,mid-1);
        root.right = helper(nums,mid+1,end);
        return root;
    }
}
