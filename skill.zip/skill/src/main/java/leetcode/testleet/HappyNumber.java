package leetcode.testleet;

public class HappyNumber {

    public int findSum(int num) {
        int totalSum = 0;
        int digit = 0;
        while (num > 0) {
            digit = num % 10;
            num = num / 10;
            totalSum = totalSum + (digit * digit);
        }
        return totalSum;
    }

    public boolean isHappyNum(int num){
        while(num!=1){
            num = findSum(num);
        }

        if(num==1){
            return true;
        }

        return false;
    }

    public static void main(String args[]){
       System.out.println(new HappyNumber().isHappyNum(19));
    }

}