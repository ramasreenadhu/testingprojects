package leetcode.testleet;

public class MergeTwoSortedArrays {
    public static int[] mergeTwoArrays(int[] a, int[] b){
        int al = a.length;
        int bl = b.length;
        int[] c = new int[al+bl];
        int i=0, j=0,k=0;
        while(i<al && j<bl){
            if(a[i] < b[j]){
                c[k++] = a[i++];
            }else{
                c[k++]= b[j++];
            }
        }
        while(i<al){
            c[k++] = a[i++];
        }

        while(j<bl){
            c[k++] = b[j++];
        }

        return c;
    }
}
