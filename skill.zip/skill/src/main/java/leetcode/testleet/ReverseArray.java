package leetcode.testleet;

import java.util.Arrays;

public class ReverseArray {
    public static void main(String args[]){
        int[] b = new int[]{1,1,0,2,3,4,5};
        int k = b.length;
        for(int i =0; i<k/2; i++){
         int temp = b[i];
         b[i]= b[k-1-i];
         b[k-1-i] = temp;
        }
        System.out.println(Arrays.toString(b));
    }
}
