package leetcode.testleet;

import java.util.Arrays;

public class TwoSum {
    public static int[] addNums(int[] num, int target){

        if(num.length<=1){
            return num;
        }
        Arrays.sort(num);
        int start = 0;
        int end = num.length-1;
        for(int i=0; i<end;i++){
            if(target<num[start]+num[end]){
                end --;
            }else if(target<num[start]+num[end]){
                start++;
            }else{
                return new int[]{start,end};
            }
        }
        return new int[]{-1,-1};
    }

    public static void main(String args[]){
        int[] rs = TwoSum.addNums(new int[]{10,20,30,40,50}, 50);
        System.out.println(Arrays.toString(rs));
    }
}
