package leetcode.testleet;

public class ValidAnagram {
    public static boolean isValidAnagram(String s1, String s2){
        if(s1.length()!=s2.length()){
            return false;
        }
        int[] ch = new int[26];
        for(int i=0; i<s1.length();i++){
            ch[s1.charAt(i)-'a']++;
            ch[s1.charAt(i)-'a']--;
        }

        for(int c: ch){
            if(c!=0){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args){
        System.out.println(ValidAnagram.isValidAnagram("tea","eat"));
    }
}
