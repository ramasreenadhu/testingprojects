package leetcode.testleet;

import java.util.Stack;

public class ValidateParentheses {
    public static boolean isValidParentheses(String str){
        if(str.isEmpty()){
            return false;
        }

        Stack<Character> stack = new Stack<Character>();
        for(int i=0; i<str.length(); i++){
            if(str.charAt(i)=='(' || str.charAt(i)=='{' || str.charAt(i)=='['){
                stack.push(str.charAt(i));
            }else if(!stack.isEmpty() && isvalidPatren(stack.peek(),str.charAt(i))){
                stack.pop();
            }
        }
        return stack.isEmpty();
    }

    public static boolean isvalidPatren(char left, char right){
        if(left=='{' && right=='}' || left=='(' && right==')' || left=='[' && right==']' ){
            return true;
        }
        return false;
    }

    public static void main(String args[]){
        System.out.println(ValidateParentheses.isValidParentheses("({[]})"));
    }
}
