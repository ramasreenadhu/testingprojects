package leetcode.twopointers;

import java.util.Arrays;

/**
 * This class contains method which merge two given sorted arrays
 * return new int[]
 **/

public class MergeSortedArray {
    /*
        Assume Given arrays arr1 & arr2 are always sorted and may contains duplicate,negative numbers
        Length of arr1 & arr2 might be different
     */
    public static int[] mergeSortedArrays(int[] arr1, int[] arr2)
    {
        if(arr1.length==0){
            return arr2;
        }

        if(arr2.length==0){
            return arr1;
        }

        int n= arr1.length;
        int m= arr2.length;
        int[] arr3 = new int[n+m];
        int i=0, j=0, k=0;
        while(i<n && j<m){
            if (arr1[i] < arr2[j]) {
                arr3[k++] = arr1[i++];
            }else{
                arr3[k++]= arr2[j++];
            }
        }

        if(i<n){
            arr3[k++] = arr1[i];
        }

        if(j<m){
            arr3[k++] = arr2[j];
        }

        return arr3;
    }

    public static void main (String[] args) {
        int[] arr1 = {1,2,3,0,0,0};
        int[] arr2 = {2,5,6};

       int[] arr= mergeSortedArrays(arr1, arr2);
       System.out.println(Arrays.toString(arr));

    }
}
