package leetcode.twopointers;

import java.util.Arrays;

public class MoveZeros {

    public static int[] zeroEnds(int[] arr){
        if(arr.length==0){
            return arr;
        }

        int n = arr.length;
        int j=0;
        for(int i=0; i<n;i++){
            if(arr[i]!=0){
                arr[j++]= arr[i];
            }
        }

        for(int i=j; j<n;j++){
            arr[i]=0;
        }

        return arr;
    }

    public static void main(String args[]){
        int[] rs = MoveZeros.zeroEnds(new int[]{0,1,2,0,0});
        System.out.println(Arrays.toString(rs));
    }
}
