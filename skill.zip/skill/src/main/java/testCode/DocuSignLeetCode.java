package testCode;

import java.util.Stack;

public class DocuSignLeetCode {

    public static boolean isValidAnagram(String s, String t){
        if(s.length()!=t.length()){
            return false;
        }
        int[] count = new int[26];

        for(int i=0; i<s.length(); i++){
          count[s.charAt(i)-'a']++;
          count[t.charAt(i)-'a']--;
        }

        for(int k : count){
            if(k!=0){
                return false;
            }
        }

        return true;
    }



    /*
   https://www.youtube.com/watch?v=tQur3kprZQk
   Input: 1->2->3->4->5->NULL
   Output: 5->4->3->2->1->NULL
   */
    public static LeetCode.ListNode reverseLinkedListNode(LeetCode.ListNode node){
        Stack<LeetCode.ListNode> stackNode = new Stack<LeetCode.ListNode>();
        while(node!=null){
            stackNode.push(node);
            node = node.next;
        }

        LeetCode.ListNode dummy=  new LeetCode.ListNode(-1);
        node= dummy;
        while(!stackNode.isEmpty()){
            LeetCode.ListNode current = stackNode.pop();
            node.next= new LeetCode.ListNode(current.val);
            node=node.next;
        }
        return dummy.next;
    }

    public static void main(String args[]){
        System.out.println(DocuSignLeetCode.isValidAnagram("anagram", "nagaram"));
    }
}
