package testCode;

public class FindMinimum {

    public static int getMinFromArray(int[] arr){

        int minVal = arr[0];

        for(int i =0; i< arr.length; i++){
            if(arr[i]< minVal){
                minVal = arr[i];
            }
        }
        return minVal;
    }

    public static void main(String args[]){
        int[] arr = { 9, 2, 3, 6, -1};
        System.out.println(FindMinimum.getMinFromArray(arr));
    }
}
