package testCode;


import java.util.Arrays;

public class FindSum {

    /*
               arr = {1, 21, 3, 14, 5, 60, 7, 6}
              value = 27
              Sample Output #
                 arr = {21, 6} or {6, 21}
     */

    public static int[] returnSumVal(int[] arr, int val){

       int startVal =0;
       int endVal = arr.length-1;
       int[] result= new int[2];

           for(int j=0; j< arr.length;j++){
            int sum = arr[startVal]+arr[endVal];
               if(sum < val){
                   startVal++;
               }else if(sum > val){
                   endVal--;
               }else {
                   result[0] = arr[startVal];
                   result[1] = arr[endVal];

               }


       }
      return  result;
    }

    public static void main(String args[]){
        int[] arrSum = new int[] {1, 3, 5, 6, 7, 14, 21, 60};
        //Arrays.sort(arrSum);
      int[] rSum= FindSum.returnSumVal(arrSum,27);
        System.out.println(Arrays.toString(rSum));
    }
}
