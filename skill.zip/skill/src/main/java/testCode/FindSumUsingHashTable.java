package testCode;

import java.util.Arrays;
import java.util.HashMap;

public class FindSumUsingHashTable {

    public static int[] findSum(int[] arr, int target){
        HashMap<Integer,Integer> hashMap = new HashMap<Integer, Integer>();
        for(int i =0; i<arr.length; i++){
            if(hashMap.containsKey(target-arr[i])){
                return new int[]{arr[hashMap.get(target-arr[i])], arr[i]};
            }else{
                hashMap.put(arr[i],i);
            }
        }
        return new int[]{-1,-1};
    }
    public static void main(String args[]){
        int[] arrSum = new int[] {1, 3, 5, 6, 7, 14, 21, 60};
        //Arrays.sort(arrSum);
        int[] rSum= FindSumUsingHashTable.findSum(arrSum,27);
        System.out.println(Arrays.toString(rSum));
    }

}
