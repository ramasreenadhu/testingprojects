package testCode;


import java.util.*;

public class LeetCode {

    private int lo, maxLen;

    // https://www.youtube.com/watch?v=1SDVa-p_CZs

    public static class ListNode {
        int val;
        ListNode next;
        ListNode() {}
        ListNode(int val) { this.val = val; }
    }

    public static ListNode MergeSortedTwoList(ListNode node1, ListNode node2){
        ListNode dummy = new ListNode(0);
        ListNode l3 = dummy;

        while(node1 !=null && node2!=null){
            if(node1.val <= node2.val){
                l3.next=node1;
            }else{
                l3.next = node2;
            }
            l3= l3.next;
        }

        if(node1!=null){
            l3.next=node1;
        }

        if(node2!=null){
            l3.next=node2;
        }
          return dummy.next;
    }

    /*
        https://www.youtube.com/watch?v=qOyO7MCd1G8&t=964s
        https://leetcode.com/problems/add-two-numbers/
        Input: (2 -> 4 -> 3) + (5 -> 6 -> 4)
        Output: 7 -> 0 -> 8
     */

    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {

        ListNode dummy = new ListNode(0);
        ListNode l3 = dummy;
        int carry =0;

        //  12+9 11%10 =1 11/10 =1
        while(l1!=null && l2!=null){
            int digitalVal = (l1.val + l2.val+carry)%10;
            carry = (l1.val + l2.val+carry)/10;
            ListNode ll = new ListNode(digitalVal);
            l3.next=ll;
            l1= l1.next;
            l2= l2.next;
        }

        while(l1!=null){
            int digitalVal = (l1.val +carry)%10;
            carry = (l1.val +carry)/10;
            ListNode ll = new ListNode(digitalVal);
            l3.next=ll;
            l1= l1.next;

        }

        while(l2!=null){
            int digitalVal = (l2.val +carry)%10;
            carry = (l2.val +carry)/10;
            ListNode ll = new ListNode(digitalVal);
            l3.next=ll;
            l2= l2.next;
        }

        if(carry!=0){
            ListNode ll =new ListNode(carry);
            l3.next =ll;
            l3 = ll;
        }

        return dummy.next;
    }


    //https://www.youtube.com/watch?v=kGlSZdDfm8M
    public static void LRUCacheTest(){

    }

    /*
    https://leetcode.com/problems/reorder-data-in-log-files/discuss/362761/Java-Solution-Beats-99-both-runtime-and-memory
    https://www.youtube.com/watch?v=Ie7VMpZlLrY
    boolean result= Character.isDigit("dig1 8 1 5 1".charAt("dig1 8 1 5 1".length()-1));
    System.out.println(result);
    int out = s1.compareTo(s2); => This returns difference s1-s2.=>  Compares two string lexicographically.
     */
    public static String[] reorderLogFiles(String[] logs) {
        if(logs.length == 0) return logs;
        List<String> letterLogs = new ArrayList<>(), digitLogs = new ArrayList<>();
        LeetCodeUtility.separateLettersDigits(logs, letterLogs, digitLogs);
        LeetCodeUtility.sortLetterLogs(letterLogs);
        return LeetCodeUtility.generateOutput(letterLogs, digitLogs);
    }



    //https://www.youtube.com/watch?v=LnnJTODA77I   -- reverse LinkedList II

    /*
        Input: words = ["hello","leetcode"], order = "hlabcdefgijkmnopqrstuvwxyz"
        Output: true
        Explanation: As 'h' comes before 'l' in this language, then the sequence is sorted.

        Input: words = ["word","world","row"], order = "worldabcefghijkmnpqstuvxyz"
        Output: false
        Explanation: As 'd' comes after 'l' in this language, then words[0] > words[1], hence the sequence is unsorted.

        https://leetcode.com/problems/verifying-an-alien-dictionary/discuss/390005/java-solution-with-HashMap
     */

    Map<Character, Integer> map;
    public boolean isAlienSorted(String[] words, String order) {
        map = new HashMap<>();
        for (int i = 0; i < order.length(); i++) {
            map.put(order.charAt(i), i);
        }
        for (int i = 0; i < words.length - 1; i++) {
            if (!compare(words[i], words[i + 1])) return false;
        }
        return true;
    }

    private boolean compare(String s1, String s2) {
        int l1 = s1.length(), l2 = s2.length();
        for (int i = 0, j = 0; i < l1 && j < l2; i++, j++) {
            if (s1.charAt(i) != s2.charAt(j)) {
                if (map.get(s1.charAt(i)) > map.get(s2.charAt(j))) {
                    return false;
                } else {
                    return true;
                }
            }
        }
        if (l1 > l2) return false;
        return true;
    }

    public String longestPalindrome(String s) {
        int len = s.length();
        if (len < 2)
            return s;

        for (int i = 0; i < len-1; i++) {
            extendPalindrome(s, i, i);  //assume odd length, try to extend Palindrome as possible
            extendPalindrome(s, i, i+1); //assume even length.
        }
        return s.substring(lo, lo + maxLen);
    }

    private void extendPalindrome(String s, int j, int k) {
        while (j >= 0 && k < s.length() && s.charAt(j) == s.charAt(k)) {
            j--;
            k++;
        }
        if (maxLen < k - j - 1) {
            lo = j + 1;
            maxLen = k - j - 1;
        }
    }

    /*
      word search : https://www.youtube.com/watch?v=OYxTVKogJkQ
     */

    /*
       Longest SubString without Repeat chars : https://www.youtube.com/watch?v=aIrbWbON63M
     */

    /*
         https://www.youtube.com/watch?v=_RrNV8oMMug
         formula : n = (n-1) + (n-2)
         Input: 2
         Output: 2
         Explanation: There are two ways to climb to the top.
         1. 1 step + 1 step
         2. 2 steps
     */
    public static int climbStairs(int n) {
         if(n <=1){
             return 1;
         }

         int[] ways = new int[n+1];
         ways[0] =1;
         ways[1] =1;

         for(int i=2; i<=n; i++){
             ways[i] = ways[i-1] + ways[i-2];
         }
         return ways[n];
    }

    /*
        https://www.youtube.com/watch?v=h6FmiyYDjmk
        http://www.goodtecher.com/leetcode-17-letter-combinations-of-a-phone-number/
     */

    public static List<String> letterCombinations(String digits) {
        List<String> result = new ArrayList<>();
        if (digits == null || digits.equals("")) {
            return result;
        }
        StringBuilder sb = new StringBuilder();
        Map<Character, char[]> lettersMap = getLettersMap();
        letterCombinationsHelper(digits, sb, lettersMap, result);
        return result;
    }

    private static Map<Character, char[]> getLettersMap() {
        Map<Character, char[]> lettersMap = new HashMap<>();
        lettersMap.put('0', new char[]{});
        lettersMap.put('1', new char[]{});
        lettersMap.put('2', new char[]{'a', 'b', 'c'});
        lettersMap.put('3', new char[]{'d', 'e', 'f'});
        lettersMap.put('4', new char[]{'g', 'h', 'i'});
        lettersMap.put('5', new char[]{'j', 'k', 'l'});
        lettersMap.put('6', new char[]{'m', 'n', 'o'});
        lettersMap.put('7', new char[]{'p', 'q', 'r', 's'});
        lettersMap.put('8', new char[]{'t', 'u', 'v'});
        lettersMap.put('9', new char[]{'w', 'x', 'y', 'z'});

        return lettersMap;
    }

    private static void letterCombinationsHelper(String digits, StringBuilder sb, Map<Character, char[]> lettersMap, List<String> result) {
        if (sb.length() == digits.length()) {
            result.add(sb.toString());
            return;
        }

        for (char ch : lettersMap.get(digits.charAt(sb.length()))) {
            sb.append(ch);
            letterCombinationsHelper(digits, sb, lettersMap, result);
            sb.deleteCharAt(sb.length() - 1);
        }
    }


    public static void main(String args[]){
//     String[] str = new String[]{"dig1 8 1 5 1","let1 art can","dig2 3 6","let2 own kit dig","let3 art zero"};
//     String[] str1 = LeetCode.reorderLogFiles(str);
//     System.out.println(Arrays.toString(str1));

       // System.out.println(LeetCode.reverseLinkedListNode(new ListNode()));
//        new LeetCode().longestPalindrome("aba");
//        System.out.println(LeetCode.climbStairs(4));

        LeetCode.letterCombinations("23");

    }
}
