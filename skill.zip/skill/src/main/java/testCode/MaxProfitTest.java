package testCode;

public class MaxProfitTest {

    public static int maxProfit(int[] arr){
         int minPrice = Integer.MAX_VALUE;
         int maxProfit=0;
         for(int i=0; i< arr.length; i++){
             if(arr[i] < minPrice){
                 minPrice = arr[i];
             }else if(arr[i]-minPrice > maxProfit){
                 maxProfit = arr[i]-minPrice;
             }
         }
       return maxProfit;
    }

    public static int maxProfit2ndSol(int[] arr){
        int maxProfit=0;
        int minVal = Integer.MAX_VALUE;
        for(int i=0; i< arr.length; i++){
            minVal = Math.min(minVal, arr[i]); // 7  7,1 1
            maxProfit = Math.max(maxProfit, arr[i]-minVal); // 0, 0

        }
        return maxProfit;
    }

    public static void main(String args[]){
        int[] arr ={7,1,5,3,6,4};
        int profit = MaxProfitTest.maxProfit2ndSol(arr);
        System.out.println(profit);

    }
}
