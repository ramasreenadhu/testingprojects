package testCode;

import leetcode.easy.MostCommonWord;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MostCommonWords {
    public static String commonWord(String str){
        if(str.isEmpty()){
            return null;
        }
        if(str.length() <=1){
            return str;
        }

       Map<String,Integer> map=  new HashMap<String,Integer>();
       String[] spStr =  str.split(" ");
       for(int i=0; i<spStr.length; i++){
           if(map.containsKey(spStr[i])){
               map.put(spStr[i], map.get(spStr[i])+1);
           }else{
               map.put(spStr[i], 1);
           }
       }

        System.out.println(map);
       int max=0;
       String rs ="";

       for(String s : map.keySet()){
           if(map.get(s)>max){
               rs=s;
               max = map.get(s);
           }
           //max = Math.max(map.get(s),max);
           //rs=s;
       }
       return rs;
    }

    public static void main(String args[]){

        System.out.println(MostCommonWords.commonWord("Bob hit a ball, the hit BALL flew far after it was hit."));
    }
}
