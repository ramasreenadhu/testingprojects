package testCode;

import java.util.Arrays;

public class RotateArray {

    /*
        Sample Input #
              arr = {1, 2, 3, 4, 5}
        Sample Output #
              arr = {5, 1, 2, 3, 4}
     */

    public static int[] rotateArr(int[] arr){

        int val = arr[arr.length-1];

        for(int i = arr.length-1; i>0; i--){
            arr[i] =arr[i-1];
        }
        arr[0]=val;
        return arr;
    }

    public static void main(String args[]){
        int[] arr = {3, 6, 1, 8, 4, 2};
        System.out.println(Arrays.toString(RotateArray.rotateArr(arr)));

    }

}
