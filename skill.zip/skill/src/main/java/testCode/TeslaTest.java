package testCode;

import leetcode.validParentheses;

import java.util.*;

public class TeslaTest {

    /*
        How many times 'balloon' words appears in given String
        Input: text = "loonbalxballpoon"
        Output: 2
     */

    //https://www.youtube.com/watch?v=LGgMZC0vj5s
    //https://leetcode.com/problems/maximum-number-of-balloons/ 
    public static int maxNumberOfBalloons(String text) {
        int[] count = new int[26];
        for(char c : text.toCharArray()){
            count[c-'a']++;
        }
        System.out.println(Arrays.toString(count));
        // [1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 2, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        return Math.min(count[1],Math.min(count[0],Math.min(count[11]/2,Math.min(count[14]/2,count[13]))));
    }

    /*
       Input: ["eat", "tea", "tan", "ate", "nat", "bat"],
      Output:
[
  ["ate","eat","tea"],
  ["nat","tan"],
  ["bat"]
]
     */

    //https://www.youtube.com/watch?v=0I6IL3TnIZs
    //https://leetcode.com/problems/group-anagrams/
    public static List<List<String>> groupAnagrams(String[] strs) {
        if (strs.length == 0) return new ArrayList();
        Map<String, List> ans = new HashMap<String, List>();
        for (String s : strs) {
            char[] ca = s.toCharArray();
            Arrays.sort(ca);
            String key = String.valueOf(ca);

            if (!ans.containsKey(key))
                ans.put(key, new ArrayList());{
            }

            ans.get(key).add(s);
        }
        return new ArrayList(ans.values());
    }


   /*
        pivot index as the index where the sum of all the numbers to the left of the index is
        equal to the sum of all the numbers to the right of the index.


         totalsum=28
         L=1
         R=27

         L=8
         R=20

         L=11
         R=17

         L=17
        if(L==R)
        return i;

        Input: nums = [1,7,3,6,5,6]
        Output: 3
        Explanation:
               The sum of the numbers to the left of index 3 (nums[3] = 6) is equal to the sum of numbers to the right of index 3.
                Also, 3 is the first index where this occurs.
    */
   // https://www.youtube.com/watch?v=wKXEviRbLtY
    public static int pivotIndex(int[] nums) {
        int totalSum=0, leftSum=0, rightSum=0;
        for(int i=0; i< nums.length; i++){
            totalSum = totalSum+nums[i];
        }
        for(int j=0; j<nums.length ;j++){
            rightSum = totalSum - leftSum -nums[j];
            if(rightSum==leftSum){
                return j;
            }
            leftSum = leftSum+nums[j]
            ;
        }
        return -1;
    }

    /*
          Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
          Output: 5
          Explanation: As one shortest transformation is "hit" -> "hot" -> "dot" -> "dog" -> "cog", return its length 5.
          https://www.youtube.com/watch?v=PeyYhb8lJJU
          https://leetcode.com/problems/word-ladder/

          // core logic: classic BFS: starting from the begin word, do a BFS till you encounter the end word. if you don't find end word by the end of the process, return 0
    // level 1: hit  level 2: hot  level 3: dot, lot   level 4: dog, log   level 5: cog  (this is for example 1)
    // TC: O(m * n) -> where m is the length of word list and n is the length of each word

    BFS uses Queue to find the shortest path. DFS uses Stack to find the shortest path. BFS is better when target is closer to Source. DFS is better when target is far from source.

     */

    private static int ladderLength(String beginWord, String endWord, List<String> wordList) {
        if (!wordList.contains(endWord)) {
            return 0;
        }

        int level = 0;
        Queue<String> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>(wordList);
        queue.offer(beginWord);

        while (!queue.isEmpty()) {
            int queueSize = queue.size();
            for (int i = 0; i < queueSize; i++) {
                String word = queue.poll();
                if (word.equals(endWord)) {
                    return level + 1;
                }
                wordMatch(queue, visited, word);
            }
            level++;
        }
        return 0;
    }

    private static void wordMatch(Queue<String> queue, Set<String> visited, String word) {
        for (int i = 0; i < word.length(); i++) {
            char[] wordArray = word.toCharArray();
            for (char ch = 'a'; ch < 'z'; ch++) {
                wordArray[i] = ch;

                String newWord = String.valueOf(wordArray);
                if (visited.contains(newWord)) {
                    visited.remove(newWord);
                    queue.offer(newWord);
                }
            }
        }
    }


    /*
         For example, 128 is a self-dividing number because 128 % 1 == 0, 128 % 2 == 0, and 128 % 8 == 0.
         Input: left = 1, right = 22
         Output: [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 15, 22]

         Logic :  System.out.println(Arrays.toString(String.valueOf(128).toCharArray())); -- [1,2,8]
     */

    public static List<Integer> selfDividingNums(int left, int right){
      List<Integer> list =new ArrayList<Integer>();
      for(int k =left; k<=right; k++){
          if(isSelfDividingNum(k)){
              list.add(k);
          }
      }
       return list;
    }

    public static boolean isSelfDividingNum(int num){
        // convert to string
        for(char c : String.valueOf(num).toCharArray()){
            if(num % c > 0){
                return false;
            }
        }
       return true;
    }

    /*
          https://www.youtube.com/watch?v=oRllj-ObrBU
          https://leetcode.com/problems/search-in-rotated-sorted-array/solution/
          Input: nums = [4,5,6,7,0,1,2], target = 0
          Output: 4
          step1: start < middle => start < taget && target < middle ( target is btw start & middle) -- end = mid-1;
          step2: middle < end =>  (target is bwt middle & end) -- start = middle+1
     */

    public static int searchInRotatedSortedAray(int[] nums, int target) {
        int start = 0, end = nums.length - 1;
        while (start <= end) {
            int mid = start + (end - start) / 2;
            if (nums[mid] == target) return mid;

            else if (nums[start] <= nums[mid]) {
                if (nums[start] <= target && target < nums[mid]) end = mid - 1; // target is btw start & middle
                else start = mid + 1;
            }
            else {
                if (target <= nums[end] && target > nums[mid]) start = mid + 1; // target is btw middle & end
                else end = mid - 1;
            }
        }
        return -1;
    }

    /*
         validate Parantheseses
     */

    public static boolean isValid2ndSolution(String str){
        Stack<Character> stack = new Stack<Character>();
        char[] ch = str.toCharArray();
        for(int i=0 ; i< ch.length; i++){
            if(ch[i]=='(' || ch[i]=='[' || ch[i]=='{'){
                stack.push(ch[i]);
            }else{
                if(!stack.isEmpty() && isParantheseses(stack.peek(),ch[i])){
                    stack.pop();
                }else{
                    return false;
                }
            }

        }

        return stack.isEmpty();
    }

    public static boolean isParantheseses(char left, char right){
        return left =='(' && right==')' || left=='{' && right=='}' || left=='[' && right==']';
    }


    //https://www.youtube.com/watch?v=kGlSZdDfm8M -- LRU cache



    public static void main(String args[]){
        //System.out.println(TeslaTest.maxNumberOfBalloons("loonbalxballpoon"));
        TeslaTest.groupAnagrams(new String[]{"eat", "tea", "tan", "ate", "nat", "bat"});
//        int result = TeslaTest.pivotIndex(new int[]{1,7,3,6,5,6});
//        System.out.println(result);

        //System.out.println(TeslaTest.ladderLength("hit", "cog", Arrays.asList(new String[]{"hot","dot","dog","lot","log","cog"})));
//       List<Integer> listInt=  TeslaTest.selfDividingNums(1,22);
//       System.out.println(listInt);

       // System.out.println(TeslaTest.searchInRotatedSortedAray(new int[]{4,5,6,7,0,1,2},0));

        //System.out.println( new validParentheses().isValid2ndSolution("((()(())))"));

    }
}
