package testCode;

public class TestFizzBuzz {



}

