package testCode;

import leetcode.validParentheses;

import java.util.HashMap;
import java.util.Stack;

public class testParthenseses {

    public static boolean isValidParentheses(String str){
        HashMap<Character,Character> hashMap =new HashMap<Character,Character>();
        hashMap.put(')','(');
        hashMap.put('}', '{');
        hashMap.put(']','[');
        char[] ch = str.toCharArray();
        Stack<Character> st = new Stack<Character>();
         for(int i=0; i<ch.length;i++){
               if(hashMap.containsKey(ch[i])){

                   char topElement = st.empty()? '#' : st.pop();

                 if(topElement !=hashMap.get(ch[i])){  // if no pop .. return false invalid parthenses
                     return false;
                 }

               }else{
                   st.push(ch[i]);
               }
        }
        return st.empty();
    }

    public static void main(String args[]){
        System.out.println( testParthenseses.isValidParentheses("[((()(())))]]"));
    }
}
