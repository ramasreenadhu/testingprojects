package testCode2;

import java.util.*;

public class BinarySearchProb {

    public static int findIndexOfVal(int[] arr, int val) {
        Arrays.sort(arr);
        int first = 0;
        int last = arr.length - 1;
        int mid = (first + last) / 2;
        while (first <= last) {
            if (arr[mid] < val) {
                last = mid + 1;
            } else if (arr[mid] > val) {
                first = mid - 1;
            } else if (arr[mid] == val) {
                return mid;
            }
            mid = first + last;
        }
        return -1;
    }


    public static int maxSubArray(int[] nums) {
        int max = nums[0];
        int maxsofar = nums[0];
        for (int i = 1; i < nums.length; i++) {
            maxsofar = Math.max(maxsofar + nums[i], nums[i]);
            max = Math.max(max, maxsofar);
        }
        return max;
    }

    public static void printNumberOFWordsRepeat(String str) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        String[] strArray = str.split(" ");
        for (int i = 0; i < strArray.length; i++) {
            if (map.containsKey(strArray[i])) {
                map.put(strArray[i], map.get(strArray[i]) + 1);
            } else {
                map.put(strArray[i], 1);
            }
        }

        Set<Map.Entry<String, Integer>> set = map.entrySet();
        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(set);
        for (Map.Entry<String, Integer> a : list) {
            System.out.println(a.getKey() + "has how many repeat words..." + a.getValue());
        }
    }

    public static String reverseString(String str) {
        char temp;
        char[] charArray = str.toCharArray();
        int n = charArray.length;
        for (int i = 0; i < n / 2; i++) {
            temp = charArray[n - i - 1];
            charArray[n - i - 1] = charArray[i];
            charArray[i] = temp;
        }
        return new String(charArray);
    }


    public static int[] rotateArray(int[] arr) {
        for (int j = 0; j <= 1; j++) {
            int val = arr[arr.length - 1];
            for (int i = arr.length - 1; i > 0; i--) {
                arr[i] = arr[i - 1];
            }
            arr[0] = val;

        }
        return arr;
    }

    public static void main(String args[]){
//        int val = BinarySearchProb.findIndexOfVal(new int[]{10,4,7,30,12},12);
//        System.out.println(val);

        //BinarySearchProb.printNumberOFWordsRepeat("rama sreenadhu rama krishna");
        //System.out.println(BinarySearchProb.reverseString("sr"));

        System.out.println(Arrays.toString(BinarySearchProb.rotateArray(new int[]{10,30,3,1,9})));
    }
}
