package testCode2;

import java.util.*;

public class CodingTest {
    public static int searchTargetInRotatedArrays(int[] arr, int target) {

        int start = 0;
        int end = arr.length;
       for(int i=0; i<arr.length; i++) {
            int mid = (start + end) / 2;
            if(arr[mid]==target){
                return mid;
            }else if(arr[start]<= arr[mid]){
                if(arr[start]<=target && target<=arr[mid]){
                    end=end-1;
                }else{
                    start= start+1;
                }
            }else if(arr[mid]<=arr[end]){
                if(arr[mid]<target & target<arr[end]){
                    start = mid+1;
                }else{
                    end = end-1;
                }
            }
        }

        return -1;
    }

    public static int countMaxNumberOFBalloonsInGivenString(String str){
       char[] ch = str.toCharArray();
       int[] count = new int[26];
       for(int i=0; i<ch.length; i++){
           count[ch[i]-'a']++;
       }
       return Math.min(count[1],Math.min(count[0],Math.min(count[11]/2,Math.min(count[14]/2,count[13]/2))));
    }


    public static List<String> groupAnagrams(String[] str){
       Map<String,List<String>> map =new HashMap<String, List<String>>();
       for(int i=0; i<str.length;i++){
          char[] ch = str[i].toCharArray();
           Arrays.sort(ch);
           String key = String.valueOf(ch);
           if(!map.containsKey(key)){
               map.put(key,new ArrayList());
           }

           map.get(key).add(str[i]);
       }
         return new ArrayList(map.values());
    }

    public static void main(String args[]){
        //System.out.println(CodingTest.searchTargetInRotatedArrays(new int[]{4,5,6,7,0,1,2},0));
        //System.out.println(CodingTest.countMaxNumberOFBalloonsInGivenString("loonbalxballpoon"));
    }


}
