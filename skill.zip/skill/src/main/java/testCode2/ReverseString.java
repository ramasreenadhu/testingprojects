package testCode2;

public class ReverseString {

    public static String reverseStr(String str){
        int n= str.length();
        char[] ch = str.toCharArray();
        char temp;
        for(int i =0; i< n/2; i++){
            temp = ch[n-i-1];
            ch[n-i-1]= ch[i];
            ch[i] = temp;
        }
        return new String(ch);
    }

    public static int reverseInt(int num){
        int rev =0;
         while(num!=0){
             int pop = num %10;
             num = num/10;
             rev = rev *10 + pop;
         }

         return rev;
    }

    public static void main(String args[]){
        String str1 = ReverseString.reverseStr("rama");
        System.out.println(str1);

        int res= ReverseString.reverseInt(8789);
        System.out.println(res);
    }
}
