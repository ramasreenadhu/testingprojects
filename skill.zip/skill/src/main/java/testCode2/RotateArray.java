package testCode2;

import java.util.Arrays;

public class RotateArray {

    public static int[] getArrayRotated(int[] arr){

         int n = arr.length-1;
         int val = arr[n];
         int[] rotatyArr = new int[n+1];

         for(int i=1; i<=n; i++){
             rotatyArr[i] = arr[i-1];
         }
        rotatyArr[0]=val;
         return rotatyArr;
    }

    public static void main(String args[]){
        System.out.println(Arrays.toString(RotateArray.getArrayRotated(new int[]{1,2,3,4,5})));
    }
}
