package testCode2;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class ValidateParanthseses {
    public static boolean isValidParthses(String str){
        Map<Character, Character> map =new HashMap<Character, Character>();
        map.put('}', '{');
        map.put(')','(');
        map.put(']','[');
        Stack<Character> stack = new Stack<Character>();
        char topEle;

        for(int i=0; i< str.length()-1; i++){
            if(map.containsKey(str.charAt(i))){
               topEle = stack.empty()? '#' : stack.pop();
               if(topEle!=map.get(str.charAt(i))){
                   return false;
               }
            }else{
                stack.push(str.charAt(i));
            }
        }
        return stack.empty();
    }
}
